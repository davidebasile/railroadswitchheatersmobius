#include "provaPVModel.h"

provaPVModel::provaPVModel(bool expandTimeArrays) {
  TheModel=new SwitchNetRJ();
  DefineName("provaPVModel");
  CreatePVList(2, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* provaPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new provaPV0(timeindex);
    break;
  case 1:
    return new provaPV1(timeindex);
    break;
  }
  return NULL;
}
