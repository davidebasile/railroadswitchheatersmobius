#ifndef _PROVA_PVS_
#define _PROVA_PVS_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"

extern Float HeatersAtInterval;

class provaPV0Worker:public InstantOfTime
{
 public:
  RailSwitchHeater2SAN *RailSwitchHeater2;
  
  provaPV0Worker();
  ~provaPV0Worker();
  double Reward_Function();
};

class provaPV0:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  provaPV0Worker *provaPV0WorkerList;

  provaPV0(int timeindex=0);
  ~provaPV0();
  void CreateWorkerList(void);
};

class provaPV1Worker:public InstantOfTime
{
 public:
  QueueSAN *Queue;
  
  provaPV1Worker();
  ~provaPV1Worker();
  double Reward_Function();
};

class provaPV1:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  provaPV1Worker *provaPV1WorkerList;

  provaPV1(int timeindex=0);
  ~provaPV1();
  void CreateWorkerList(void);
};

#endif
