#include "provaPVNodes.h"

provaPV0Worker::provaPV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater2);
}

provaPV0Worker::~provaPV0Worker() {
  delete [] TheModelPtr;
}

double provaPV0Worker::Reward_Function(void) {

return (double) RailSwitchHeater2->on->Mark();

return (0);



}

provaPV0::provaPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={HeatersAtInterval};
  double stoppts[1]={HeatersAtInterval};
  Initialize("ActivatedHeatersAtTime",(RewardType)0,1, startpts, stoppts, timeindex, 0,1, 1);
  AddVariableDependency("on","RailSwitchHeater2");
}

provaPV0::~provaPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void provaPV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new provaPV0Worker;
}
provaPV1Worker::provaPV1Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&Queue);
}

provaPV1Worker::~provaPV1Worker() {
  delete [] TheModelPtr;
}

double provaPV1Worker::Reward_Function(void) {

return (double) Queue->queue->Mark();

return (0);



}

provaPV1::provaPV1(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={HeatersAtInterval};
  double stoppts[1]={HeatersAtInterval};
  Initialize("ActivatedHeatersAtTime2",(RewardType)0,1, startpts, stoppts, timeindex, 0,1, 1);
  AddVariableDependency("queue","Queue");
}

provaPV1::~provaPV1() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void provaPV1::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new provaPV1Worker;
}
