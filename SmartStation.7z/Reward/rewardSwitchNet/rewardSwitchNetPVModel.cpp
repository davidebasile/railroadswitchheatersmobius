#include "rewardSwitchNetPVModel.h"

rewardSwitchNetPVModel::rewardSwitchNetPVModel(bool expandTimeArrays) {
  TheModel=new SwitchNetRJ();
  DefineName("rewardSwitchNetPVModel");
  CreatePVList(3, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* rewardSwitchNetPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new rewardSwitchNetPV0(timeindex);
    break;
  case 1:
    return new rewardSwitchNetPV1(timeindex);
    break;
  case 2:
    return new rewardSwitchNetPV2(timeindex);
    break;
  }
  return NULL;
}
