#ifndef _REWARDSWITCHNET_PVS_
#define _REWARDSWITCHNET_PVS_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
#include "Cpp/Performance_Variables/IntervalOfTime.hpp"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"

extern Short priorities;
extern Float HeatersAtInterval;
extern Short phigh;
extern Short plow;
extern Short pmedium;

class rewardSwitchNetPV0Worker:public IntervalOfTime
{
 public:
  RailSwitchHeater2SAN *RailSwitchHeater2;
  
  rewardSwitchNetPV0Worker();
  ~rewardSwitchNetPV0Worker();
  double Reward_Function();
};

class rewardSwitchNetPV0:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  rewardSwitchNetPV0Worker *rewardSwitchNetPV0WorkerList;

  rewardSwitchNetPV0(int timeindex=0);
  ~rewardSwitchNetPV0();
  void CreateWorkerList(void);
};

class rewardSwitchNetPV1Worker:public InstantOfTime
{
 public:
  RailSwitchHeater2SAN *RailSwitchHeater2;
  
  rewardSwitchNetPV1Worker();
  ~rewardSwitchNetPV1Worker();
  double Reward_Function();
};

class rewardSwitchNetPV1:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  rewardSwitchNetPV1Worker *rewardSwitchNetPV1WorkerList;

  rewardSwitchNetPV1(int timeindex=0);
  ~rewardSwitchNetPV1();
  void CreateWorkerList(void);
};

class rewardSwitchNetPV2Worker:public InstantOfTime
{
 public:
  RailSwitchHeater2SAN *RailSwitchHeater2;
  
  rewardSwitchNetPV2Worker();
  ~rewardSwitchNetPV2Worker();
  double Reward_Function();
};

class rewardSwitchNetPV2:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  rewardSwitchNetPV2Worker *rewardSwitchNetPV2WorkerList;

  rewardSwitchNetPV2(int timeindex=0);
  ~rewardSwitchNetPV2();
  void CreateWorkerList(void);
};

#endif
