#ifndef _REWARDSWITCHNET_PVMODEL_
#define _REWARDSWITCHNET_PVMODEL_
#include "rewardSwitchNetPVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
class rewardSwitchNetPVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  rewardSwitchNetPVModel(bool expandtimepoints);
};

#endif
