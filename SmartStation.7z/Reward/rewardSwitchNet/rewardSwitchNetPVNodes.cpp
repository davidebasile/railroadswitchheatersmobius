#include "rewardSwitchNetPVNodes.h"

rewardSwitchNetPV0Worker::rewardSwitchNetPV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater2);
}

rewardSwitchNetPV0Worker::~rewardSwitchNetPV0Worker() {
  delete [] TheModelPtr;
}

double rewardSwitchNetPV0Worker::Reward_Function(void) {

if (priorities==4) //ALL
{
	if (RailSwitchHeater2->on->Mark() > 0)
		return (double) 1/numSwitch;
}
else if (priorities==3) //LOW
{
	if ((RailSwitchHeater2->on->Mark() > 0)&&
	    (RailSwitchHeater2->SwitchID->Mark()>(phigh+pmedium))&&
         (RailSwitchHeater2->SwitchID->Mark()<= (phigh+pmedium+plow)))
		return (double) 1/plow;
}
else if (priorities==2) //MEDIUM
{
	if ((RailSwitchHeater2->on->Mark() > 0)&&
	    (RailSwitchHeater2->SwitchID->Mark()>(phigh))&&
     (RailSwitchHeater2->SwitchID->Mark()<= (phigh+pmedium)))
		return (double) 1/pmedium;
}
else if (priorities==1) //HIGH
{
	if ((RailSwitchHeater2->on->Mark() > 0)&&
	    (RailSwitchHeater2->SwitchID->Mark()>0)&&
          (RailSwitchHeater2->SwitchID->Mark()<= (phigh)))
		return (double) 1/phigh;
}

return (0);



}

rewardSwitchNetPV0::rewardSwitchNetPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={0.0};
  double stoppts[1]={26.0};
  Initialize("TimeOn",(RewardType)1,1, startpts, stoppts, timeindex, 0,2, 2);
  AddVariableDependency("on","RailSwitchHeater2");
  AddVariableDependency("SwitchID","RailSwitchHeater2");
}

rewardSwitchNetPV0::~rewardSwitchNetPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void rewardSwitchNetPV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new rewardSwitchNetPV0Worker;
}
rewardSwitchNetPV1Worker::rewardSwitchNetPV1Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater2);
}

rewardSwitchNetPV1Worker::~rewardSwitchNetPV1Worker() {
  delete [] TheModelPtr;
}

double rewardSwitchNetPV1Worker::Reward_Function(void) {

if (priorities==4) //ALL
{
	if (RailSwitchHeater2->failure->Mark() > 0)
		return (double) 1/numSwitch;
}
else if (priorities==3) //LOW
{
	if ((RailSwitchHeater2->failure->Mark() > 0)&&
	    (RailSwitchHeater2->SwitchID->Mark()>(phigh+pmedium))&&
         (RailSwitchHeater2->SwitchID->Mark()<= (phigh+pmedium+plow)))
		return (double) 1/plow;
}
else if (priorities==2) //MEDIUM
{
	if ((RailSwitchHeater2->failure->Mark() > 0)&&
	    (RailSwitchHeater2->SwitchID->Mark()>(phigh))&&
     (RailSwitchHeater2->SwitchID->Mark()<= (phigh+pmedium)))
		return (double) 1/pmedium;
}
else if (priorities==1) //HIGH
{
	if ((RailSwitchHeater2->failure->Mark() > 0)&&
	    (RailSwitchHeater2->SwitchID->Mark()>0)&&
          (RailSwitchHeater2->SwitchID->Mark()<= (phigh)))
		return (double) 1/phigh;
}

return (0);



}

rewardSwitchNetPV1::rewardSwitchNetPV1(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={25.0};
  double stoppts[1]={25.0};
  Initialize("Failure",(RewardType)0,1, startpts, stoppts, timeindex, 0,2, 2);
  AddVariableDependency("failure","RailSwitchHeater2");
  AddVariableDependency("SwitchID","RailSwitchHeater2");
}

rewardSwitchNetPV1::~rewardSwitchNetPV1() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void rewardSwitchNetPV1::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new rewardSwitchNetPV1Worker;
}
rewardSwitchNetPV2Worker::rewardSwitchNetPV2Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater2);
}

rewardSwitchNetPV2Worker::~rewardSwitchNetPV2Worker() {
  delete [] TheModelPtr;
}

double rewardSwitchNetPV2Worker::Reward_Function(void) {

if (priorities==4) //ALL
{
	return RailSwitchHeater2->on->Mark();
}
else if (priorities==3) //LOW
{
	if (
	    (RailSwitchHeater2->SwitchID->Mark()>(phigh+pmedium))&&
         (RailSwitchHeater2->SwitchID->Mark()<= (phigh+pmedium+plow)))
		return RailSwitchHeater2->on->Mark();
}
else if (priorities==2) //MEDIUM
{
	if (
	    (RailSwitchHeater2->SwitchID->Mark()>(phigh))&&
     (RailSwitchHeater2->SwitchID->Mark()<= (phigh+pmedium)))
		return RailSwitchHeater2->on->Mark();
}
else if (priorities==1) //HIGH
{
	if (
	    (RailSwitchHeater2->SwitchID->Mark()>0)&&
          (RailSwitchHeater2->SwitchID->Mark()<= (phigh)))
		return RailSwitchHeater2->on->Mark();
}

return (0);



}

rewardSwitchNetPV2::rewardSwitchNetPV2(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={HeatersAtInterval};
  double stoppts[1]={HeatersAtInterval};
  Initialize("ActivatedHeatersAtTime",(RewardType)0,1, startpts, stoppts, timeindex, 0,2, 2);
  AddVariableDependency("on","RailSwitchHeater2");
  AddVariableDependency("SwitchID","RailSwitchHeater2");
}

rewardSwitchNetPV2::~rewardSwitchNetPV2() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void rewardSwitchNetPV2::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new rewardSwitchNetPV2Worker;
}
