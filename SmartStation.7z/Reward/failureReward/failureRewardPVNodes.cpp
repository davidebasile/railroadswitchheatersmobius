#include "failureRewardPVNodes.h"

failureRewardPV0Worker::failureRewardPV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater2);
}

failureRewardPV0Worker::~failureRewardPV0Worker() {
  delete [] TheModelPtr;
}

double failureRewardPV0Worker::Reward_Function(void) {

if (RailSwitchHeater2->failure->Mark()==1)
		return (double) 1/numSwitch;	


return (0);



}

failureRewardPV0::failureRewardPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={Interval};
  double stoppts[1]={Interval};
  Initialize("failureReward",(RewardType)0,1, startpts, stoppts, timeindex, 0,1, 1);
  AddVariableDependency("failure","RailSwitchHeater2");
}

failureRewardPV0::~failureRewardPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void failureRewardPV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new failureRewardPV0Worker;
}
