#include "failureRewardPVModel.h"

failureRewardPVModel::failureRewardPVModel(bool expandTimeArrays) {
  TheModel=new SwitchNetRJ();
  DefineName("failureRewardPVModel");
  CreatePVList(1, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* failureRewardPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new failureRewardPV0(timeindex);
    break;
  }
  return NULL;
}
