#ifndef _FAILUREREWARD_PVMODEL_
#define _FAILUREREWARD_PVMODEL_
#include "failureRewardPVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
class failureRewardPVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  failureRewardPVModel(bool expandtimepoints);
};

#endif
