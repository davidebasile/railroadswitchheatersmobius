#ifndef _FAILUREREWARD_PVS_
#define _FAILUREREWARD_PVS_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"

extern Float Interval;

class failureRewardPV0Worker:public InstantOfTime
{
 public:
  RailSwitchHeater2SAN *RailSwitchHeater2;
  
  failureRewardPV0Worker();
  ~failureRewardPV0Worker();
  double Reward_Function();
};

class failureRewardPV0:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  failureRewardPV0Worker *failureRewardPV0WorkerList;

  failureRewardPV0(int timeindex=0);
  ~failureRewardPV0();
  void CreateWorkerList(void);
};

#endif
