#ifndef _PHYSICREW_PVS_
#define _PHYSICREW_PVS_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
#include "Cpp/Performance_Variables/IntervalOfTime.hpp"


class physicRewPV0Worker:public IntervalOfTime
{
 public:
  RailSwitchHeater2SAN *RailSwitchHeater2;
  
  physicRewPV0Worker();
  ~physicRewPV0Worker();
  double Reward_Function();
};

class physicRewPV0:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  physicRewPV0Worker *physicRewPV0WorkerList;

  physicRewPV0(int timeindex=0);
  ~physicRewPV0();
  void CreateWorkerList(void);
};

#endif
