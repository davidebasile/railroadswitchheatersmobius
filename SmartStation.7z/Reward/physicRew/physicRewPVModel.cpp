#include "physicRewPVModel.h"

physicRewPVModel::physicRewPVModel(bool expandTimeArrays) {
  TheModel=new SwitchNetRJ();
  DefineName("physicRewPVModel");
  CreatePVList(1, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* physicRewPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new physicRewPV0(timeindex);
    break;
  }
  return NULL;
}
