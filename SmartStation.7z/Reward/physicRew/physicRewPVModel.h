#ifndef _PHYSICREW_PVMODEL_
#define _PHYSICREW_PVMODEL_
#include "physicRewPVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
class physicRewPVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  physicRewPVModel(bool expandtimepoints);
};

#endif
