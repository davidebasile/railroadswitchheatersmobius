#include "physicRewPVNodes.h"

physicRewPV0Worker::physicRewPV0Worker():IntervalOfTime(true)
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater2);
}

physicRewPV0Worker::~physicRewPV0Worker() {
  delete [] TheModelPtr;
}

double physicRewPV0Worker::Reward_Function(void) {

return RailSwitchHeater2->on->Mark();

return (0);



}

physicRewPV0::physicRewPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={0.0};
  double stoppts[1]={25};
  Initialize("prova",(RewardType)2,1, startpts, stoppts, timeindex, 0,1, 1);
  AddVariableDependency("on","RailSwitchHeater2");
}

physicRewPV0::~physicRewPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void physicRewPV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new physicRewPV0Worker;
}
