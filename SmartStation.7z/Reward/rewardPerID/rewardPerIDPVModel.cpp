#include "rewardPerIDPVModel.h"

rewardPerIDPVModel::rewardPerIDPVModel(bool expandTimeArrays) {
  TheModel=new SwitchNetRJ();
  DefineName("rewardPerIDPVModel");
  CreatePVList(2, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* rewardPerIDPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new rewardPerIDPV0(timeindex);
    break;
  case 1:
    return new rewardPerIDPV1(timeindex);
    break;
  }
  return NULL;
}
