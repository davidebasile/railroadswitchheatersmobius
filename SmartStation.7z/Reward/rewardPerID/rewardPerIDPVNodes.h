#ifndef _REWARDPERID_PVS_
#define _REWARDPERID_PVS_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
#include "Cpp/Performance_Variables/IntervalOfTime.hpp"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"

extern Short IdThreshold;

class rewardPerIDPV0Worker:public IntervalOfTime
{
 public:
  RailSwitchHeater2SAN *RailSwitchHeater2;
  
  rewardPerIDPV0Worker();
  ~rewardPerIDPV0Worker();
  double Reward_Function();
};

class rewardPerIDPV0:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  rewardPerIDPV0Worker *rewardPerIDPV0WorkerList;

  rewardPerIDPV0(int timeindex=0);
  ~rewardPerIDPV0();
  void CreateWorkerList(void);
};

class rewardPerIDPV1Worker:public InstantOfTime
{
 public:
  RailSwitchHeater2SAN *RailSwitchHeater2;
  
  rewardPerIDPV1Worker();
  ~rewardPerIDPV1Worker();
  double Reward_Function();
};

class rewardPerIDPV1:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  rewardPerIDPV1Worker *rewardPerIDPV1WorkerList;

  rewardPerIDPV1(int timeindex=0);
  ~rewardPerIDPV1();
  void CreateWorkerList(void);
};

#endif
