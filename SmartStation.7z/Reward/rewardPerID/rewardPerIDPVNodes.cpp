#include "rewardPerIDPVNodes.h"

rewardPerIDPV0Worker::rewardPerIDPV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater2);
}

rewardPerIDPV0Worker::~rewardPerIDPV0Worker() {
  delete [] TheModelPtr;
}

double rewardPerIDPV0Worker::Reward_Function(void) {

if ((RailSwitchHeater2->SwitchID->Mark()>0)&&(RailSwitchHeater2->SwitchID->Mark()<=IdThreshold))
{
	if (RailSwitchHeater2->on->Mark() > 0)
		return (double) 1/IdThreshold;
}

return (0);



}

rewardPerIDPV0::rewardPerIDPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={0.0};
  double stoppts[1]={26.0};
  Initialize("TimeOnID",(RewardType)1,1, startpts, stoppts, timeindex, 0,2, 2);
  AddVariableDependency("SwitchID","RailSwitchHeater2");
  AddVariableDependency("on","RailSwitchHeater2");
}

rewardPerIDPV0::~rewardPerIDPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void rewardPerIDPV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new rewardPerIDPV0Worker;
}
rewardPerIDPV1Worker::rewardPerIDPV1Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater2);
}

rewardPerIDPV1Worker::~rewardPerIDPV1Worker() {
  delete [] TheModelPtr;
}

double rewardPerIDPV1Worker::Reward_Function(void) {

if ((RailSwitchHeater2->SwitchID->Mark()>0)&&(RailSwitchHeater2->SwitchID->Mark()<=IdThreshold))
{
	if (RailSwitchHeater2->failure->Mark() > 0)
		return (double) 1/IdThreshold;
}

return (0);



}

rewardPerIDPV1::rewardPerIDPV1(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={25.0};
  double stoppts[1]={25.0};
  Initialize("FailureID",(RewardType)0,1, startpts, stoppts, timeindex, 0,2, 2);
  AddVariableDependency("SwitchID","RailSwitchHeater2");
  AddVariableDependency("failure","RailSwitchHeater2");
}

rewardPerIDPV1::~rewardPerIDPV1() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void rewardPerIDPV1::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new rewardPerIDPV1Worker;
}
