#ifndef _REWARDPERID_PVMODEL_
#define _REWARDPERID_PVMODEL_
#include "rewardPerIDPVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
class rewardPerIDPVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  rewardPerIDPVModel(bool expandtimepoints);
};

#endif
