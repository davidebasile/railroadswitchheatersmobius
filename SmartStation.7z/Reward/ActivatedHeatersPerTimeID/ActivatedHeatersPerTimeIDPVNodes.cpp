#include "ActivatedHeatersPerTimeIDPVNodes.h"

ActivatedHeatersPerTimeIDPV0Worker::ActivatedHeatersPerTimeIDPV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater2);
}

ActivatedHeatersPerTimeIDPV0Worker::~ActivatedHeatersPerTimeIDPV0Worker() {
  delete [] TheModelPtr;
}

double ActivatedHeatersPerTimeIDPV0Worker::Reward_Function(void) {

if ((RailSwitchHeater2->SwitchID->Mark()>0)&&(RailSwitchHeater2->SwitchID->Mark()<=IdThreshold))
{
	if (RailSwitchHeater2->on->Mark() > 0)
		return RailSwitchHeater2->on->Mark();
}

return (0);



}

ActivatedHeatersPerTimeIDPV0::ActivatedHeatersPerTimeIDPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={HeatersAtInterval};
  double stoppts[1]={HeatersAtInterval};
  Initialize("ActivatedHeatersPerTime",(RewardType)0,1, startpts, stoppts, timeindex, 0,2, 2);
  AddVariableDependency("SwitchID","RailSwitchHeater2");
  AddVariableDependency("on","RailSwitchHeater2");
}

ActivatedHeatersPerTimeIDPV0::~ActivatedHeatersPerTimeIDPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void ActivatedHeatersPerTimeIDPV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new ActivatedHeatersPerTimeIDPV0Worker;
}
