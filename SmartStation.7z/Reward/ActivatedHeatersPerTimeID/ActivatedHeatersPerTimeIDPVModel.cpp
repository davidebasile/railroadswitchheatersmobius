#include "ActivatedHeatersPerTimeIDPVModel.h"

ActivatedHeatersPerTimeIDPVModel::ActivatedHeatersPerTimeIDPVModel(bool expandTimeArrays) {
  TheModel=new SwitchNetRJ();
  DefineName("ActivatedHeatersPerTimeIDPVModel");
  CreatePVList(1, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* ActivatedHeatersPerTimeIDPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new ActivatedHeatersPerTimeIDPV0(timeindex);
    break;
  }
  return NULL;
}
