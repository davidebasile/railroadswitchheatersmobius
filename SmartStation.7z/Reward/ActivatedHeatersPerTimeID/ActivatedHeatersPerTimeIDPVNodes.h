#ifndef _ACTIVATEDHEATERSPERTIMEID_PVS_
#define _ACTIVATEDHEATERSPERTIMEID_PVS_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"

extern Short IdThreshold;
extern Float HeatersAtInterval;

class ActivatedHeatersPerTimeIDPV0Worker:public InstantOfTime
{
 public:
  RailSwitchHeater2SAN *RailSwitchHeater2;
  
  ActivatedHeatersPerTimeIDPV0Worker();
  ~ActivatedHeatersPerTimeIDPV0Worker();
  double Reward_Function();
};

class ActivatedHeatersPerTimeIDPV0:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  ActivatedHeatersPerTimeIDPV0Worker *ActivatedHeatersPerTimeIDPV0WorkerList;

  ActivatedHeatersPerTimeIDPV0(int timeindex=0);
  ~ActivatedHeatersPerTimeIDPV0();
  void CreateWorkerList(void);
};

#endif
