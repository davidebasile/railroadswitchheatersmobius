#include "rewardSwitchNetModPVNodes.h"

rewardSwitchNetModPV0Worker::rewardSwitchNetModPV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailRoadSwitchHeaterCommunicationModel);
}

rewardSwitchNetModPV0Worker::~rewardSwitchNetModPV0Worker() {
  delete [] TheModelPtr;
}

double rewardSwitchNetModPV0Worker::Reward_Function(void) {

if (priorities==4) //ALL
{
	if ((RailRoadSwitchHeaterCommunicationModel->state->Mark() >= 31) && (RailRoadSwitchHeaterCommunicationModel->state->Mark() <= 33) )
		return (double) 1/numSwitch;
}
else if (priorities==3) //LOW
{
	if (( (RailRoadSwitchHeaterCommunicationModel->state->Mark() >= 31) && (RailRoadSwitchHeaterCommunicationModel->state->Mark() <= 33) )&&
	    (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()>(phigh+pmedium))&&
         (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()<= (phigh+pmedium+plow)))
		return (double) 1/plow;
}
else if (priorities==2) //MEDIUM
{
	if ((RailRoadSwitchHeaterCommunicationModel->state->Mark() >= 31) && (RailRoadSwitchHeaterCommunicationModel->state->Mark() <= 33) &&
	    (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()>(phigh))&&
     (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()<= (phigh+pmedium)))
		return (double) 1/pmedium;
}
else if (priorities==1) //HIGH
{
	if ((RailRoadSwitchHeaterCommunicationModel->state->Mark() >= 31) && (RailRoadSwitchHeaterCommunicationModel->state->Mark() <= 33) &&
	    (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()>0)&&
          (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()<= (phigh)))
		return (double) 1/phigh;
}

return (0);



}

rewardSwitchNetModPV0::rewardSwitchNetModPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetModRJ);
  double startpts[1]={0.0};
  double stoppts[1]={26.0};
  Initialize("TimeOn",(RewardType)1,1, startpts, stoppts, timeindex, 0,2, 2);
  AddVariableDependency("state","RailRoadSwitchHeaterCommunicationModel");
  AddVariableDependency("SwitchID","RailRoadSwitchHeaterCommunicationModel");
}

rewardSwitchNetModPV0::~rewardSwitchNetModPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void rewardSwitchNetModPV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new rewardSwitchNetModPV0Worker;
}
rewardSwitchNetModPV1Worker::rewardSwitchNetModPV1Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailRoadSwitchHeaterCommunicationModel);
}

rewardSwitchNetModPV1Worker::~rewardSwitchNetModPV1Worker() {
  delete [] TheModelPtr;
}

double rewardSwitchNetModPV1Worker::Reward_Function(void) {

if (priorities==4) //ALL
{
	if ((RailRoadSwitchHeaterCommunicationModel->state->Mark()>=61)  && (RailRoadSwitchHeaterCommunicationModel->state->Mark()<=63) )
		return (double) 1/numSwitch;
}
else if (priorities==3) //LOW
{
	if (((RailRoadSwitchHeaterCommunicationModel->state->Mark()>=61)  && (RailRoadSwitchHeaterCommunicationModel->state->Mark()<=63) )&&
	    (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()>(phigh+pmedium))&&
         (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()<= (phigh+pmedium+plow)))
		return (double) 1/plow;
}
else if (priorities==2) //MEDIUM
{
	if (((RailRoadSwitchHeaterCommunicationModel->state->Mark()>=61)  && (RailRoadSwitchHeaterCommunicationModel->state->Mark()<=63) )&&
	    (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()>(phigh))&&
     (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()<= (phigh+pmedium)))
		return (double) 1/pmedium;
}
else if (priorities==1) //HIGH
{
	if (((RailRoadSwitchHeaterCommunicationModel->state->Mark()>=61)  && (RailRoadSwitchHeaterCommunicationModel->state->Mark()<=63) )&&
	    (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()>0)&&
          (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()<= (phigh)))
		return (double) 1/phigh;
}

return (0);



}

rewardSwitchNetModPV1::rewardSwitchNetModPV1(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetModRJ);
  double startpts[1]={25.0};
  double stoppts[1]={25.0};
  Initialize("Failure",(RewardType)0,1, startpts, stoppts, timeindex, 0,2, 2);
  AddVariableDependency("state","RailRoadSwitchHeaterCommunicationModel");
  AddVariableDependency("SwitchID","RailRoadSwitchHeaterCommunicationModel");
}

rewardSwitchNetModPV1::~rewardSwitchNetModPV1() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void rewardSwitchNetModPV1::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new rewardSwitchNetModPV1Worker;
}
rewardSwitchNetModPV2Worker::rewardSwitchNetModPV2Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailRoadSwitchHeaterCommunicationModel);
}

rewardSwitchNetModPV2Worker::~rewardSwitchNetModPV2Worker() {
  delete [] TheModelPtr;
}

double rewardSwitchNetModPV2Worker::Reward_Function(void) {

if (priorities==4) //ALL
{
	if  ((RailRoadSwitchHeaterCommunicationModel->state->Mark() >= 31) && (RailRoadSwitchHeaterCommunicationModel->state->Mark() <= 33) ) 
		return 1;
}
else if (priorities==3) //LOW
{
	if ( ((RailRoadSwitchHeaterCommunicationModel->state->Mark() >= 31) && (RailRoadSwitchHeaterCommunicationModel->state->Mark() <= 33) ) &&
	    (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()>(phigh+pmedium))&&
         (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()<= (phigh+pmedium+plow)))
		return 1;
}
else if (priorities==2) //MEDIUM
{
	if ( ((RailRoadSwitchHeaterCommunicationModel->state->Mark() >= 31) && (RailRoadSwitchHeaterCommunicationModel->state->Mark() <= 33) ) &&
	    (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()>(phigh))&&
     (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()<= (phigh+pmedium)))
		return 1;
}
else if (priorities==1) //HIGH
{
	if ( ((RailRoadSwitchHeaterCommunicationModel->state->Mark() >= 31) && (RailRoadSwitchHeaterCommunicationModel->state->Mark() <= 33) ) &&
	    (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()>0)&&
          (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()<= (phigh)))
		return 1;
}

return (0);



}

rewardSwitchNetModPV2::rewardSwitchNetModPV2(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetModRJ);
  double startpts[1]={HeatersAtInterval};
  double stoppts[1]={HeatersAtInterval};
  Initialize("ActivatedHeatersAtTime",(RewardType)0,1, startpts, stoppts, timeindex, 0,2, 2);
  AddVariableDependency("state","RailRoadSwitchHeaterCommunicationModel");
  AddVariableDependency("SwitchID","RailRoadSwitchHeaterCommunicationModel");
}

rewardSwitchNetModPV2::~rewardSwitchNetModPV2() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void rewardSwitchNetModPV2::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new rewardSwitchNetModPV2Worker;
}
