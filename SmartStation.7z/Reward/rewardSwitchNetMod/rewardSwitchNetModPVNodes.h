#ifndef _REWARDSWITCHNETMOD_PVS_
#define _REWARDSWITCHNETMOD_PVS_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/SwitchNetMod/SwitchNetModRJ__HeatersNetM.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__HeaterModuleM.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__RailRoadSwitchHeater.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__Controller.h"
#include "Cpp/Performance_Variables/IntervalOfTime.hpp"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"

extern Short priorities;
extern Float HeatersAtInterval;
extern Short phigh;
extern Short plow;
extern Short pmedium;

class rewardSwitchNetModPV0Worker:public IntervalOfTime
{
 public:
  RailRoadSwitchHeaterCommunicationModelSAN *RailRoadSwitchHeaterCommunicationModel;
  
  rewardSwitchNetModPV0Worker();
  ~rewardSwitchNetModPV0Worker();
  double Reward_Function();
};

class rewardSwitchNetModPV0:public PerformanceVariableNode
{
 public:
  SwitchNetModRJ *TheSwitchNetModRJ;

  rewardSwitchNetModPV0Worker *rewardSwitchNetModPV0WorkerList;

  rewardSwitchNetModPV0(int timeindex=0);
  ~rewardSwitchNetModPV0();
  void CreateWorkerList(void);
};

class rewardSwitchNetModPV1Worker:public InstantOfTime
{
 public:
  RailRoadSwitchHeaterCommunicationModelSAN *RailRoadSwitchHeaterCommunicationModel;
  
  rewardSwitchNetModPV1Worker();
  ~rewardSwitchNetModPV1Worker();
  double Reward_Function();
};

class rewardSwitchNetModPV1:public PerformanceVariableNode
{
 public:
  SwitchNetModRJ *TheSwitchNetModRJ;

  rewardSwitchNetModPV1Worker *rewardSwitchNetModPV1WorkerList;

  rewardSwitchNetModPV1(int timeindex=0);
  ~rewardSwitchNetModPV1();
  void CreateWorkerList(void);
};

class rewardSwitchNetModPV2Worker:public InstantOfTime
{
 public:
  RailRoadSwitchHeaterCommunicationModelSAN *RailRoadSwitchHeaterCommunicationModel;
  
  rewardSwitchNetModPV2Worker();
  ~rewardSwitchNetModPV2Worker();
  double Reward_Function();
};

class rewardSwitchNetModPV2:public PerformanceVariableNode
{
 public:
  SwitchNetModRJ *TheSwitchNetModRJ;

  rewardSwitchNetModPV2Worker *rewardSwitchNetModPV2WorkerList;

  rewardSwitchNetModPV2(int timeindex=0);
  ~rewardSwitchNetModPV2();
  void CreateWorkerList(void);
};

#endif
