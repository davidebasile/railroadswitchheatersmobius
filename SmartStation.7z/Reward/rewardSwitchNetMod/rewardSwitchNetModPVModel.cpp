#include "rewardSwitchNetModPVModel.h"

rewardSwitchNetModPVModel::rewardSwitchNetModPVModel(bool expandTimeArrays) {
  TheModel=new SwitchNetModRJ();
  DefineName("rewardSwitchNetModPVModel");
  CreatePVList(3, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* rewardSwitchNetModPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new rewardSwitchNetModPV0(timeindex);
    break;
  case 1:
    return new rewardSwitchNetModPV1(timeindex);
    break;
  case 2:
    return new rewardSwitchNetModPV2(timeindex);
    break;
  }
  return NULL;
}
