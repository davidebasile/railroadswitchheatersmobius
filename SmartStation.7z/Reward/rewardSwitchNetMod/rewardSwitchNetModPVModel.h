#ifndef _REWARDSWITCHNETMOD_PVMODEL_
#define _REWARDSWITCHNETMOD_PVMODEL_
#include "rewardSwitchNetModPVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Composed/SwitchNetMod/SwitchNetModRJ__HeatersNetM.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__HeaterModuleM.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__RailRoadSwitchHeater.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__Controller.h"
class rewardSwitchNetModPVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  rewardSwitchNetModPVModel(bool expandtimepoints);
};

#endif
