#ifndef _ACTIVATEDHEATERSPERTIME_PVMODEL_
#define _ACTIVATEDHEATERSPERTIME_PVMODEL_
#include "ActivatedHeatersPerTimePVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
class ActivatedHeatersPerTimePVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  ActivatedHeatersPerTimePVModel(bool expandtimepoints);
};

#endif
