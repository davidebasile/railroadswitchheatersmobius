#ifndef _ACTIVATEDHEATERSPERTIME_PVS_
#define _ACTIVATEDHEATERSPERTIME_PVS_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"

extern Short priorities;
extern Float HeatersAtInterval;
extern Short phigh;
extern Short plow;
extern Short pmedium;

class ActivatedHeatersPerTimePV0Worker:public InstantOfTime
{
 public:
  RailSwitchHeater2SAN *RailSwitchHeater2;
  
  ActivatedHeatersPerTimePV0Worker();
  ~ActivatedHeatersPerTimePV0Worker();
  double Reward_Function();
};

class ActivatedHeatersPerTimePV0:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  ActivatedHeatersPerTimePV0Worker *ActivatedHeatersPerTimePV0WorkerList;

  ActivatedHeatersPerTimePV0(int timeindex=0);
  ~ActivatedHeatersPerTimePV0();
  void CreateWorkerList(void);
};

#endif
