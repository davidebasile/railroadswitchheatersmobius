#include "ActivatedHeatersPerTimePVNodes.h"

ActivatedHeatersPerTimePV0Worker::ActivatedHeatersPerTimePV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater2);
}

ActivatedHeatersPerTimePV0Worker::~ActivatedHeatersPerTimePV0Worker() {
  delete [] TheModelPtr;
}

double ActivatedHeatersPerTimePV0Worker::Reward_Function(void) {

if (priorities==4) //ALL
{
	return RailSwitchHeater2->on->Mark();
}
else if (priorities==3) //LOW
{
	if (
	    (RailSwitchHeater2->SwitchID->Mark()>(phigh+pmedium))&&
         (RailSwitchHeater2->SwitchID->Mark()<= (phigh+pmedium+plow)))
		return RailSwitchHeater2->on->Mark();
}
else if (priorities==2) //MEDIUM
{
	if (
	    (RailSwitchHeater2->SwitchID->Mark()>(phigh))&&
     (RailSwitchHeater2->SwitchID->Mark()<= (phigh+pmedium)))
		return RailSwitchHeater2->on->Mark();
}
else if (priorities==1) //HIGH
{
	if (
	    (RailSwitchHeater2->SwitchID->Mark()>0)&&
          (RailSwitchHeater2->SwitchID->Mark()<= (phigh)))
		return RailSwitchHeater2->on->Mark();
}

return (0);



}

ActivatedHeatersPerTimePV0::ActivatedHeatersPerTimePV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={HeatersAtInterval};
  double stoppts[1]={HeatersAtInterval};
  Initialize("ActivatedHeatersAtTime",(RewardType)0,1, startpts, stoppts, timeindex, 0,2, 2);
  AddVariableDependency("on","RailSwitchHeater2");
  AddVariableDependency("SwitchID","RailSwitchHeater2");
}

ActivatedHeatersPerTimePV0::~ActivatedHeatersPerTimePV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void ActivatedHeatersPerTimePV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new ActivatedHeatersPerTimePV0Worker;
}
