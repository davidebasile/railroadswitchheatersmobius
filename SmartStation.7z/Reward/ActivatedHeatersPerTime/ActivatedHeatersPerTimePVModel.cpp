#include "ActivatedHeatersPerTimePVModel.h"

ActivatedHeatersPerTimePVModel::ActivatedHeatersPerTimePVModel(bool expandTimeArrays) {
  TheModel=new SwitchNetRJ();
  DefineName("ActivatedHeatersPerTimePVModel");
  CreatePVList(1, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* ActivatedHeatersPerTimePVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new ActivatedHeatersPerTimePV0(timeindex);
    break;
  }
  return NULL;
}
