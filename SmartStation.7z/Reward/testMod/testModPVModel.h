#ifndef _TESTMOD_PVMODEL_
#define _TESTMOD_PVMODEL_
#include "testModPVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Composed/SwitchNetMod/SwitchNetModRJ__HeatersNetM.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__HeaterModuleM.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__RailRoadSwitchHeater.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__Controller.h"
class testModPVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  testModPVModel(bool expandtimepoints);
};

#endif
