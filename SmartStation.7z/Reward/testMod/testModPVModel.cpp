#include "testModPVModel.h"

testModPVModel::testModPVModel(bool expandTimeArrays) {
  TheModel=new SwitchNetModRJ();
  DefineName("testModPVModel");
  CreatePVList(1, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* testModPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new testModPV0(timeindex);
    break;
  }
  return NULL;
}
