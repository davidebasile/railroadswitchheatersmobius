#ifndef _TESTMOD_PVS_
#define _TESTMOD_PVS_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/SwitchNetMod/SwitchNetModRJ__HeatersNetM.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__HeaterModuleM.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__RailRoadSwitchHeater.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__Controller.h"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"

extern Short ID;
extern Float Interval;

class testModPV0Worker:public InstantOfTime
{
 public:
  RailRoadSwitchHeaterCommunicationModelSAN *RailRoadSwitchHeaterCommunicationModel;
  
  testModPV0Worker();
  ~testModPV0Worker();
  double Reward_Function();
};

class testModPV0:public PerformanceVariableNode
{
 public:
  SwitchNetModRJ *TheSwitchNetModRJ;

  testModPV0Worker *testModPV0WorkerList;

  testModPV0(int timeindex=0);
  ~testModPV0();
  void CreateWorkerList(void);
};

#endif
