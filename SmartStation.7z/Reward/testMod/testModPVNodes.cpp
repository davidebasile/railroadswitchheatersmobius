#include "testModPVNodes.h"

testModPV0Worker::testModPV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailRoadSwitchHeaterCommunicationModel);
}

testModPV0Worker::~testModPV0Worker() {
  delete [] TheModelPtr;
}

double testModPV0Worker::Reward_Function(void) {

if (RailRoadSwitchHeaterCommunicationModel->SwitchID->Mark()==ID)
{
	return RailRoadSwitchHeaterCommunicationModel->state->Mark();
}

return (0);



}

testModPV0::testModPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetModRJ);
  double startpts[1]={Interval};
  double stoppts[1]={Interval};
  Initialize("ActivateHeaterAtTime",(RewardType)0,1, startpts, stoppts, timeindex, 0,2, 2);
  AddVariableDependency("SwitchID","RailRoadSwitchHeaterCommunicationModel");
  AddVariableDependency("state","RailRoadSwitchHeaterCommunicationModel");
}

testModPV0::~testModPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void testModPV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new testModPV0Worker;
}
