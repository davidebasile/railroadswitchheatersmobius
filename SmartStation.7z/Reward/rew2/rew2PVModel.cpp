#include "rew2PVModel.h"

rew2PVModel::rew2PVModel(bool expandTimeArrays) {
  TheModel=new SwitchNetRJ();
  DefineName("rew2PVModel");
  CreatePVList(1, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* rew2PVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new rew2PV0(timeindex);
    break;
  }
  return NULL;
}
