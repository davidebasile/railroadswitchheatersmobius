#ifndef _REW2_PVMODEL_
#define _REW2_PVMODEL_
#include "rew2PVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Composed/SwitchNet/SwitchNetRJ.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
class rew2PVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  rew2PVModel(bool expandtimepoints);
};

#endif
