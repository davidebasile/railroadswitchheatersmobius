#include "rew2PVNodes.h"

rew2PV0Worker::rew2PV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater2);
}

rew2PV0Worker::~rew2PV0Worker() {
  delete [] TheModelPtr;
}

double rew2PV0Worker::Reward_Function(void) {

return (double) RailSwitchHeater2->sharedOn->Mark()/numSwitch;

return (0);



}

rew2PV0::rew2PV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={HeatersAtInterval};
  double stoppts[1]={HeatersAtInterval};
  Initialize("ActivatedHeatersAtTime",(RewardType)0,1, startpts, stoppts, timeindex, 0,1, 1);
  AddVariableDependency("sharedOn","RailSwitchHeater2");
}

rew2PV0::~rew2PV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void rew2PV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new rew2PV0Worker;
}
