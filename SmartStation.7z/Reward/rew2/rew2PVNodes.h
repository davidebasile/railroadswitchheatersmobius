#ifndef _REW2_PVS_
#define _REW2_PVS_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/SwitchNet/SwitchNetRJ.h"
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"

extern Short HeatersAtInterval;

class rew2PV0Worker:public InstantOfTime
{
 public:
  RailSwitchHeater2SAN *RailSwitchHeater2;
  
  rew2PV0Worker();
  ~rew2PV0Worker();
  double Reward_Function();
};

class rew2PV0:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  rew2PV0Worker *rew2PV0WorkerList;

  rew2PV0(int timeindex=0);
  ~rew2PV0();
  void CreateWorkerList(void);
};

#endif
