#ifndef _TEST_PVMODEL_
#define _TEST_PVMODEL_
#include "testPVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__HeatersNetM.h"
#include "Composed/SwitchNet/SwitchNetRJ__HeaterModuleM.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
class testPVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  testPVModel(bool expandtimepoints);
};

#endif
