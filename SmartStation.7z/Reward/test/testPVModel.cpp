#include "testPVModel.h"

testPVModel::testPVModel(bool expandTimeArrays) {
  TheModel=new SwitchNetRJ();
  DefineName("testPVModel");
  CreatePVList(1, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* testPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new testPV0(timeindex);
    break;
  }
  return NULL;
}
