#ifndef _TEST_PVS_
#define _TEST_PVS_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/SwitchNet/SwitchNetRJ__HeatersNetM.h"
#include "Composed/SwitchNet/SwitchNetRJ__HeaterModuleM.h"
#include "Composed/SwitchNet/SwitchNetRJ.h"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"

extern Short ID;
extern Float Interval;

class testPV0Worker:public InstantOfTime
{
 public:
  RailSwitchHeater2SAN *RailRoadSwitchHeater;
  
  testPV0Worker();
  ~testPV0Worker();
  double Reward_Function();
};

class testPV0:public PerformanceVariableNode
{
 public:
  SwitchNetRJ *TheSwitchNetRJ;

  testPV0Worker *testPV0WorkerList;

  testPV0(int timeindex=0);
  ~testPV0();
  void CreateWorkerList(void);
};

#endif
