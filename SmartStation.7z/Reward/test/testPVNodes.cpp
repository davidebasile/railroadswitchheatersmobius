#include "testPVNodes.h"

testPV0Worker::testPV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailRoadSwitchHeater);
}

testPV0Worker::~testPV0Worker() {
  delete [] TheModelPtr;
}

double testPV0Worker::Reward_Function(void) {

if (RailRoadSwitchHeater->SwitchID->Mark()==ID)
{
	if (RailRoadSwitchHeater->ready->Mark()==1)
		return 1;
	else if (RailRoadSwitchHeater->on->Mark()==1)
		return 2;
	else if (RailRoadSwitchHeater->off->Mark()==1)
		return 0;
	else if (RailRoadSwitchHeater->failure->Mark()==1)
		return -1;	
}

return (0);



}

testPV0::testPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheSwitchNetRJ);
  double startpts[1]={Interval};
  double stoppts[1]={Interval};
  Initialize("ActivateHeaterAtTime",(RewardType)0,1, startpts, stoppts, timeindex, 0,5, 5);
  AddVariableDependency("SwitchID","RailRoadSwitchHeater");
  AddVariableDependency("ready","RailRoadSwitchHeater");
  AddVariableDependency("on","RailRoadSwitchHeater");
  AddVariableDependency("off","RailRoadSwitchHeater");
  AddVariableDependency("failure","RailRoadSwitchHeater");
}

testPV0::~testPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void testPV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new testPV0Worker;
}
