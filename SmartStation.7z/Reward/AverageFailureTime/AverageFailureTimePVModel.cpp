#include "AverageFailureTimePVModel.h"

AverageFailureTimePVModel::AverageFailureTimePVModel(bool expandTimeArrays) {
  TheModel=new Rail2RJ();
  DefineName("AverageFailureTimePVModel");
  CreatePVList(1, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* AverageFailureTimePVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new AverageFailureTimePV0(timeindex);
    break;
  }
  return NULL;
}
