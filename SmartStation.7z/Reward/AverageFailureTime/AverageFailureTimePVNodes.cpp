#include "AverageFailureTimePVNodes.h"

AverageFailureTimePV0Worker::AverageFailureTimePV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&RailSwitchHeater);
}

AverageFailureTimePV0Worker::~AverageFailureTimePV0Worker() {
  delete [] TheModelPtr;
}

double AverageFailureTimePV0Worker::Reward_Function(void) {

if (RailSwitchHeater->failure->Mark()==numHeater)
	return 1;

return (0);



}

AverageFailureTimePV0::AverageFailureTimePV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheRail2RJ);
  double startpts[1]={0};
  double stoppts[1]={30};
  Initialize("TimeToFailure",(RewardType)1,1, startpts, stoppts, timeindex, 0,1, 1);
  AddVariableDependency("failure","RailSwitchHeater");
}

AverageFailureTimePV0::~AverageFailureTimePV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void AverageFailureTimePV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new AverageFailureTimePV0Worker;
}
