#ifndef _AVERAGEFAILURETIME_PVS_
#define _AVERAGEFAILURETIME_PVS_
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/Rail2/Rail2RJ__Rep1.h"
#include "Composed/Rail2/Rail2RJ.h"
#include "Cpp/Performance_Variables/IntervalOfTime.hpp"


class AverageFailureTimePV0Worker:public IntervalOfTime
{
 public:
  RailSwitchHeaterSAN *RailSwitchHeater;
  
  AverageFailureTimePV0Worker();
  ~AverageFailureTimePV0Worker();
  double Reward_Function();
};

class AverageFailureTimePV0:public PerformanceVariableNode
{
 public:
  Rail2RJ *TheRail2RJ;

  AverageFailureTimePV0Worker *AverageFailureTimePV0WorkerList;

  AverageFailureTimePV0(int timeindex=0);
  ~AverageFailureTimePV0();
  void CreateWorkerList(void);
};

#endif
