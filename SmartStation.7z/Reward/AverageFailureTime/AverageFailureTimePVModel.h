#ifndef _AVERAGEFAILURETIME_PVMODEL_
#define _AVERAGEFAILURETIME_PVMODEL_
#include "AverageFailureTimePVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Composed/Rail2/Rail2RJ__Rep1.h"
#include "Composed/Rail2/Rail2RJ.h"
class AverageFailureTimePVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  AverageFailureTimePVModel(bool expandtimepoints);
};

#endif
