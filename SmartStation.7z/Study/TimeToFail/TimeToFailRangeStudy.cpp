
#include "Study/TimeToFail/TimeToFailRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
Float TimeToAlert;
Float TimeToHeatRate;
Short capacity;
Short numHeater;

//********************************************************
//TimeToFailRangeStudy Constructor
//********************************************************
TimeToFailRangeStudy::TimeToFailRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 4;
  NumExps = 1;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("TimeToAlert");
  GVTypes[0]=strdup("float");
  GVNames[1]=strdup("TimeToHeatRate");
  GVTypes[1]=strdup("float");
  GVNames[2]=strdup("capacity");
  GVTypes[2]=strdup("short");
  GVNames[3]=strdup("numHeater");
  GVTypes[3]=strdup("short");

  // create the arrays to store the values of each gv
  TimeToAlertValues = new float[NumExps];
  TimeToHeatRateValues = new float[NumExps];
  capacityValues = new short[NumExps];
  numHeaterValues = new short[NumExps];

  // call methods to assign values to each gv
  SetValues_TimeToAlert();
  SetValues_TimeToHeatRate();
  SetValues_capacity();
  SetValues_numHeater();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//TimeToFailRangeStudy Destructor
//******************************************************
TimeToFailRangeStudy::~TimeToFailRangeStudy() {
  delete [] TimeToAlertValues;
  delete [] TimeToHeatRateValues;
  delete [] capacityValues;
  delete [] numHeaterValues;
  delete ThePVModel;
}


//******************************************************
// set values for TimeToAlert
//******************************************************
void TimeToFailRangeStudy::SetValues_TimeToAlert() {
  TimeToAlertValues[0] = 0.6;
}


//******************************************************
// set values for TimeToHeatRate
//******************************************************
void TimeToFailRangeStudy::SetValues_TimeToHeatRate() {
  TimeToHeatRateValues[0] = 0.7;
}


//******************************************************
// set values for capacity
//******************************************************
void TimeToFailRangeStudy::SetValues_capacity() {
  capacityValues[0] = 3;
}


//******************************************************
// set values for numHeater
//******************************************************
void TimeToFailRangeStudy::SetValues_numHeater() {
  numHeaterValues[0] = 2;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void TimeToFailRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "TimeToAlert\tfloat\t" << TimeToAlert << endl;
  cout << "TimeToHeatRate\tfloat\t" << TimeToHeatRate << endl;
  cout << "capacity\tshort\t" << capacity << endl;
  cout << "numHeater\tshort\t" << numHeater << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *TimeToFailRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("TimeToAlert", TheGVName) == 0)
    return &TimeToAlert;
  else if (strcmp("TimeToHeatRate", TheGVName) == 0)
    return &TimeToHeatRate;
  else if (strcmp("capacity", TheGVName) == 0)
    return &capacity;
  else if (strcmp("numHeater", TheGVName) == 0)
    return &numHeater;
  else 
    cerr<<"!! TimeToFailRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void TimeToFailRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("TimeToAlert", TheGVName) == 0)
    SetGvValue(TimeToAlert, *(float *)TheGVValue);
  else if (strcmp("TimeToHeatRate", TheGVName) == 0)
    SetGvValue(TimeToHeatRate, *(float *)TheGVValue);
  else if (strcmp("capacity", TheGVName) == 0)
    SetGvValue(capacity, *(short *)TheGVValue);
  else if (strcmp("numHeater", TheGVName) == 0)
    SetGvValue(numHeater, *(short *)TheGVValue);
  else 
    cerr<<"!! TimeToFailRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void TimeToFailRangeStudy::SetGVs(int expNum) {
  SetGvValue(TimeToAlert, TimeToAlertValues[expNum]);
  SetGvValue(TimeToHeatRate, TimeToHeatRateValues[expNum]);
  SetGvValue(capacity, capacityValues[expNum]);
  SetGvValue(numHeater, numHeaterValues[expNum]);
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new TimeToFailRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* TimeToFailRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new AverageFailureTimePVModel(expandTimeArrays);
  return ThePVModel;
}


