
#ifndef TimeToFailRangeSTUDY_H_
#define TimeToFailRangeSTUDY_H_

#include "Reward/AverageFailureTime/AverageFailureTimePVNodes.h"
#include "Reward/AverageFailureTime/AverageFailureTimePVModel.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/Study/BaseStudyClass.hpp"

extern Float TimeToAlert;
extern Float TimeToHeatRate;
extern Short capacity;
extern Short numHeater;

class TimeToFailRangeStudy : public BaseStudyClass {
public:

TimeToFailRangeStudy();
~TimeToFailRangeStudy();

private:

float *TimeToAlertValues;
float *TimeToHeatRateValues;
short *capacityValues;
short *numHeaterValues;

void SetValues_TimeToAlert();
void SetValues_TimeToHeatRate();
void SetValues_capacity();
void SetValues_numHeater();

void PrintGlobalValues(int);
void *GetGVValue(char *TheGVName);
void OverrideGVValue(char *TheGVName, void *TheGVValue);
void SetGVs(int expnum);
PVModel *GetPVModel(bool expandTimeArrays);
};

#endif

