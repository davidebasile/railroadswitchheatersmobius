
#ifndef sharedOnTestRangeSTUDY_H_
#define sharedOnTestRangeSTUDY_H_

#include "Reward/prova/provaPVNodes.h"
#include "Reward/prova/provaPVModel.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/Study/BaseStudyClass.hpp"

extern Float HeatersAtInterval;
extern Short TimeClock;
extern Float freezingThreshold;
extern Short initialInternalTemperature;
extern Short numSwitch;
extern Short phigh;
extern Short plow;
extern Short pmedium;
extern Short queueSize;
extern Float warningThreshold;
extern Float workingTemperature;

class sharedOnTestRangeStudy : public BaseStudyClass {
public:

sharedOnTestRangeStudy();
~sharedOnTestRangeStudy();

private:

float *HeatersAtIntervalValues;
short *TimeClockValues;
float *freezingThresholdValues;
short *initialInternalTemperatureValues;
short *numSwitchValues;
short *phighValues;
short *plowValues;
short *pmediumValues;
short *queueSizeValues;
float *warningThresholdValues;
float *workingTemperatureValues;

void SetValues_HeatersAtInterval();
void SetValues_TimeClock();
void SetValues_freezingThreshold();
void SetValues_initialInternalTemperature();
void SetValues_numSwitch();
void SetValues_phigh();
void SetValues_plow();
void SetValues_pmedium();
void SetValues_queueSize();
void SetValues_warningThreshold();
void SetValues_workingTemperature();

void PrintGlobalValues(int);
void *GetGVValue(char *TheGVName);
void OverrideGVValue(char *TheGVName, void *TheGVValue);
void SetGVs(int expnum);
PVModel *GetPVModel(bool expandTimeArrays);
};

#endif

