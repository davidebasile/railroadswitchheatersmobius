
#include "Study/sharedOnTest/sharedOnTestRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
Float HeatersAtInterval;
Short TimeClock;
Float freezingThreshold;
Short initialInternalTemperature;
Short numSwitch;
Short phigh;
Short plow;
Short pmedium;
Short queueSize;
Float warningThreshold;
Float workingTemperature;

//********************************************************
//sharedOnTestRangeStudy Constructor
//********************************************************
sharedOnTestRangeStudy::sharedOnTestRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 11;
  NumExps = 23;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("HeatersAtInterval");
  GVTypes[0]=strdup("float");
  GVNames[1]=strdup("TimeClock");
  GVTypes[1]=strdup("short");
  GVNames[2]=strdup("freezingThreshold");
  GVTypes[2]=strdup("float");
  GVNames[3]=strdup("initialInternalTemperature");
  GVTypes[3]=strdup("short");
  GVNames[4]=strdup("numSwitch");
  GVTypes[4]=strdup("short");
  GVNames[5]=strdup("phigh");
  GVTypes[5]=strdup("short");
  GVNames[6]=strdup("plow");
  GVTypes[6]=strdup("short");
  GVNames[7]=strdup("pmedium");
  GVTypes[7]=strdup("short");
  GVNames[8]=strdup("queueSize");
  GVTypes[8]=strdup("short");
  GVNames[9]=strdup("warningThreshold");
  GVTypes[9]=strdup("float");
  GVNames[10]=strdup("workingTemperature");
  GVTypes[10]=strdup("float");

  // create the arrays to store the values of each gv
  HeatersAtIntervalValues = new float[NumExps];
  TimeClockValues = new short[NumExps];
  freezingThresholdValues = new float[NumExps];
  initialInternalTemperatureValues = new short[NumExps];
  numSwitchValues = new short[NumExps];
  phighValues = new short[NumExps];
  plowValues = new short[NumExps];
  pmediumValues = new short[NumExps];
  queueSizeValues = new short[NumExps];
  warningThresholdValues = new float[NumExps];
  workingTemperatureValues = new float[NumExps];

  // call methods to assign values to each gv
  SetValues_HeatersAtInterval();
  SetValues_TimeClock();
  SetValues_freezingThreshold();
  SetValues_initialInternalTemperature();
  SetValues_numSwitch();
  SetValues_phigh();
  SetValues_plow();
  SetValues_pmedium();
  SetValues_queueSize();
  SetValues_warningThreshold();
  SetValues_workingTemperature();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//sharedOnTestRangeStudy Destructor
//******************************************************
sharedOnTestRangeStudy::~sharedOnTestRangeStudy() {
  delete [] HeatersAtIntervalValues;
  delete [] TimeClockValues;
  delete [] freezingThresholdValues;
  delete [] initialInternalTemperatureValues;
  delete [] numSwitchValues;
  delete [] phighValues;
  delete [] plowValues;
  delete [] pmediumValues;
  delete [] queueSizeValues;
  delete [] warningThresholdValues;
  delete [] workingTemperatureValues;
  delete ThePVModel;
}


//******************************************************
// set values for HeatersAtInterval
//******************************************************
void sharedOnTestRangeStudy::SetValues_HeatersAtInterval() {
  HeatersAtIntervalValues[0] = 1.5;
  HeatersAtIntervalValues[1] = 2.5;
  HeatersAtIntervalValues[2] = 3.5;
  HeatersAtIntervalValues[3] = 4.5;
  HeatersAtIntervalValues[4] = 5.5;
  HeatersAtIntervalValues[5] = 6.5;
  HeatersAtIntervalValues[6] = 7.5;
  HeatersAtIntervalValues[7] = 8.5;
  HeatersAtIntervalValues[8] = 9.5;
  HeatersAtIntervalValues[9] = 10.5;
  HeatersAtIntervalValues[10] = 11.5;
  HeatersAtIntervalValues[11] = 12.5;
  HeatersAtIntervalValues[12] = 13.5;
  HeatersAtIntervalValues[13] = 14.5;
  HeatersAtIntervalValues[14] = 15.5;
  HeatersAtIntervalValues[15] = 16.5;
  HeatersAtIntervalValues[16] = 17.5;
  HeatersAtIntervalValues[17] = 18.5;
  HeatersAtIntervalValues[18] = 19.5;
  HeatersAtIntervalValues[19] = 20.5;
  HeatersAtIntervalValues[20] = 21.5;
  HeatersAtIntervalValues[21] = 22.5;
  HeatersAtIntervalValues[22] = 23.5;
}


//******************************************************
// set values for TimeClock
//******************************************************
void sharedOnTestRangeStudy::SetValues_TimeClock() {
  for (int n=0; n<NumExps; n++)
    TimeClockValues[n] = 1;
}


//******************************************************
// set values for freezingThreshold
//******************************************************
void sharedOnTestRangeStudy::SetValues_freezingThreshold() {
  for (int n=0; n<NumExps; n++)
    freezingThresholdValues[n] = 0;
}


//******************************************************
// set values for initialInternalTemperature
//******************************************************
void sharedOnTestRangeStudy::SetValues_initialInternalTemperature() {
  for (int n=0; n<NumExps; n++)
    initialInternalTemperatureValues[n] = 5;
}


//******************************************************
// set values for numSwitch
//******************************************************
void sharedOnTestRangeStudy::SetValues_numSwitch() {
  for (int n=0; n<NumExps; n++)
    numSwitchValues[n] = 6;
}


//******************************************************
// set values for phigh
//******************************************************
void sharedOnTestRangeStudy::SetValues_phigh() {
  for (int n=0; n<NumExps; n++)
    phighValues[n] = 1;
}


//******************************************************
// set values for plow
//******************************************************
void sharedOnTestRangeStudy::SetValues_plow() {
  for (int n=0; n<NumExps; n++)
    plowValues[n] = 1;
}


//******************************************************
// set values for pmedium
//******************************************************
void sharedOnTestRangeStudy::SetValues_pmedium() {
  for (int n=0; n<NumExps; n++)
    pmediumValues[n] = 4;
}


//******************************************************
// set values for queueSize
//******************************************************
void sharedOnTestRangeStudy::SetValues_queueSize() {
  for (int n=0; n<NumExps; n++)
    queueSizeValues[n] = 2;
}


//******************************************************
// set values for warningThreshold
//******************************************************
void sharedOnTestRangeStudy::SetValues_warningThreshold() {
  for (int n=0; n<NumExps; n++)
    warningThresholdValues[n] = 3.0;
}


//******************************************************
// set values for workingTemperature
//******************************************************
void sharedOnTestRangeStudy::SetValues_workingTemperature() {
  for (int n=0; n<NumExps; n++)
    workingTemperatureValues[n] = 8.0;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void sharedOnTestRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "HeatersAtInterval\tfloat\t" << HeatersAtInterval << endl;
  cout << "TimeClock\tshort\t" << TimeClock << endl;
  cout << "freezingThreshold\tfloat\t" << freezingThreshold << endl;
  cout << "initialInternalTemperature\tshort\t" << initialInternalTemperature << endl;
  cout << "numSwitch\tshort\t" << numSwitch << endl;
  cout << "phigh\tshort\t" << phigh << endl;
  cout << "plow\tshort\t" << plow << endl;
  cout << "pmedium\tshort\t" << pmedium << endl;
  cout << "queueSize\tshort\t" << queueSize << endl;
  cout << "warningThreshold\tfloat\t" << warningThreshold << endl;
  cout << "workingTemperature\tfloat\t" << workingTemperature << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *sharedOnTestRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("HeatersAtInterval", TheGVName) == 0)
    return &HeatersAtInterval;
  else if (strcmp("TimeClock", TheGVName) == 0)
    return &TimeClock;
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    return &freezingThreshold;
  else if (strcmp("initialInternalTemperature", TheGVName) == 0)
    return &initialInternalTemperature;
  else if (strcmp("numSwitch", TheGVName) == 0)
    return &numSwitch;
  else if (strcmp("phigh", TheGVName) == 0)
    return &phigh;
  else if (strcmp("plow", TheGVName) == 0)
    return &plow;
  else if (strcmp("pmedium", TheGVName) == 0)
    return &pmedium;
  else if (strcmp("queueSize", TheGVName) == 0)
    return &queueSize;
  else if (strcmp("warningThreshold", TheGVName) == 0)
    return &warningThreshold;
  else if (strcmp("workingTemperature", TheGVName) == 0)
    return &workingTemperature;
  else 
    cerr<<"!! sharedOnTestRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void sharedOnTestRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("HeatersAtInterval", TheGVName) == 0)
    SetGvValue(HeatersAtInterval, *(float *)TheGVValue);
  else if (strcmp("TimeClock", TheGVName) == 0)
    SetGvValue(TimeClock, *(short *)TheGVValue);
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    SetGvValue(freezingThreshold, *(float *)TheGVValue);
  else if (strcmp("initialInternalTemperature", TheGVName) == 0)
    SetGvValue(initialInternalTemperature, *(short *)TheGVValue);
  else if (strcmp("numSwitch", TheGVName) == 0)
    SetGvValue(numSwitch, *(short *)TheGVValue);
  else if (strcmp("phigh", TheGVName) == 0)
    SetGvValue(phigh, *(short *)TheGVValue);
  else if (strcmp("plow", TheGVName) == 0)
    SetGvValue(plow, *(short *)TheGVValue);
  else if (strcmp("pmedium", TheGVName) == 0)
    SetGvValue(pmedium, *(short *)TheGVValue);
  else if (strcmp("queueSize", TheGVName) == 0)
    SetGvValue(queueSize, *(short *)TheGVValue);
  else if (strcmp("warningThreshold", TheGVName) == 0)
    SetGvValue(warningThreshold, *(float *)TheGVValue);
  else if (strcmp("workingTemperature", TheGVName) == 0)
    SetGvValue(workingTemperature, *(float *)TheGVValue);
  else 
    cerr<<"!! sharedOnTestRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void sharedOnTestRangeStudy::SetGVs(int expNum) {
  SetGvValue(HeatersAtInterval, HeatersAtIntervalValues[expNum]);
  SetGvValue(TimeClock, TimeClockValues[expNum]);
  SetGvValue(freezingThreshold, freezingThresholdValues[expNum]);
  SetGvValue(initialInternalTemperature, initialInternalTemperatureValues[expNum]);
  SetGvValue(numSwitch, numSwitchValues[expNum]);
  SetGvValue(phigh, phighValues[expNum]);
  SetGvValue(plow, plowValues[expNum]);
  SetGvValue(pmedium, pmediumValues[expNum]);
  SetGvValue(queueSize, queueSizeValues[expNum]);
  SetGvValue(warningThreshold, warningThresholdValues[expNum]);
  SetGvValue(workingTemperature, workingTemperatureValues[expNum]);
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new sharedOnTestRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* sharedOnTestRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new provaPVModel(expandTimeArrays);
  return ThePVModel;
}


