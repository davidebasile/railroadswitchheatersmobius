
#include "Study/carlislePriorityHeaterPerTimeID/carlislePriorityHeaterPerTimeIDRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
Float HeatersAtInterval;
Short IdThreshold;
Short TimeClock;
Float freezingThreshold;
Short gapThreshold;
Short numSwitch;
Short phigh;
Short plow;
Short pmedium;
Short queueSize;
Float warningThreshold;

//********************************************************
//carlislePriorityHeaterPerTimeIDRangeStudy Constructor
//********************************************************
carlislePriorityHeaterPerTimeIDRangeStudy::carlislePriorityHeaterPerTimeIDRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 11;
  NumExps = 75;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("HeatersAtInterval");
  GVTypes[0]=strdup("float");
  GVNames[1]=strdup("IdThreshold");
  GVTypes[1]=strdup("short");
  GVNames[2]=strdup("TimeClock");
  GVTypes[2]=strdup("short");
  GVNames[3]=strdup("freezingThreshold");
  GVTypes[3]=strdup("float");
  GVNames[4]=strdup("gapThreshold");
  GVTypes[4]=strdup("short");
  GVNames[5]=strdup("numSwitch");
  GVTypes[5]=strdup("short");
  GVNames[6]=strdup("phigh");
  GVTypes[6]=strdup("short");
  GVNames[7]=strdup("plow");
  GVTypes[7]=strdup("short");
  GVNames[8]=strdup("pmedium");
  GVTypes[8]=strdup("short");
  GVNames[9]=strdup("queueSize");
  GVTypes[9]=strdup("short");
  GVNames[10]=strdup("warningThreshold");
  GVTypes[10]=strdup("float");

  // create the arrays to store the values of each gv
  HeatersAtIntervalValues = new float[NumExps];
  IdThresholdValues = new short[NumExps];
  TimeClockValues = new short[NumExps];
  freezingThresholdValues = new float[NumExps];
  gapThresholdValues = new short[NumExps];
  numSwitchValues = new short[NumExps];
  phighValues = new short[NumExps];
  plowValues = new short[NumExps];
  pmediumValues = new short[NumExps];
  queueSizeValues = new short[NumExps];
  warningThresholdValues = new float[NumExps];

  // call methods to assign values to each gv
  SetValues_HeatersAtInterval();
  SetValues_IdThreshold();
  SetValues_TimeClock();
  SetValues_freezingThreshold();
  SetValues_gapThreshold();
  SetValues_numSwitch();
  SetValues_phigh();
  SetValues_plow();
  SetValues_pmedium();
  SetValues_queueSize();
  SetValues_warningThreshold();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//carlislePriorityHeaterPerTimeIDRangeStudy Destructor
//******************************************************
carlislePriorityHeaterPerTimeIDRangeStudy::~carlislePriorityHeaterPerTimeIDRangeStudy() {
  delete [] HeatersAtIntervalValues;
  delete [] IdThresholdValues;
  delete [] TimeClockValues;
  delete [] freezingThresholdValues;
  delete [] gapThresholdValues;
  delete [] numSwitchValues;
  delete [] phighValues;
  delete [] plowValues;
  delete [] pmediumValues;
  delete [] queueSizeValues;
  delete [] warningThresholdValues;
  delete ThePVModel;
}


//******************************************************
// set values for HeatersAtInterval
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetValues_HeatersAtInterval() {
  HeatersAtIntervalValues[0] = 1.5;
  HeatersAtIntervalValues[1] = 2.5;
  HeatersAtIntervalValues[2] = 3.5;
  HeatersAtIntervalValues[3] = 4.5;
  HeatersAtIntervalValues[4] = 5.5;
  HeatersAtIntervalValues[5] = 6.5;
  HeatersAtIntervalValues[6] = 7.5;
  HeatersAtIntervalValues[7] = 8.5;
  HeatersAtIntervalValues[8] = 9.5;
  HeatersAtIntervalValues[9] = 10.5;
  HeatersAtIntervalValues[10] = 11.5;
  HeatersAtIntervalValues[11] = 12.5;
  HeatersAtIntervalValues[12] = 13.5;
  HeatersAtIntervalValues[13] = 14.5;
  HeatersAtIntervalValues[14] = 15.5;
  HeatersAtIntervalValues[15] = 16.5;
  HeatersAtIntervalValues[16] = 17.5;
  HeatersAtIntervalValues[17] = 18.5;
  HeatersAtIntervalValues[18] = 19.5;
  HeatersAtIntervalValues[19] = 20.5;
  HeatersAtIntervalValues[20] = 21.5;
  HeatersAtIntervalValues[21] = 22.5;
  HeatersAtIntervalValues[22] = 23.5;
  HeatersAtIntervalValues[23] = 24.5;
  HeatersAtIntervalValues[24] = 25.5;
  HeatersAtIntervalValues[25] = 1.5;
  HeatersAtIntervalValues[26] = 2.5;
  HeatersAtIntervalValues[27] = 3.5;
  HeatersAtIntervalValues[28] = 4.5;
  HeatersAtIntervalValues[29] = 5.5;
  HeatersAtIntervalValues[30] = 6.5;
  HeatersAtIntervalValues[31] = 7.5;
  HeatersAtIntervalValues[32] = 8.5;
  HeatersAtIntervalValues[33] = 9.5;
  HeatersAtIntervalValues[34] = 10.5;
  HeatersAtIntervalValues[35] = 11.5;
  HeatersAtIntervalValues[36] = 12.5;
  HeatersAtIntervalValues[37] = 13.5;
  HeatersAtIntervalValues[38] = 14.5;
  HeatersAtIntervalValues[39] = 15.5;
  HeatersAtIntervalValues[40] = 16.5;
  HeatersAtIntervalValues[41] = 17.5;
  HeatersAtIntervalValues[42] = 18.5;
  HeatersAtIntervalValues[43] = 19.5;
  HeatersAtIntervalValues[44] = 20.5;
  HeatersAtIntervalValues[45] = 21.5;
  HeatersAtIntervalValues[46] = 22.5;
  HeatersAtIntervalValues[47] = 23.5;
  HeatersAtIntervalValues[48] = 24.5;
  HeatersAtIntervalValues[49] = 25.5;
  HeatersAtIntervalValues[50] = 1.5;
  HeatersAtIntervalValues[51] = 2.5;
  HeatersAtIntervalValues[52] = 3.5;
  HeatersAtIntervalValues[53] = 4.5;
  HeatersAtIntervalValues[54] = 5.5;
  HeatersAtIntervalValues[55] = 6.5;
  HeatersAtIntervalValues[56] = 7.5;
  HeatersAtIntervalValues[57] = 8.5;
  HeatersAtIntervalValues[58] = 9.5;
  HeatersAtIntervalValues[59] = 10.5;
  HeatersAtIntervalValues[60] = 11.5;
  HeatersAtIntervalValues[61] = 12.5;
  HeatersAtIntervalValues[62] = 13.5;
  HeatersAtIntervalValues[63] = 14.5;
  HeatersAtIntervalValues[64] = 15.5;
  HeatersAtIntervalValues[65] = 16.5;
  HeatersAtIntervalValues[66] = 17.5;
  HeatersAtIntervalValues[67] = 18.5;
  HeatersAtIntervalValues[68] = 19.5;
  HeatersAtIntervalValues[69] = 20.5;
  HeatersAtIntervalValues[70] = 21.5;
  HeatersAtIntervalValues[71] = 22.5;
  HeatersAtIntervalValues[72] = 23.5;
  HeatersAtIntervalValues[73] = 24.5;
  HeatersAtIntervalValues[74] = 25.5;
}


//******************************************************
// set values for IdThreshold
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetValues_IdThreshold() {
  IdThresholdValues[0] = 23;
  IdThresholdValues[1] = 23;
  IdThresholdValues[2] = 23;
  IdThresholdValues[3] = 23;
  IdThresholdValues[4] = 23;
  IdThresholdValues[5] = 23;
  IdThresholdValues[6] = 23;
  IdThresholdValues[7] = 23;
  IdThresholdValues[8] = 23;
  IdThresholdValues[9] = 23;
  IdThresholdValues[10] = 23;
  IdThresholdValues[11] = 23;
  IdThresholdValues[12] = 23;
  IdThresholdValues[13] = 23;
  IdThresholdValues[14] = 23;
  IdThresholdValues[15] = 23;
  IdThresholdValues[16] = 23;
  IdThresholdValues[17] = 23;
  IdThresholdValues[18] = 23;
  IdThresholdValues[19] = 23;
  IdThresholdValues[20] = 23;
  IdThresholdValues[21] = 23;
  IdThresholdValues[22] = 23;
  IdThresholdValues[23] = 23;
  IdThresholdValues[24] = 23;
  IdThresholdValues[25] = 12;
  IdThresholdValues[26] = 12;
  IdThresholdValues[27] = 12;
  IdThresholdValues[28] = 12;
  IdThresholdValues[29] = 12;
  IdThresholdValues[30] = 12;
  IdThresholdValues[31] = 12;
  IdThresholdValues[32] = 12;
  IdThresholdValues[33] = 12;
  IdThresholdValues[34] = 12;
  IdThresholdValues[35] = 12;
  IdThresholdValues[36] = 12;
  IdThresholdValues[37] = 12;
  IdThresholdValues[38] = 12;
  IdThresholdValues[39] = 12;
  IdThresholdValues[40] = 12;
  IdThresholdValues[41] = 12;
  IdThresholdValues[42] = 12;
  IdThresholdValues[43] = 12;
  IdThresholdValues[44] = 12;
  IdThresholdValues[45] = 12;
  IdThresholdValues[46] = 12;
  IdThresholdValues[47] = 12;
  IdThresholdValues[48] = 12;
  IdThresholdValues[49] = 12;
  IdThresholdValues[50] = 6;
  IdThresholdValues[51] = 6;
  IdThresholdValues[52] = 6;
  IdThresholdValues[53] = 6;
  IdThresholdValues[54] = 6;
  IdThresholdValues[55] = 6;
  IdThresholdValues[56] = 6;
  IdThresholdValues[57] = 6;
  IdThresholdValues[58] = 6;
  IdThresholdValues[59] = 6;
  IdThresholdValues[60] = 6;
  IdThresholdValues[61] = 6;
  IdThresholdValues[62] = 6;
  IdThresholdValues[63] = 6;
  IdThresholdValues[64] = 6;
  IdThresholdValues[65] = 6;
  IdThresholdValues[66] = 6;
  IdThresholdValues[67] = 6;
  IdThresholdValues[68] = 6;
  IdThresholdValues[69] = 6;
  IdThresholdValues[70] = 6;
  IdThresholdValues[71] = 6;
  IdThresholdValues[72] = 6;
  IdThresholdValues[73] = 6;
  IdThresholdValues[74] = 6;
}


//******************************************************
// set values for TimeClock
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetValues_TimeClock() {
  for (int n=0; n<NumExps; n++)
    TimeClockValues[n] = 1;
}


//******************************************************
// set values for freezingThreshold
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetValues_freezingThreshold() {
  for (int n=0; n<NumExps; n++)
    freezingThresholdValues[n] = 0.0;
}


//******************************************************
// set values for gapThreshold
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetValues_gapThreshold() {
  for (int n=0; n<NumExps; n++)
    gapThresholdValues[n] = 1;
}


//******************************************************
// set values for numSwitch
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetValues_numSwitch() {
  for (int n=0; n<NumExps; n++)
    numSwitchValues[n] = 41;
}


//******************************************************
// set values for phigh
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetValues_phigh() {
  for (int n=0; n<NumExps; n++)
    phighValues[n] = 41;
}


//******************************************************
// set values for plow
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetValues_plow() {
  for (int n=0; n<NumExps; n++)
    plowValues[n] = 0;
}


//******************************************************
// set values for pmedium
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetValues_pmedium() {
  for (int n=0; n<NumExps; n++)
    pmediumValues[n] = 0;
}


//******************************************************
// set values for queueSize
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetValues_queueSize() {
  for (int n=0; n<NumExps; n++)
    queueSizeValues[n] = 21;
}


//******************************************************
// set values for warningThreshold
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetValues_warningThreshold() {
  for (int n=0; n<NumExps; n++)
    warningThresholdValues[n] = 7.0;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "HeatersAtInterval\tfloat\t" << HeatersAtInterval << endl;
  cout << "IdThreshold\tshort\t" << IdThreshold << endl;
  cout << "TimeClock\tshort\t" << TimeClock << endl;
  cout << "freezingThreshold\tfloat\t" << freezingThreshold << endl;
  cout << "gapThreshold\tshort\t" << gapThreshold << endl;
  cout << "numSwitch\tshort\t" << numSwitch << endl;
  cout << "phigh\tshort\t" << phigh << endl;
  cout << "plow\tshort\t" << plow << endl;
  cout << "pmedium\tshort\t" << pmedium << endl;
  cout << "queueSize\tshort\t" << queueSize << endl;
  cout << "warningThreshold\tfloat\t" << warningThreshold << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *carlislePriorityHeaterPerTimeIDRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("HeatersAtInterval", TheGVName) == 0)
    return &HeatersAtInterval;
  else if (strcmp("IdThreshold", TheGVName) == 0)
    return &IdThreshold;
  else if (strcmp("TimeClock", TheGVName) == 0)
    return &TimeClock;
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    return &freezingThreshold;
  else if (strcmp("gapThreshold", TheGVName) == 0)
    return &gapThreshold;
  else if (strcmp("numSwitch", TheGVName) == 0)
    return &numSwitch;
  else if (strcmp("phigh", TheGVName) == 0)
    return &phigh;
  else if (strcmp("plow", TheGVName) == 0)
    return &plow;
  else if (strcmp("pmedium", TheGVName) == 0)
    return &pmedium;
  else if (strcmp("queueSize", TheGVName) == 0)
    return &queueSize;
  else if (strcmp("warningThreshold", TheGVName) == 0)
    return &warningThreshold;
  else 
    cerr<<"!! carlislePriorityHeaterPerTimeIDRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("HeatersAtInterval", TheGVName) == 0)
    SetGvValue(HeatersAtInterval, *(float *)TheGVValue);
  else if (strcmp("IdThreshold", TheGVName) == 0)
    SetGvValue(IdThreshold, *(short *)TheGVValue);
  else if (strcmp("TimeClock", TheGVName) == 0)
    SetGvValue(TimeClock, *(short *)TheGVValue);
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    SetGvValue(freezingThreshold, *(float *)TheGVValue);
  else if (strcmp("gapThreshold", TheGVName) == 0)
    SetGvValue(gapThreshold, *(short *)TheGVValue);
  else if (strcmp("numSwitch", TheGVName) == 0)
    SetGvValue(numSwitch, *(short *)TheGVValue);
  else if (strcmp("phigh", TheGVName) == 0)
    SetGvValue(phigh, *(short *)TheGVValue);
  else if (strcmp("plow", TheGVName) == 0)
    SetGvValue(plow, *(short *)TheGVValue);
  else if (strcmp("pmedium", TheGVName) == 0)
    SetGvValue(pmedium, *(short *)TheGVValue);
  else if (strcmp("queueSize", TheGVName) == 0)
    SetGvValue(queueSize, *(short *)TheGVValue);
  else if (strcmp("warningThreshold", TheGVName) == 0)
    SetGvValue(warningThreshold, *(float *)TheGVValue);
  else 
    cerr<<"!! carlislePriorityHeaterPerTimeIDRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void carlislePriorityHeaterPerTimeIDRangeStudy::SetGVs(int expNum) {
  SetGvValue(HeatersAtInterval, HeatersAtIntervalValues[expNum]);
  SetGvValue(IdThreshold, IdThresholdValues[expNum]);
  SetGvValue(TimeClock, TimeClockValues[expNum]);
  SetGvValue(freezingThreshold, freezingThresholdValues[expNum]);
  SetGvValue(gapThreshold, gapThresholdValues[expNum]);
  SetGvValue(numSwitch, numSwitchValues[expNum]);
  SetGvValue(phigh, phighValues[expNum]);
  SetGvValue(plow, plowValues[expNum]);
  SetGvValue(pmedium, pmediumValues[expNum]);
  SetGvValue(queueSize, queueSizeValues[expNum]);
  SetGvValue(warningThreshold, warningThresholdValues[expNum]);
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new carlislePriorityHeaterPerTimeIDRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* carlislePriorityHeaterPerTimeIDRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new ActivatedHeatersPerTimeIDPVModel(expandTimeArrays);
  return ThePVModel;
}


