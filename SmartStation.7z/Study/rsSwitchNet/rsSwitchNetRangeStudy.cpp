
#include "Study/rsSwitchNet/rsSwitchNetRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
Short HeatersAtInterval;
Short TimeClock;
Float freezingThreshold;
Short numSwitch;
Short queueSize;
Float warningThreshold;
Float workingTemperature;

//********************************************************
//rsSwitchNetRangeStudy Constructor
//********************************************************
rsSwitchNetRangeStudy::rsSwitchNetRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 7;
  NumExps = 48;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("HeatersAtInterval");
  GVTypes[0]=strdup("short");
  GVNames[1]=strdup("TimeClock");
  GVTypes[1]=strdup("short");
  GVNames[2]=strdup("freezingThreshold");
  GVTypes[2]=strdup("float");
  GVNames[3]=strdup("numSwitch");
  GVTypes[3]=strdup("short");
  GVNames[4]=strdup("queueSize");
  GVTypes[4]=strdup("short");
  GVNames[5]=strdup("warningThreshold");
  GVTypes[5]=strdup("float");
  GVNames[6]=strdup("workingTemperature");
  GVTypes[6]=strdup("float");

  // create the arrays to store the values of each gv
  HeatersAtIntervalValues = new short[NumExps];
  TimeClockValues = new short[NumExps];
  freezingThresholdValues = new float[NumExps];
  numSwitchValues = new short[NumExps];
  queueSizeValues = new short[NumExps];
  warningThresholdValues = new float[NumExps];
  workingTemperatureValues = new float[NumExps];

  // call methods to assign values to each gv
  SetValues_HeatersAtInterval();
  SetValues_TimeClock();
  SetValues_freezingThreshold();
  SetValues_numSwitch();
  SetValues_queueSize();
  SetValues_warningThreshold();
  SetValues_workingTemperature();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//rsSwitchNetRangeStudy Destructor
//******************************************************
rsSwitchNetRangeStudy::~rsSwitchNetRangeStudy() {
  delete [] HeatersAtIntervalValues;
  delete [] TimeClockValues;
  delete [] freezingThresholdValues;
  delete [] numSwitchValues;
  delete [] queueSizeValues;
  delete [] warningThresholdValues;
  delete [] workingTemperatureValues;
  delete ThePVModel;
}


//******************************************************
// set values for HeatersAtInterval
//******************************************************
void rsSwitchNetRangeStudy::SetValues_HeatersAtInterval() {
  for (int n=0; n<NumExps; n++)
    HeatersAtIntervalValues[n] = 7;
}


//******************************************************
// set values for TimeClock
//******************************************************
void rsSwitchNetRangeStudy::SetValues_TimeClock() {
  for (int n=0; n<NumExps; n++)
    TimeClockValues[n] = 1;
}


//******************************************************
// set values for freezingThreshold
//******************************************************
void rsSwitchNetRangeStudy::SetValues_freezingThreshold() {
  for (int n=0; n<NumExps; n++)
    freezingThresholdValues[n] = 0.0;
}


//******************************************************
// set values for numSwitch
//******************************************************
void rsSwitchNetRangeStudy::SetValues_numSwitch() {
  for (int n=0; n<NumExps; n++)
    numSwitchValues[n] = 4;
}


//******************************************************
// set values for queueSize
//******************************************************
void rsSwitchNetRangeStudy::SetValues_queueSize() {
  queueSizeValues[0] = 1;
  queueSizeValues[1] = 2;
  queueSizeValues[2] = 3;
  queueSizeValues[3] = 4;
  queueSizeValues[4] = 1;
  queueSizeValues[5] = 2;
  queueSizeValues[6] = 3;
  queueSizeValues[7] = 4;
  queueSizeValues[8] = 1;
  queueSizeValues[9] = 2;
  queueSizeValues[10] = 3;
  queueSizeValues[11] = 4;
  queueSizeValues[12] = 1;
  queueSizeValues[13] = 2;
  queueSizeValues[14] = 3;
  queueSizeValues[15] = 4;
  queueSizeValues[16] = 1;
  queueSizeValues[17] = 2;
  queueSizeValues[18] = 3;
  queueSizeValues[19] = 4;
  queueSizeValues[20] = 1;
  queueSizeValues[21] = 2;
  queueSizeValues[22] = 3;
  queueSizeValues[23] = 4;
  queueSizeValues[24] = 1;
  queueSizeValues[25] = 2;
  queueSizeValues[26] = 3;
  queueSizeValues[27] = 4;
  queueSizeValues[28] = 1;
  queueSizeValues[29] = 2;
  queueSizeValues[30] = 3;
  queueSizeValues[31] = 4;
  queueSizeValues[32] = 1;
  queueSizeValues[33] = 2;
  queueSizeValues[34] = 3;
  queueSizeValues[35] = 4;
  queueSizeValues[36] = 1;
  queueSizeValues[37] = 2;
  queueSizeValues[38] = 3;
  queueSizeValues[39] = 4;
  queueSizeValues[40] = 1;
  queueSizeValues[41] = 2;
  queueSizeValues[42] = 3;
  queueSizeValues[43] = 4;
  queueSizeValues[44] = 1;
  queueSizeValues[45] = 2;
  queueSizeValues[46] = 3;
  queueSizeValues[47] = 4;
}


//******************************************************
// set values for warningThreshold
//******************************************************
void rsSwitchNetRangeStudy::SetValues_warningThreshold() {
  warningThresholdValues[0] = 1.0;
  warningThresholdValues[1] = 1.0;
  warningThresholdValues[2] = 1.0;
  warningThresholdValues[3] = 1.0;
  warningThresholdValues[4] = 3.0;
  warningThresholdValues[5] = 3.0;
  warningThresholdValues[6] = 3.0;
  warningThresholdValues[7] = 3.0;
  warningThresholdValues[8] = 4.0;
  warningThresholdValues[9] = 4.0;
  warningThresholdValues[10] = 4.0;
  warningThresholdValues[11] = 4.0;
  warningThresholdValues[12] = 1.0;
  warningThresholdValues[13] = 1.0;
  warningThresholdValues[14] = 1.0;
  warningThresholdValues[15] = 1.0;
  warningThresholdValues[16] = 3.0;
  warningThresholdValues[17] = 3.0;
  warningThresholdValues[18] = 3.0;
  warningThresholdValues[19] = 3.0;
  warningThresholdValues[20] = 4.0;
  warningThresholdValues[21] = 4.0;
  warningThresholdValues[22] = 4.0;
  warningThresholdValues[23] = 4.0;
  warningThresholdValues[24] = 1.0;
  warningThresholdValues[25] = 1.0;
  warningThresholdValues[26] = 1.0;
  warningThresholdValues[27] = 1.0;
  warningThresholdValues[28] = 3.0;
  warningThresholdValues[29] = 3.0;
  warningThresholdValues[30] = 3.0;
  warningThresholdValues[31] = 3.0;
  warningThresholdValues[32] = 4.0;
  warningThresholdValues[33] = 4.0;
  warningThresholdValues[34] = 4.0;
  warningThresholdValues[35] = 4.0;
  warningThresholdValues[36] = 1.0;
  warningThresholdValues[37] = 1.0;
  warningThresholdValues[38] = 1.0;
  warningThresholdValues[39] = 1.0;
  warningThresholdValues[40] = 3.0;
  warningThresholdValues[41] = 3.0;
  warningThresholdValues[42] = 3.0;
  warningThresholdValues[43] = 3.0;
  warningThresholdValues[44] = 4.0;
  warningThresholdValues[45] = 4.0;
  warningThresholdValues[46] = 4.0;
  warningThresholdValues[47] = 4.0;
}


//******************************************************
// set values for workingTemperature
//******************************************************
void rsSwitchNetRangeStudy::SetValues_workingTemperature() {
  workingTemperatureValues[0] = 4.0;
  workingTemperatureValues[1] = 4.0;
  workingTemperatureValues[2] = 4.0;
  workingTemperatureValues[3] = 4.0;
  workingTemperatureValues[4] = 4.0;
  workingTemperatureValues[5] = 4.0;
  workingTemperatureValues[6] = 4.0;
  workingTemperatureValues[7] = 4.0;
  workingTemperatureValues[8] = 4.0;
  workingTemperatureValues[9] = 4.0;
  workingTemperatureValues[10] = 4.0;
  workingTemperatureValues[11] = 4.0;
  workingTemperatureValues[12] = 5.0;
  workingTemperatureValues[13] = 5.0;
  workingTemperatureValues[14] = 5.0;
  workingTemperatureValues[15] = 5.0;
  workingTemperatureValues[16] = 5.0;
  workingTemperatureValues[17] = 5.0;
  workingTemperatureValues[18] = 5.0;
  workingTemperatureValues[19] = 5.0;
  workingTemperatureValues[20] = 5.0;
  workingTemperatureValues[21] = 5.0;
  workingTemperatureValues[22] = 5.0;
  workingTemperatureValues[23] = 5.0;
  workingTemperatureValues[24] = 7.0;
  workingTemperatureValues[25] = 7.0;
  workingTemperatureValues[26] = 7.0;
  workingTemperatureValues[27] = 7.0;
  workingTemperatureValues[28] = 7.0;
  workingTemperatureValues[29] = 7.0;
  workingTemperatureValues[30] = 7.0;
  workingTemperatureValues[31] = 7.0;
  workingTemperatureValues[32] = 7.0;
  workingTemperatureValues[33] = 7.0;
  workingTemperatureValues[34] = 7.0;
  workingTemperatureValues[35] = 7.0;
  workingTemperatureValues[36] = 50.0;
  workingTemperatureValues[37] = 50.0;
  workingTemperatureValues[38] = 50.0;
  workingTemperatureValues[39] = 50.0;
  workingTemperatureValues[40] = 50.0;
  workingTemperatureValues[41] = 50.0;
  workingTemperatureValues[42] = 50.0;
  workingTemperatureValues[43] = 50.0;
  workingTemperatureValues[44] = 50.0;
  workingTemperatureValues[45] = 50.0;
  workingTemperatureValues[46] = 50.0;
  workingTemperatureValues[47] = 50.0;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void rsSwitchNetRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "HeatersAtInterval\tshort\t" << HeatersAtInterval << endl;
  cout << "TimeClock\tshort\t" << TimeClock << endl;
  cout << "freezingThreshold\tfloat\t" << freezingThreshold << endl;
  cout << "numSwitch\tshort\t" << numSwitch << endl;
  cout << "queueSize\tshort\t" << queueSize << endl;
  cout << "warningThreshold\tfloat\t" << warningThreshold << endl;
  cout << "workingTemperature\tfloat\t" << workingTemperature << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *rsSwitchNetRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("HeatersAtInterval", TheGVName) == 0)
    return &HeatersAtInterval;
  else if (strcmp("TimeClock", TheGVName) == 0)
    return &TimeClock;
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    return &freezingThreshold;
  else if (strcmp("numSwitch", TheGVName) == 0)
    return &numSwitch;
  else if (strcmp("queueSize", TheGVName) == 0)
    return &queueSize;
  else if (strcmp("warningThreshold", TheGVName) == 0)
    return &warningThreshold;
  else if (strcmp("workingTemperature", TheGVName) == 0)
    return &workingTemperature;
  else 
    cerr<<"!! rsSwitchNetRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void rsSwitchNetRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("HeatersAtInterval", TheGVName) == 0)
    SetGvValue(HeatersAtInterval, *(short *)TheGVValue);
  else if (strcmp("TimeClock", TheGVName) == 0)
    SetGvValue(TimeClock, *(short *)TheGVValue);
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    SetGvValue(freezingThreshold, *(float *)TheGVValue);
  else if (strcmp("numSwitch", TheGVName) == 0)
    SetGvValue(numSwitch, *(short *)TheGVValue);
  else if (strcmp("queueSize", TheGVName) == 0)
    SetGvValue(queueSize, *(short *)TheGVValue);
  else if (strcmp("warningThreshold", TheGVName) == 0)
    SetGvValue(warningThreshold, *(float *)TheGVValue);
  else if (strcmp("workingTemperature", TheGVName) == 0)
    SetGvValue(workingTemperature, *(float *)TheGVValue);
  else 
    cerr<<"!! rsSwitchNetRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void rsSwitchNetRangeStudy::SetGVs(int expNum) {
  SetGvValue(HeatersAtInterval, HeatersAtIntervalValues[expNum]);
  SetGvValue(TimeClock, TimeClockValues[expNum]);
  SetGvValue(freezingThreshold, freezingThresholdValues[expNum]);
  SetGvValue(numSwitch, numSwitchValues[expNum]);
  SetGvValue(queueSize, queueSizeValues[expNum]);
  SetGvValue(warningThreshold, warningThresholdValues[expNum]);
  SetGvValue(workingTemperature, workingTemperatureValues[expNum]);
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new rsSwitchNetRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* rsSwitchNetRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new rewardSwitchNetPVModel(expandTimeArrays);
  return ThePVModel;
}


