
#ifndef rsSwitchNetRangeSTUDY_H_
#define rsSwitchNetRangeSTUDY_H_

#include "Reward/rewardSwitchNet/rewardSwitchNetPVNodes.h"
#include "Reward/rewardSwitchNet/rewardSwitchNetPVModel.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/Study/BaseStudyClass.hpp"

extern Short HeatersAtInterval;
extern Short TimeClock;
extern Float freezingThreshold;
extern Short numSwitch;
extern Short queueSize;
extern Float warningThreshold;
extern Float workingTemperature;

class rsSwitchNetRangeStudy : public BaseStudyClass {
public:

rsSwitchNetRangeStudy();
~rsSwitchNetRangeStudy();

private:

short *HeatersAtIntervalValues;
short *TimeClockValues;
float *freezingThresholdValues;
short *numSwitchValues;
short *queueSizeValues;
float *warningThresholdValues;
float *workingTemperatureValues;

void SetValues_HeatersAtInterval();
void SetValues_TimeClock();
void SetValues_freezingThreshold();
void SetValues_numSwitch();
void SetValues_queueSize();
void SetValues_warningThreshold();
void SetValues_workingTemperature();

void PrintGlobalValues(int);
void *GetGVValue(char *TheGVName);
void OverrideGVValue(char *TheGVName, void *TheGVValue);
void SetGVs(int expnum);
PVModel *GetPVModel(bool expandTimeArrays);
};

#endif

