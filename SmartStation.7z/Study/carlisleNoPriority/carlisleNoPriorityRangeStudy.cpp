
#include "Study/carlisleNoPriority/carlisleNoPriorityRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
Float HeatersAtInterval;
Short TimeClock;
Float freezingThreshold;
Short gapThreshold;
Short numSwitch;
Short phigh;
Short plow;
Short pmedium;
Short priorities;
Short queueSize;
Float warningThreshold;

//********************************************************
//carlisleNoPriorityRangeStudy Constructor
//********************************************************
carlisleNoPriorityRangeStudy::carlisleNoPriorityRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 11;
  NumExps = 224;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("HeatersAtInterval");
  GVTypes[0]=strdup("float");
  GVNames[1]=strdup("TimeClock");
  GVTypes[1]=strdup("short");
  GVNames[2]=strdup("freezingThreshold");
  GVTypes[2]=strdup("float");
  GVNames[3]=strdup("gapThreshold");
  GVTypes[3]=strdup("short");
  GVNames[4]=strdup("numSwitch");
  GVTypes[4]=strdup("short");
  GVNames[5]=strdup("phigh");
  GVTypes[5]=strdup("short");
  GVNames[6]=strdup("plow");
  GVTypes[6]=strdup("short");
  GVNames[7]=strdup("pmedium");
  GVTypes[7]=strdup("short");
  GVNames[8]=strdup("priorities");
  GVTypes[8]=strdup("short");
  GVNames[9]=strdup("queueSize");
  GVTypes[9]=strdup("short");
  GVNames[10]=strdup("warningThreshold");
  GVTypes[10]=strdup("float");

  // create the arrays to store the values of each gv
  HeatersAtIntervalValues = new float[NumExps];
  TimeClockValues = new short[NumExps];
  freezingThresholdValues = new float[NumExps];
  gapThresholdValues = new short[NumExps];
  numSwitchValues = new short[NumExps];
  phighValues = new short[NumExps];
  plowValues = new short[NumExps];
  pmediumValues = new short[NumExps];
  prioritiesValues = new short[NumExps];
  queueSizeValues = new short[NumExps];
  warningThresholdValues = new float[NumExps];

  // call methods to assign values to each gv
  SetValues_HeatersAtInterval();
  SetValues_TimeClock();
  SetValues_freezingThreshold();
  SetValues_gapThreshold();
  SetValues_numSwitch();
  SetValues_phigh();
  SetValues_plow();
  SetValues_pmedium();
  SetValues_priorities();
  SetValues_queueSize();
  SetValues_warningThreshold();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//carlisleNoPriorityRangeStudy Destructor
//******************************************************
carlisleNoPriorityRangeStudy::~carlisleNoPriorityRangeStudy() {
  delete [] HeatersAtIntervalValues;
  delete [] TimeClockValues;
  delete [] freezingThresholdValues;
  delete [] gapThresholdValues;
  delete [] numSwitchValues;
  delete [] phighValues;
  delete [] plowValues;
  delete [] pmediumValues;
  delete [] prioritiesValues;
  delete [] queueSizeValues;
  delete [] warningThresholdValues;
  delete ThePVModel;
}


//******************************************************
// set values for HeatersAtInterval
//******************************************************
void carlisleNoPriorityRangeStudy::SetValues_HeatersAtInterval() {
  for (int n=0; n<NumExps; n++)
    HeatersAtIntervalValues[n] = 12.5;
}


//******************************************************
// set values for TimeClock
//******************************************************
void carlisleNoPriorityRangeStudy::SetValues_TimeClock() {
  for (int n=0; n<NumExps; n++)
    TimeClockValues[n] = 1;
}


//******************************************************
// set values for freezingThreshold
//******************************************************
void carlisleNoPriorityRangeStudy::SetValues_freezingThreshold() {
  for (int n=0; n<NumExps; n++)
    freezingThresholdValues[n] = 0.0;
}


//******************************************************
// set values for gapThreshold
//******************************************************
void carlisleNoPriorityRangeStudy::SetValues_gapThreshold() {
  gapThresholdValues[0] = 1;
  gapThresholdValues[1] = 2;
  gapThresholdValues[2] = 3;
  gapThresholdValues[3] = 4;
  gapThresholdValues[4] = 5;
  gapThresholdValues[5] = 6;
  gapThresholdValues[6] = 7;
  gapThresholdValues[7] = 8;
  gapThresholdValues[8] = 1;
  gapThresholdValues[9] = 2;
  gapThresholdValues[10] = 3;
  gapThresholdValues[11] = 4;
  gapThresholdValues[12] = 5;
  gapThresholdValues[13] = 6;
  gapThresholdValues[14] = 7;
  gapThresholdValues[15] = 8;
  gapThresholdValues[16] = 1;
  gapThresholdValues[17] = 2;
  gapThresholdValues[18] = 3;
  gapThresholdValues[19] = 4;
  gapThresholdValues[20] = 5;
  gapThresholdValues[21] = 6;
  gapThresholdValues[22] = 7;
  gapThresholdValues[23] = 8;
  gapThresholdValues[24] = 1;
  gapThresholdValues[25] = 2;
  gapThresholdValues[26] = 3;
  gapThresholdValues[27] = 4;
  gapThresholdValues[28] = 5;
  gapThresholdValues[29] = 6;
  gapThresholdValues[30] = 7;
  gapThresholdValues[31] = 8;
  gapThresholdValues[32] = 1;
  gapThresholdValues[33] = 2;
  gapThresholdValues[34] = 3;
  gapThresholdValues[35] = 4;
  gapThresholdValues[36] = 5;
  gapThresholdValues[37] = 6;
  gapThresholdValues[38] = 7;
  gapThresholdValues[39] = 8;
  gapThresholdValues[40] = 1;
  gapThresholdValues[41] = 2;
  gapThresholdValues[42] = 3;
  gapThresholdValues[43] = 4;
  gapThresholdValues[44] = 5;
  gapThresholdValues[45] = 6;
  gapThresholdValues[46] = 7;
  gapThresholdValues[47] = 8;
  gapThresholdValues[48] = 1;
  gapThresholdValues[49] = 2;
  gapThresholdValues[50] = 3;
  gapThresholdValues[51] = 4;
  gapThresholdValues[52] = 5;
  gapThresholdValues[53] = 6;
  gapThresholdValues[54] = 7;
  gapThresholdValues[55] = 8;
  gapThresholdValues[56] = 1;
  gapThresholdValues[57] = 2;
  gapThresholdValues[58] = 3;
  gapThresholdValues[59] = 4;
  gapThresholdValues[60] = 5;
  gapThresholdValues[61] = 6;
  gapThresholdValues[62] = 7;
  gapThresholdValues[63] = 8;
  gapThresholdValues[64] = 1;
  gapThresholdValues[65] = 2;
  gapThresholdValues[66] = 3;
  gapThresholdValues[67] = 4;
  gapThresholdValues[68] = 5;
  gapThresholdValues[69] = 6;
  gapThresholdValues[70] = 7;
  gapThresholdValues[71] = 8;
  gapThresholdValues[72] = 1;
  gapThresholdValues[73] = 2;
  gapThresholdValues[74] = 3;
  gapThresholdValues[75] = 4;
  gapThresholdValues[76] = 5;
  gapThresholdValues[77] = 6;
  gapThresholdValues[78] = 7;
  gapThresholdValues[79] = 8;
  gapThresholdValues[80] = 1;
  gapThresholdValues[81] = 2;
  gapThresholdValues[82] = 3;
  gapThresholdValues[83] = 4;
  gapThresholdValues[84] = 5;
  gapThresholdValues[85] = 6;
  gapThresholdValues[86] = 7;
  gapThresholdValues[87] = 8;
  gapThresholdValues[88] = 1;
  gapThresholdValues[89] = 2;
  gapThresholdValues[90] = 3;
  gapThresholdValues[91] = 4;
  gapThresholdValues[92] = 5;
  gapThresholdValues[93] = 6;
  gapThresholdValues[94] = 7;
  gapThresholdValues[95] = 8;
  gapThresholdValues[96] = 1;
  gapThresholdValues[97] = 2;
  gapThresholdValues[98] = 3;
  gapThresholdValues[99] = 4;
  gapThresholdValues[100] = 5;
  gapThresholdValues[101] = 6;
  gapThresholdValues[102] = 7;
  gapThresholdValues[103] = 8;
  gapThresholdValues[104] = 1;
  gapThresholdValues[105] = 2;
  gapThresholdValues[106] = 3;
  gapThresholdValues[107] = 4;
  gapThresholdValues[108] = 5;
  gapThresholdValues[109] = 6;
  gapThresholdValues[110] = 7;
  gapThresholdValues[111] = 8;
  gapThresholdValues[112] = 1;
  gapThresholdValues[113] = 2;
  gapThresholdValues[114] = 3;
  gapThresholdValues[115] = 4;
  gapThresholdValues[116] = 5;
  gapThresholdValues[117] = 6;
  gapThresholdValues[118] = 7;
  gapThresholdValues[119] = 8;
  gapThresholdValues[120] = 1;
  gapThresholdValues[121] = 2;
  gapThresholdValues[122] = 3;
  gapThresholdValues[123] = 4;
  gapThresholdValues[124] = 5;
  gapThresholdValues[125] = 6;
  gapThresholdValues[126] = 7;
  gapThresholdValues[127] = 8;
  gapThresholdValues[128] = 1;
  gapThresholdValues[129] = 2;
  gapThresholdValues[130] = 3;
  gapThresholdValues[131] = 4;
  gapThresholdValues[132] = 5;
  gapThresholdValues[133] = 6;
  gapThresholdValues[134] = 7;
  gapThresholdValues[135] = 8;
  gapThresholdValues[136] = 1;
  gapThresholdValues[137] = 2;
  gapThresholdValues[138] = 3;
  gapThresholdValues[139] = 4;
  gapThresholdValues[140] = 5;
  gapThresholdValues[141] = 6;
  gapThresholdValues[142] = 7;
  gapThresholdValues[143] = 8;
  gapThresholdValues[144] = 1;
  gapThresholdValues[145] = 2;
  gapThresholdValues[146] = 3;
  gapThresholdValues[147] = 4;
  gapThresholdValues[148] = 5;
  gapThresholdValues[149] = 6;
  gapThresholdValues[150] = 7;
  gapThresholdValues[151] = 8;
  gapThresholdValues[152] = 1;
  gapThresholdValues[153] = 2;
  gapThresholdValues[154] = 3;
  gapThresholdValues[155] = 4;
  gapThresholdValues[156] = 5;
  gapThresholdValues[157] = 6;
  gapThresholdValues[158] = 7;
  gapThresholdValues[159] = 8;
  gapThresholdValues[160] = 1;
  gapThresholdValues[161] = 2;
  gapThresholdValues[162] = 3;
  gapThresholdValues[163] = 4;
  gapThresholdValues[164] = 5;
  gapThresholdValues[165] = 6;
  gapThresholdValues[166] = 7;
  gapThresholdValues[167] = 8;
  gapThresholdValues[168] = 1;
  gapThresholdValues[169] = 2;
  gapThresholdValues[170] = 3;
  gapThresholdValues[171] = 4;
  gapThresholdValues[172] = 5;
  gapThresholdValues[173] = 6;
  gapThresholdValues[174] = 7;
  gapThresholdValues[175] = 8;
  gapThresholdValues[176] = 1;
  gapThresholdValues[177] = 2;
  gapThresholdValues[178] = 3;
  gapThresholdValues[179] = 4;
  gapThresholdValues[180] = 5;
  gapThresholdValues[181] = 6;
  gapThresholdValues[182] = 7;
  gapThresholdValues[183] = 8;
  gapThresholdValues[184] = 1;
  gapThresholdValues[185] = 2;
  gapThresholdValues[186] = 3;
  gapThresholdValues[187] = 4;
  gapThresholdValues[188] = 5;
  gapThresholdValues[189] = 6;
  gapThresholdValues[190] = 7;
  gapThresholdValues[191] = 8;
  gapThresholdValues[192] = 1;
  gapThresholdValues[193] = 2;
  gapThresholdValues[194] = 3;
  gapThresholdValues[195] = 4;
  gapThresholdValues[196] = 5;
  gapThresholdValues[197] = 6;
  gapThresholdValues[198] = 7;
  gapThresholdValues[199] = 8;
  gapThresholdValues[200] = 1;
  gapThresholdValues[201] = 2;
  gapThresholdValues[202] = 3;
  gapThresholdValues[203] = 4;
  gapThresholdValues[204] = 5;
  gapThresholdValues[205] = 6;
  gapThresholdValues[206] = 7;
  gapThresholdValues[207] = 8;
  gapThresholdValues[208] = 1;
  gapThresholdValues[209] = 2;
  gapThresholdValues[210] = 3;
  gapThresholdValues[211] = 4;
  gapThresholdValues[212] = 5;
  gapThresholdValues[213] = 6;
  gapThresholdValues[214] = 7;
  gapThresholdValues[215] = 8;
  gapThresholdValues[216] = 1;
  gapThresholdValues[217] = 2;
  gapThresholdValues[218] = 3;
  gapThresholdValues[219] = 4;
  gapThresholdValues[220] = 5;
  gapThresholdValues[221] = 6;
  gapThresholdValues[222] = 7;
  gapThresholdValues[223] = 8;
}


//******************************************************
// set values for numSwitch
//******************************************************
void carlisleNoPriorityRangeStudy::SetValues_numSwitch() {
  for (int n=0; n<NumExps; n++)
    numSwitchValues[n] = 41;
}


//******************************************************
// set values for phigh
//******************************************************
void carlisleNoPriorityRangeStudy::SetValues_phigh() {
  for (int n=0; n<NumExps; n++)
    phighValues[n] = 41;
}


//******************************************************
// set values for plow
//******************************************************
void carlisleNoPriorityRangeStudy::SetValues_plow() {
  for (int n=0; n<NumExps; n++)
    plowValues[n] = 0;
}


//******************************************************
// set values for pmedium
//******************************************************
void carlisleNoPriorityRangeStudy::SetValues_pmedium() {
  for (int n=0; n<NumExps; n++)
    pmediumValues[n] = 0;
}


//******************************************************
// set values for priorities
//******************************************************
void carlisleNoPriorityRangeStudy::SetValues_priorities() {
  for (int n=0; n<NumExps; n++)
    prioritiesValues[n] = 1;
}


//******************************************************
// set values for queueSize
//******************************************************
void carlisleNoPriorityRangeStudy::SetValues_queueSize() {
  queueSizeValues[0] = 10;
  queueSizeValues[1] = 10;
  queueSizeValues[2] = 10;
  queueSizeValues[3] = 10;
  queueSizeValues[4] = 10;
  queueSizeValues[5] = 10;
  queueSizeValues[6] = 10;
  queueSizeValues[7] = 10;
  queueSizeValues[8] = 21;
  queueSizeValues[9] = 21;
  queueSizeValues[10] = 21;
  queueSizeValues[11] = 21;
  queueSizeValues[12] = 21;
  queueSizeValues[13] = 21;
  queueSizeValues[14] = 21;
  queueSizeValues[15] = 21;
  queueSizeValues[16] = 31;
  queueSizeValues[17] = 31;
  queueSizeValues[18] = 31;
  queueSizeValues[19] = 31;
  queueSizeValues[20] = 31;
  queueSizeValues[21] = 31;
  queueSizeValues[22] = 31;
  queueSizeValues[23] = 31;
  queueSizeValues[24] = 41;
  queueSizeValues[25] = 41;
  queueSizeValues[26] = 41;
  queueSizeValues[27] = 41;
  queueSizeValues[28] = 41;
  queueSizeValues[29] = 41;
  queueSizeValues[30] = 41;
  queueSizeValues[31] = 41;
  queueSizeValues[32] = 10;
  queueSizeValues[33] = 10;
  queueSizeValues[34] = 10;
  queueSizeValues[35] = 10;
  queueSizeValues[36] = 10;
  queueSizeValues[37] = 10;
  queueSizeValues[38] = 10;
  queueSizeValues[39] = 10;
  queueSizeValues[40] = 21;
  queueSizeValues[41] = 21;
  queueSizeValues[42] = 21;
  queueSizeValues[43] = 21;
  queueSizeValues[44] = 21;
  queueSizeValues[45] = 21;
  queueSizeValues[46] = 21;
  queueSizeValues[47] = 21;
  queueSizeValues[48] = 31;
  queueSizeValues[49] = 31;
  queueSizeValues[50] = 31;
  queueSizeValues[51] = 31;
  queueSizeValues[52] = 31;
  queueSizeValues[53] = 31;
  queueSizeValues[54] = 31;
  queueSizeValues[55] = 31;
  queueSizeValues[56] = 41;
  queueSizeValues[57] = 41;
  queueSizeValues[58] = 41;
  queueSizeValues[59] = 41;
  queueSizeValues[60] = 41;
  queueSizeValues[61] = 41;
  queueSizeValues[62] = 41;
  queueSizeValues[63] = 41;
  queueSizeValues[64] = 10;
  queueSizeValues[65] = 10;
  queueSizeValues[66] = 10;
  queueSizeValues[67] = 10;
  queueSizeValues[68] = 10;
  queueSizeValues[69] = 10;
  queueSizeValues[70] = 10;
  queueSizeValues[71] = 10;
  queueSizeValues[72] = 21;
  queueSizeValues[73] = 21;
  queueSizeValues[74] = 21;
  queueSizeValues[75] = 21;
  queueSizeValues[76] = 21;
  queueSizeValues[77] = 21;
  queueSizeValues[78] = 21;
  queueSizeValues[79] = 21;
  queueSizeValues[80] = 31;
  queueSizeValues[81] = 31;
  queueSizeValues[82] = 31;
  queueSizeValues[83] = 31;
  queueSizeValues[84] = 31;
  queueSizeValues[85] = 31;
  queueSizeValues[86] = 31;
  queueSizeValues[87] = 31;
  queueSizeValues[88] = 41;
  queueSizeValues[89] = 41;
  queueSizeValues[90] = 41;
  queueSizeValues[91] = 41;
  queueSizeValues[92] = 41;
  queueSizeValues[93] = 41;
  queueSizeValues[94] = 41;
  queueSizeValues[95] = 41;
  queueSizeValues[96] = 10;
  queueSizeValues[97] = 10;
  queueSizeValues[98] = 10;
  queueSizeValues[99] = 10;
  queueSizeValues[100] = 10;
  queueSizeValues[101] = 10;
  queueSizeValues[102] = 10;
  queueSizeValues[103] = 10;
  queueSizeValues[104] = 21;
  queueSizeValues[105] = 21;
  queueSizeValues[106] = 21;
  queueSizeValues[107] = 21;
  queueSizeValues[108] = 21;
  queueSizeValues[109] = 21;
  queueSizeValues[110] = 21;
  queueSizeValues[111] = 21;
  queueSizeValues[112] = 31;
  queueSizeValues[113] = 31;
  queueSizeValues[114] = 31;
  queueSizeValues[115] = 31;
  queueSizeValues[116] = 31;
  queueSizeValues[117] = 31;
  queueSizeValues[118] = 31;
  queueSizeValues[119] = 31;
  queueSizeValues[120] = 41;
  queueSizeValues[121] = 41;
  queueSizeValues[122] = 41;
  queueSizeValues[123] = 41;
  queueSizeValues[124] = 41;
  queueSizeValues[125] = 41;
  queueSizeValues[126] = 41;
  queueSizeValues[127] = 41;
  queueSizeValues[128] = 10;
  queueSizeValues[129] = 10;
  queueSizeValues[130] = 10;
  queueSizeValues[131] = 10;
  queueSizeValues[132] = 10;
  queueSizeValues[133] = 10;
  queueSizeValues[134] = 10;
  queueSizeValues[135] = 10;
  queueSizeValues[136] = 21;
  queueSizeValues[137] = 21;
  queueSizeValues[138] = 21;
  queueSizeValues[139] = 21;
  queueSizeValues[140] = 21;
  queueSizeValues[141] = 21;
  queueSizeValues[142] = 21;
  queueSizeValues[143] = 21;
  queueSizeValues[144] = 31;
  queueSizeValues[145] = 31;
  queueSizeValues[146] = 31;
  queueSizeValues[147] = 31;
  queueSizeValues[148] = 31;
  queueSizeValues[149] = 31;
  queueSizeValues[150] = 31;
  queueSizeValues[151] = 31;
  queueSizeValues[152] = 41;
  queueSizeValues[153] = 41;
  queueSizeValues[154] = 41;
  queueSizeValues[155] = 41;
  queueSizeValues[156] = 41;
  queueSizeValues[157] = 41;
  queueSizeValues[158] = 41;
  queueSizeValues[159] = 41;
  queueSizeValues[160] = 10;
  queueSizeValues[161] = 10;
  queueSizeValues[162] = 10;
  queueSizeValues[163] = 10;
  queueSizeValues[164] = 10;
  queueSizeValues[165] = 10;
  queueSizeValues[166] = 10;
  queueSizeValues[167] = 10;
  queueSizeValues[168] = 21;
  queueSizeValues[169] = 21;
  queueSizeValues[170] = 21;
  queueSizeValues[171] = 21;
  queueSizeValues[172] = 21;
  queueSizeValues[173] = 21;
  queueSizeValues[174] = 21;
  queueSizeValues[175] = 21;
  queueSizeValues[176] = 31;
  queueSizeValues[177] = 31;
  queueSizeValues[178] = 31;
  queueSizeValues[179] = 31;
  queueSizeValues[180] = 31;
  queueSizeValues[181] = 31;
  queueSizeValues[182] = 31;
  queueSizeValues[183] = 31;
  queueSizeValues[184] = 41;
  queueSizeValues[185] = 41;
  queueSizeValues[186] = 41;
  queueSizeValues[187] = 41;
  queueSizeValues[188] = 41;
  queueSizeValues[189] = 41;
  queueSizeValues[190] = 41;
  queueSizeValues[191] = 41;
  queueSizeValues[192] = 10;
  queueSizeValues[193] = 10;
  queueSizeValues[194] = 10;
  queueSizeValues[195] = 10;
  queueSizeValues[196] = 10;
  queueSizeValues[197] = 10;
  queueSizeValues[198] = 10;
  queueSizeValues[199] = 10;
  queueSizeValues[200] = 21;
  queueSizeValues[201] = 21;
  queueSizeValues[202] = 21;
  queueSizeValues[203] = 21;
  queueSizeValues[204] = 21;
  queueSizeValues[205] = 21;
  queueSizeValues[206] = 21;
  queueSizeValues[207] = 21;
  queueSizeValues[208] = 31;
  queueSizeValues[209] = 31;
  queueSizeValues[210] = 31;
  queueSizeValues[211] = 31;
  queueSizeValues[212] = 31;
  queueSizeValues[213] = 31;
  queueSizeValues[214] = 31;
  queueSizeValues[215] = 31;
  queueSizeValues[216] = 41;
  queueSizeValues[217] = 41;
  queueSizeValues[218] = 41;
  queueSizeValues[219] = 41;
  queueSizeValues[220] = 41;
  queueSizeValues[221] = 41;
  queueSizeValues[222] = 41;
  queueSizeValues[223] = 41;
}


//******************************************************
// set values for warningThreshold
//******************************************************
void carlisleNoPriorityRangeStudy::SetValues_warningThreshold() {
  warningThresholdValues[0] = 5.0;
  warningThresholdValues[1] = 5.0;
  warningThresholdValues[2] = 5.0;
  warningThresholdValues[3] = 5.0;
  warningThresholdValues[4] = 5.0;
  warningThresholdValues[5] = 5.0;
  warningThresholdValues[6] = 5.0;
  warningThresholdValues[7] = 5.0;
  warningThresholdValues[8] = 5.0;
  warningThresholdValues[9] = 5.0;
  warningThresholdValues[10] = 5.0;
  warningThresholdValues[11] = 5.0;
  warningThresholdValues[12] = 5.0;
  warningThresholdValues[13] = 5.0;
  warningThresholdValues[14] = 5.0;
  warningThresholdValues[15] = 5.0;
  warningThresholdValues[16] = 5.0;
  warningThresholdValues[17] = 5.0;
  warningThresholdValues[18] = 5.0;
  warningThresholdValues[19] = 5.0;
  warningThresholdValues[20] = 5.0;
  warningThresholdValues[21] = 5.0;
  warningThresholdValues[22] = 5.0;
  warningThresholdValues[23] = 5.0;
  warningThresholdValues[24] = 5.0;
  warningThresholdValues[25] = 5.0;
  warningThresholdValues[26] = 5.0;
  warningThresholdValues[27] = 5.0;
  warningThresholdValues[28] = 5.0;
  warningThresholdValues[29] = 5.0;
  warningThresholdValues[30] = 5.0;
  warningThresholdValues[31] = 5.0;
  warningThresholdValues[32] = 8.0;
  warningThresholdValues[33] = 8.0;
  warningThresholdValues[34] = 8.0;
  warningThresholdValues[35] = 8.0;
  warningThresholdValues[36] = 8.0;
  warningThresholdValues[37] = 8.0;
  warningThresholdValues[38] = 8.0;
  warningThresholdValues[39] = 8.0;
  warningThresholdValues[40] = 8.0;
  warningThresholdValues[41] = 8.0;
  warningThresholdValues[42] = 8.0;
  warningThresholdValues[43] = 8.0;
  warningThresholdValues[44] = 8.0;
  warningThresholdValues[45] = 8.0;
  warningThresholdValues[46] = 8.0;
  warningThresholdValues[47] = 8.0;
  warningThresholdValues[48] = 8.0;
  warningThresholdValues[49] = 8.0;
  warningThresholdValues[50] = 8.0;
  warningThresholdValues[51] = 8.0;
  warningThresholdValues[52] = 8.0;
  warningThresholdValues[53] = 8.0;
  warningThresholdValues[54] = 8.0;
  warningThresholdValues[55] = 8.0;
  warningThresholdValues[56] = 8.0;
  warningThresholdValues[57] = 8.0;
  warningThresholdValues[58] = 8.0;
  warningThresholdValues[59] = 8.0;
  warningThresholdValues[60] = 8.0;
  warningThresholdValues[61] = 8.0;
  warningThresholdValues[62] = 8.0;
  warningThresholdValues[63] = 8.0;
  warningThresholdValues[64] = 11.0;
  warningThresholdValues[65] = 11.0;
  warningThresholdValues[66] = 11.0;
  warningThresholdValues[67] = 11.0;
  warningThresholdValues[68] = 11.0;
  warningThresholdValues[69] = 11.0;
  warningThresholdValues[70] = 11.0;
  warningThresholdValues[71] = 11.0;
  warningThresholdValues[72] = 11.0;
  warningThresholdValues[73] = 11.0;
  warningThresholdValues[74] = 11.0;
  warningThresholdValues[75] = 11.0;
  warningThresholdValues[76] = 11.0;
  warningThresholdValues[77] = 11.0;
  warningThresholdValues[78] = 11.0;
  warningThresholdValues[79] = 11.0;
  warningThresholdValues[80] = 11.0;
  warningThresholdValues[81] = 11.0;
  warningThresholdValues[82] = 11.0;
  warningThresholdValues[83] = 11.0;
  warningThresholdValues[84] = 11.0;
  warningThresholdValues[85] = 11.0;
  warningThresholdValues[86] = 11.0;
  warningThresholdValues[87] = 11.0;
  warningThresholdValues[88] = 11.0;
  warningThresholdValues[89] = 11.0;
  warningThresholdValues[90] = 11.0;
  warningThresholdValues[91] = 11.0;
  warningThresholdValues[92] = 11.0;
  warningThresholdValues[93] = 11.0;
  warningThresholdValues[94] = 11.0;
  warningThresholdValues[95] = 11.0;
  warningThresholdValues[96] = 14.0;
  warningThresholdValues[97] = 14.0;
  warningThresholdValues[98] = 14.0;
  warningThresholdValues[99] = 14.0;
  warningThresholdValues[100] = 14.0;
  warningThresholdValues[101] = 14.0;
  warningThresholdValues[102] = 14.0;
  warningThresholdValues[103] = 14.0;
  warningThresholdValues[104] = 14.0;
  warningThresholdValues[105] = 14.0;
  warningThresholdValues[106] = 14.0;
  warningThresholdValues[107] = 14.0;
  warningThresholdValues[108] = 14.0;
  warningThresholdValues[109] = 14.0;
  warningThresholdValues[110] = 14.0;
  warningThresholdValues[111] = 14.0;
  warningThresholdValues[112] = 14.0;
  warningThresholdValues[113] = 14.0;
  warningThresholdValues[114] = 14.0;
  warningThresholdValues[115] = 14.0;
  warningThresholdValues[116] = 14.0;
  warningThresholdValues[117] = 14.0;
  warningThresholdValues[118] = 14.0;
  warningThresholdValues[119] = 14.0;
  warningThresholdValues[120] = 14.0;
  warningThresholdValues[121] = 14.0;
  warningThresholdValues[122] = 14.0;
  warningThresholdValues[123] = 14.0;
  warningThresholdValues[124] = 14.0;
  warningThresholdValues[125] = 14.0;
  warningThresholdValues[126] = 14.0;
  warningThresholdValues[127] = 14.0;
  warningThresholdValues[128] = 17.0;
  warningThresholdValues[129] = 17.0;
  warningThresholdValues[130] = 17.0;
  warningThresholdValues[131] = 17.0;
  warningThresholdValues[132] = 17.0;
  warningThresholdValues[133] = 17.0;
  warningThresholdValues[134] = 17.0;
  warningThresholdValues[135] = 17.0;
  warningThresholdValues[136] = 17.0;
  warningThresholdValues[137] = 17.0;
  warningThresholdValues[138] = 17.0;
  warningThresholdValues[139] = 17.0;
  warningThresholdValues[140] = 17.0;
  warningThresholdValues[141] = 17.0;
  warningThresholdValues[142] = 17.0;
  warningThresholdValues[143] = 17.0;
  warningThresholdValues[144] = 17.0;
  warningThresholdValues[145] = 17.0;
  warningThresholdValues[146] = 17.0;
  warningThresholdValues[147] = 17.0;
  warningThresholdValues[148] = 17.0;
  warningThresholdValues[149] = 17.0;
  warningThresholdValues[150] = 17.0;
  warningThresholdValues[151] = 17.0;
  warningThresholdValues[152] = 17.0;
  warningThresholdValues[153] = 17.0;
  warningThresholdValues[154] = 17.0;
  warningThresholdValues[155] = 17.0;
  warningThresholdValues[156] = 17.0;
  warningThresholdValues[157] = 17.0;
  warningThresholdValues[158] = 17.0;
  warningThresholdValues[159] = 17.0;
  warningThresholdValues[160] = 20.0;
  warningThresholdValues[161] = 20.0;
  warningThresholdValues[162] = 20.0;
  warningThresholdValues[163] = 20.0;
  warningThresholdValues[164] = 20.0;
  warningThresholdValues[165] = 20.0;
  warningThresholdValues[166] = 20.0;
  warningThresholdValues[167] = 20.0;
  warningThresholdValues[168] = 20.0;
  warningThresholdValues[169] = 20.0;
  warningThresholdValues[170] = 20.0;
  warningThresholdValues[171] = 20.0;
  warningThresholdValues[172] = 20.0;
  warningThresholdValues[173] = 20.0;
  warningThresholdValues[174] = 20.0;
  warningThresholdValues[175] = 20.0;
  warningThresholdValues[176] = 20.0;
  warningThresholdValues[177] = 20.0;
  warningThresholdValues[178] = 20.0;
  warningThresholdValues[179] = 20.0;
  warningThresholdValues[180] = 20.0;
  warningThresholdValues[181] = 20.0;
  warningThresholdValues[182] = 20.0;
  warningThresholdValues[183] = 20.0;
  warningThresholdValues[184] = 20.0;
  warningThresholdValues[185] = 20.0;
  warningThresholdValues[186] = 20.0;
  warningThresholdValues[187] = 20.0;
  warningThresholdValues[188] = 20.0;
  warningThresholdValues[189] = 20.0;
  warningThresholdValues[190] = 20.0;
  warningThresholdValues[191] = 20.0;
  warningThresholdValues[192] = 23.0;
  warningThresholdValues[193] = 23.0;
  warningThresholdValues[194] = 23.0;
  warningThresholdValues[195] = 23.0;
  warningThresholdValues[196] = 23.0;
  warningThresholdValues[197] = 23.0;
  warningThresholdValues[198] = 23.0;
  warningThresholdValues[199] = 23.0;
  warningThresholdValues[200] = 23.0;
  warningThresholdValues[201] = 23.0;
  warningThresholdValues[202] = 23.0;
  warningThresholdValues[203] = 23.0;
  warningThresholdValues[204] = 23.0;
  warningThresholdValues[205] = 23.0;
  warningThresholdValues[206] = 23.0;
  warningThresholdValues[207] = 23.0;
  warningThresholdValues[208] = 23.0;
  warningThresholdValues[209] = 23.0;
  warningThresholdValues[210] = 23.0;
  warningThresholdValues[211] = 23.0;
  warningThresholdValues[212] = 23.0;
  warningThresholdValues[213] = 23.0;
  warningThresholdValues[214] = 23.0;
  warningThresholdValues[215] = 23.0;
  warningThresholdValues[216] = 23.0;
  warningThresholdValues[217] = 23.0;
  warningThresholdValues[218] = 23.0;
  warningThresholdValues[219] = 23.0;
  warningThresholdValues[220] = 23.0;
  warningThresholdValues[221] = 23.0;
  warningThresholdValues[222] = 23.0;
  warningThresholdValues[223] = 23.0;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void carlisleNoPriorityRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "HeatersAtInterval\tfloat\t" << HeatersAtInterval << endl;
  cout << "TimeClock\tshort\t" << TimeClock << endl;
  cout << "freezingThreshold\tfloat\t" << freezingThreshold << endl;
  cout << "gapThreshold\tshort\t" << gapThreshold << endl;
  cout << "numSwitch\tshort\t" << numSwitch << endl;
  cout << "phigh\tshort\t" << phigh << endl;
  cout << "plow\tshort\t" << plow << endl;
  cout << "pmedium\tshort\t" << pmedium << endl;
  cout << "priorities\tshort\t" << priorities << endl;
  cout << "queueSize\tshort\t" << queueSize << endl;
  cout << "warningThreshold\tfloat\t" << warningThreshold << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *carlisleNoPriorityRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("HeatersAtInterval", TheGVName) == 0)
    return &HeatersAtInterval;
  else if (strcmp("TimeClock", TheGVName) == 0)
    return &TimeClock;
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    return &freezingThreshold;
  else if (strcmp("gapThreshold", TheGVName) == 0)
    return &gapThreshold;
  else if (strcmp("numSwitch", TheGVName) == 0)
    return &numSwitch;
  else if (strcmp("phigh", TheGVName) == 0)
    return &phigh;
  else if (strcmp("plow", TheGVName) == 0)
    return &plow;
  else if (strcmp("pmedium", TheGVName) == 0)
    return &pmedium;
  else if (strcmp("priorities", TheGVName) == 0)
    return &priorities;
  else if (strcmp("queueSize", TheGVName) == 0)
    return &queueSize;
  else if (strcmp("warningThreshold", TheGVName) == 0)
    return &warningThreshold;
  else 
    cerr<<"!! carlisleNoPriorityRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void carlisleNoPriorityRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("HeatersAtInterval", TheGVName) == 0)
    SetGvValue(HeatersAtInterval, *(float *)TheGVValue);
  else if (strcmp("TimeClock", TheGVName) == 0)
    SetGvValue(TimeClock, *(short *)TheGVValue);
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    SetGvValue(freezingThreshold, *(float *)TheGVValue);
  else if (strcmp("gapThreshold", TheGVName) == 0)
    SetGvValue(gapThreshold, *(short *)TheGVValue);
  else if (strcmp("numSwitch", TheGVName) == 0)
    SetGvValue(numSwitch, *(short *)TheGVValue);
  else if (strcmp("phigh", TheGVName) == 0)
    SetGvValue(phigh, *(short *)TheGVValue);
  else if (strcmp("plow", TheGVName) == 0)
    SetGvValue(plow, *(short *)TheGVValue);
  else if (strcmp("pmedium", TheGVName) == 0)
    SetGvValue(pmedium, *(short *)TheGVValue);
  else if (strcmp("priorities", TheGVName) == 0)
    SetGvValue(priorities, *(short *)TheGVValue);
  else if (strcmp("queueSize", TheGVName) == 0)
    SetGvValue(queueSize, *(short *)TheGVValue);
  else if (strcmp("warningThreshold", TheGVName) == 0)
    SetGvValue(warningThreshold, *(float *)TheGVValue);
  else 
    cerr<<"!! carlisleNoPriorityRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void carlisleNoPriorityRangeStudy::SetGVs(int expNum) {
  SetGvValue(HeatersAtInterval, HeatersAtIntervalValues[expNum]);
  SetGvValue(TimeClock, TimeClockValues[expNum]);
  SetGvValue(freezingThreshold, freezingThresholdValues[expNum]);
  SetGvValue(gapThreshold, gapThresholdValues[expNum]);
  SetGvValue(numSwitch, numSwitchValues[expNum]);
  SetGvValue(phigh, phighValues[expNum]);
  SetGvValue(plow, plowValues[expNum]);
  SetGvValue(pmedium, pmediumValues[expNum]);
  SetGvValue(priorities, prioritiesValues[expNum]);
  SetGvValue(queueSize, queueSizeValues[expNum]);
  SetGvValue(warningThreshold, warningThresholdValues[expNum]);
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new carlisleNoPriorityRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* carlisleNoPriorityRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new rewardSwitchNetPVModel(expandTimeArrays);
  return ThePVModel;
}


