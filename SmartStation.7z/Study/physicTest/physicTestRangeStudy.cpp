
#include "Study/physicTest/physicTestRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
Short TimeClock;
Float freezingThreshold;
Short gapThreshold;
Short initialInternalTemperature;
Short numSwitch;
Short phigh;
Short plow;
Short pmedium;
Short queueSize;
Float warningThreshold;

//********************************************************
//physicTestRangeStudy Constructor
//********************************************************
physicTestRangeStudy::physicTestRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 10;
  NumExps = 1;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("TimeClock");
  GVTypes[0]=strdup("short");
  GVNames[1]=strdup("freezingThreshold");
  GVTypes[1]=strdup("float");
  GVNames[2]=strdup("gapThreshold");
  GVTypes[2]=strdup("short");
  GVNames[3]=strdup("initialInternalTemperature");
  GVTypes[3]=strdup("short");
  GVNames[4]=strdup("numSwitch");
  GVTypes[4]=strdup("short");
  GVNames[5]=strdup("phigh");
  GVTypes[5]=strdup("short");
  GVNames[6]=strdup("plow");
  GVTypes[6]=strdup("short");
  GVNames[7]=strdup("pmedium");
  GVTypes[7]=strdup("short");
  GVNames[8]=strdup("queueSize");
  GVTypes[8]=strdup("short");
  GVNames[9]=strdup("warningThreshold");
  GVTypes[9]=strdup("float");

  // create the arrays to store the values of each gv
  TimeClockValues = new short[NumExps];
  freezingThresholdValues = new float[NumExps];
  gapThresholdValues = new short[NumExps];
  initialInternalTemperatureValues = new short[NumExps];
  numSwitchValues = new short[NumExps];
  phighValues = new short[NumExps];
  plowValues = new short[NumExps];
  pmediumValues = new short[NumExps];
  queueSizeValues = new short[NumExps];
  warningThresholdValues = new float[NumExps];

  // call methods to assign values to each gv
  SetValues_TimeClock();
  SetValues_freezingThreshold();
  SetValues_gapThreshold();
  SetValues_initialInternalTemperature();
  SetValues_numSwitch();
  SetValues_phigh();
  SetValues_plow();
  SetValues_pmedium();
  SetValues_queueSize();
  SetValues_warningThreshold();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//physicTestRangeStudy Destructor
//******************************************************
physicTestRangeStudy::~physicTestRangeStudy() {
  delete [] TimeClockValues;
  delete [] freezingThresholdValues;
  delete [] gapThresholdValues;
  delete [] initialInternalTemperatureValues;
  delete [] numSwitchValues;
  delete [] phighValues;
  delete [] plowValues;
  delete [] pmediumValues;
  delete [] queueSizeValues;
  delete [] warningThresholdValues;
  delete ThePVModel;
}


//******************************************************
// set values for TimeClock
//******************************************************
void physicTestRangeStudy::SetValues_TimeClock() {
  TimeClockValues[0] = 1;
}


//******************************************************
// set values for freezingThreshold
//******************************************************
void physicTestRangeStudy::SetValues_freezingThreshold() {
  freezingThresholdValues[0] = -1000.0;
}


//******************************************************
// set values for gapThreshold
//******************************************************
void physicTestRangeStudy::SetValues_gapThreshold() {
  gapThresholdValues[0] = 0;
}


//******************************************************
// set values for initialInternalTemperature
//******************************************************
void physicTestRangeStudy::SetValues_initialInternalTemperature() {
  initialInternalTemperatureValues[0] = -5;
}


//******************************************************
// set values for numSwitch
//******************************************************
void physicTestRangeStudy::SetValues_numSwitch() {
  numSwitchValues[0] = 1;
}


//******************************************************
// set values for phigh
//******************************************************
void physicTestRangeStudy::SetValues_phigh() {
  phighValues[0] = 23;
}


//******************************************************
// set values for plow
//******************************************************
void physicTestRangeStudy::SetValues_plow() {
  plowValues[0] = 12;
}


//******************************************************
// set values for pmedium
//******************************************************
void physicTestRangeStudy::SetValues_pmedium() {
  pmediumValues[0] = 6;
}


//******************************************************
// set values for queueSize
//******************************************************
void physicTestRangeStudy::SetValues_queueSize() {
  queueSizeValues[0] = 4;
}


//******************************************************
// set values for warningThreshold
//******************************************************
void physicTestRangeStudy::SetValues_warningThreshold() {
  warningThresholdValues[0] = 100.0;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void physicTestRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "TimeClock\tshort\t" << TimeClock << endl;
  cout << "freezingThreshold\tfloat\t" << freezingThreshold << endl;
  cout << "gapThreshold\tshort\t" << gapThreshold << endl;
  cout << "initialInternalTemperature\tshort\t" << initialInternalTemperature << endl;
  cout << "numSwitch\tshort\t" << numSwitch << endl;
  cout << "phigh\tshort\t" << phigh << endl;
  cout << "plow\tshort\t" << plow << endl;
  cout << "pmedium\tshort\t" << pmedium << endl;
  cout << "queueSize\tshort\t" << queueSize << endl;
  cout << "warningThreshold\tfloat\t" << warningThreshold << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *physicTestRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("TimeClock", TheGVName) == 0)
    return &TimeClock;
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    return &freezingThreshold;
  else if (strcmp("gapThreshold", TheGVName) == 0)
    return &gapThreshold;
  else if (strcmp("initialInternalTemperature", TheGVName) == 0)
    return &initialInternalTemperature;
  else if (strcmp("numSwitch", TheGVName) == 0)
    return &numSwitch;
  else if (strcmp("phigh", TheGVName) == 0)
    return &phigh;
  else if (strcmp("plow", TheGVName) == 0)
    return &plow;
  else if (strcmp("pmedium", TheGVName) == 0)
    return &pmedium;
  else if (strcmp("queueSize", TheGVName) == 0)
    return &queueSize;
  else if (strcmp("warningThreshold", TheGVName) == 0)
    return &warningThreshold;
  else 
    cerr<<"!! physicTestRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void physicTestRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("TimeClock", TheGVName) == 0)
    SetGvValue(TimeClock, *(short *)TheGVValue);
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    SetGvValue(freezingThreshold, *(float *)TheGVValue);
  else if (strcmp("gapThreshold", TheGVName) == 0)
    SetGvValue(gapThreshold, *(short *)TheGVValue);
  else if (strcmp("initialInternalTemperature", TheGVName) == 0)
    SetGvValue(initialInternalTemperature, *(short *)TheGVValue);
  else if (strcmp("numSwitch", TheGVName) == 0)
    SetGvValue(numSwitch, *(short *)TheGVValue);
  else if (strcmp("phigh", TheGVName) == 0)
    SetGvValue(phigh, *(short *)TheGVValue);
  else if (strcmp("plow", TheGVName) == 0)
    SetGvValue(plow, *(short *)TheGVValue);
  else if (strcmp("pmedium", TheGVName) == 0)
    SetGvValue(pmedium, *(short *)TheGVValue);
  else if (strcmp("queueSize", TheGVName) == 0)
    SetGvValue(queueSize, *(short *)TheGVValue);
  else if (strcmp("warningThreshold", TheGVName) == 0)
    SetGvValue(warningThreshold, *(float *)TheGVValue);
  else 
    cerr<<"!! physicTestRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void physicTestRangeStudy::SetGVs(int expNum) {
  SetGvValue(TimeClock, TimeClockValues[expNum]);
  SetGvValue(freezingThreshold, freezingThresholdValues[expNum]);
  SetGvValue(gapThreshold, gapThresholdValues[expNum]);
  SetGvValue(initialInternalTemperature, initialInternalTemperatureValues[expNum]);
  SetGvValue(numSwitch, numSwitchValues[expNum]);
  SetGvValue(phigh, phighValues[expNum]);
  SetGvValue(plow, plowValues[expNum]);
  SetGvValue(pmedium, pmediumValues[expNum]);
  SetGvValue(queueSize, queueSizeValues[expNum]);
  SetGvValue(warningThreshold, warningThresholdValues[expNum]);
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new physicTestRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* physicTestRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new physicRewPVModel(expandTimeArrays);
  return ThePVModel;
}


