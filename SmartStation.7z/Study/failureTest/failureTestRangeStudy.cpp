
#include "Study/failureTest/failureTestRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
Float Interval;
Short TimeClock;
Float freezingThreshold;
Short initialInternalTemperature;
Short numSwitch;
Short phigh;
Short plow;
Short pmedium;
Short queueSize;
Float warningThreshold;
Float workingTemperature;

//********************************************************
//failureTestRangeStudy Constructor
//********************************************************
failureTestRangeStudy::failureTestRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 11;
  NumExps = 24;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("Interval");
  GVTypes[0]=strdup("float");
  GVNames[1]=strdup("TimeClock");
  GVTypes[1]=strdup("short");
  GVNames[2]=strdup("freezingThreshold");
  GVTypes[2]=strdup("float");
  GVNames[3]=strdup("initialInternalTemperature");
  GVTypes[3]=strdup("short");
  GVNames[4]=strdup("numSwitch");
  GVTypes[4]=strdup("short");
  GVNames[5]=strdup("phigh");
  GVTypes[5]=strdup("short");
  GVNames[6]=strdup("plow");
  GVTypes[6]=strdup("short");
  GVNames[7]=strdup("pmedium");
  GVTypes[7]=strdup("short");
  GVNames[8]=strdup("queueSize");
  GVTypes[8]=strdup("short");
  GVNames[9]=strdup("warningThreshold");
  GVTypes[9]=strdup("float");
  GVNames[10]=strdup("workingTemperature");
  GVTypes[10]=strdup("float");

  // create the arrays to store the values of each gv
  IntervalValues = new float[NumExps];
  TimeClockValues = new short[NumExps];
  freezingThresholdValues = new float[NumExps];
  initialInternalTemperatureValues = new short[NumExps];
  numSwitchValues = new short[NumExps];
  phighValues = new short[NumExps];
  plowValues = new short[NumExps];
  pmediumValues = new short[NumExps];
  queueSizeValues = new short[NumExps];
  warningThresholdValues = new float[NumExps];
  workingTemperatureValues = new float[NumExps];

  // call methods to assign values to each gv
  SetValues_Interval();
  SetValues_TimeClock();
  SetValues_freezingThreshold();
  SetValues_initialInternalTemperature();
  SetValues_numSwitch();
  SetValues_phigh();
  SetValues_plow();
  SetValues_pmedium();
  SetValues_queueSize();
  SetValues_warningThreshold();
  SetValues_workingTemperature();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//failureTestRangeStudy Destructor
//******************************************************
failureTestRangeStudy::~failureTestRangeStudy() {
  delete [] IntervalValues;
  delete [] TimeClockValues;
  delete [] freezingThresholdValues;
  delete [] initialInternalTemperatureValues;
  delete [] numSwitchValues;
  delete [] phighValues;
  delete [] plowValues;
  delete [] pmediumValues;
  delete [] queueSizeValues;
  delete [] warningThresholdValues;
  delete [] workingTemperatureValues;
  delete ThePVModel;
}


//******************************************************
// set values for Interval
//******************************************************
void failureTestRangeStudy::SetValues_Interval() {
  IntervalValues[0] = 1.2;
  IntervalValues[1] = 2.2;
  IntervalValues[2] = 3.2;
  IntervalValues[3] = 4.2;
  IntervalValues[4] = 5.2;
  IntervalValues[5] = 6.2;
  IntervalValues[6] = 7.2;
  IntervalValues[7] = 8.2;
  IntervalValues[8] = 9.2;
  IntervalValues[9] = 10.2;
  IntervalValues[10] = 11.2;
  IntervalValues[11] = 12.2;
  IntervalValues[12] = 13.2;
  IntervalValues[13] = 14.2;
  IntervalValues[14] = 15.2;
  IntervalValues[15] = 16.2;
  IntervalValues[16] = 17.2;
  IntervalValues[17] = 18.2;
  IntervalValues[18] = 19.2;
  IntervalValues[19] = 20.2;
  IntervalValues[20] = 21.2;
  IntervalValues[21] = 22.2;
  IntervalValues[22] = 23.2;
  IntervalValues[23] = 24.2;
}


//******************************************************
// set values for TimeClock
//******************************************************
void failureTestRangeStudy::SetValues_TimeClock() {
  for (int n=0; n<NumExps; n++)
    TimeClockValues[n] = 1;
}


//******************************************************
// set values for freezingThreshold
//******************************************************
void failureTestRangeStudy::SetValues_freezingThreshold() {
  for (int n=0; n<NumExps; n++)
    freezingThresholdValues[n] = 0;
}


//******************************************************
// set values for initialInternalTemperature
//******************************************************
void failureTestRangeStudy::SetValues_initialInternalTemperature() {
  for (int n=0; n<NumExps; n++)
    initialInternalTemperatureValues[n] = 5;
}


//******************************************************
// set values for numSwitch
//******************************************************
void failureTestRangeStudy::SetValues_numSwitch() {
  for (int n=0; n<NumExps; n++)
    numSwitchValues[n] = 20;
}


//******************************************************
// set values for phigh
//******************************************************
void failureTestRangeStudy::SetValues_phigh() {
  for (int n=0; n<NumExps; n++)
    phighValues[n] = 0;
}


//******************************************************
// set values for plow
//******************************************************
void failureTestRangeStudy::SetValues_plow() {
  for (int n=0; n<NumExps; n++)
    plowValues[n] = 20;
}


//******************************************************
// set values for pmedium
//******************************************************
void failureTestRangeStudy::SetValues_pmedium() {
  for (int n=0; n<NumExps; n++)
    pmediumValues[n] = 0;
}


//******************************************************
// set values for queueSize
//******************************************************
void failureTestRangeStudy::SetValues_queueSize() {
  for (int n=0; n<NumExps; n++)
    queueSizeValues[n] = 20;
}


//******************************************************
// set values for warningThreshold
//******************************************************
void failureTestRangeStudy::SetValues_warningThreshold() {
  for (int n=0; n<NumExps; n++)
    warningThresholdValues[n] = -1000.0;
}


//******************************************************
// set values for workingTemperature
//******************************************************
void failureTestRangeStudy::SetValues_workingTemperature() {
  for (int n=0; n<NumExps; n++)
    workingTemperatureValues[n] = 10.0;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void failureTestRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "Interval\tfloat\t" << Interval << endl;
  cout << "TimeClock\tshort\t" << TimeClock << endl;
  cout << "freezingThreshold\tfloat\t" << freezingThreshold << endl;
  cout << "initialInternalTemperature\tshort\t" << initialInternalTemperature << endl;
  cout << "numSwitch\tshort\t" << numSwitch << endl;
  cout << "phigh\tshort\t" << phigh << endl;
  cout << "plow\tshort\t" << plow << endl;
  cout << "pmedium\tshort\t" << pmedium << endl;
  cout << "queueSize\tshort\t" << queueSize << endl;
  cout << "warningThreshold\tfloat\t" << warningThreshold << endl;
  cout << "workingTemperature\tfloat\t" << workingTemperature << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *failureTestRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("Interval", TheGVName) == 0)
    return &Interval;
  else if (strcmp("TimeClock", TheGVName) == 0)
    return &TimeClock;
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    return &freezingThreshold;
  else if (strcmp("initialInternalTemperature", TheGVName) == 0)
    return &initialInternalTemperature;
  else if (strcmp("numSwitch", TheGVName) == 0)
    return &numSwitch;
  else if (strcmp("phigh", TheGVName) == 0)
    return &phigh;
  else if (strcmp("plow", TheGVName) == 0)
    return &plow;
  else if (strcmp("pmedium", TheGVName) == 0)
    return &pmedium;
  else if (strcmp("queueSize", TheGVName) == 0)
    return &queueSize;
  else if (strcmp("warningThreshold", TheGVName) == 0)
    return &warningThreshold;
  else if (strcmp("workingTemperature", TheGVName) == 0)
    return &workingTemperature;
  else 
    cerr<<"!! failureTestRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void failureTestRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("Interval", TheGVName) == 0)
    SetGvValue(Interval, *(float *)TheGVValue);
  else if (strcmp("TimeClock", TheGVName) == 0)
    SetGvValue(TimeClock, *(short *)TheGVValue);
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    SetGvValue(freezingThreshold, *(float *)TheGVValue);
  else if (strcmp("initialInternalTemperature", TheGVName) == 0)
    SetGvValue(initialInternalTemperature, *(short *)TheGVValue);
  else if (strcmp("numSwitch", TheGVName) == 0)
    SetGvValue(numSwitch, *(short *)TheGVValue);
  else if (strcmp("phigh", TheGVName) == 0)
    SetGvValue(phigh, *(short *)TheGVValue);
  else if (strcmp("plow", TheGVName) == 0)
    SetGvValue(plow, *(short *)TheGVValue);
  else if (strcmp("pmedium", TheGVName) == 0)
    SetGvValue(pmedium, *(short *)TheGVValue);
  else if (strcmp("queueSize", TheGVName) == 0)
    SetGvValue(queueSize, *(short *)TheGVValue);
  else if (strcmp("warningThreshold", TheGVName) == 0)
    SetGvValue(warningThreshold, *(float *)TheGVValue);
  else if (strcmp("workingTemperature", TheGVName) == 0)
    SetGvValue(workingTemperature, *(float *)TheGVValue);
  else 
    cerr<<"!! failureTestRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void failureTestRangeStudy::SetGVs(int expNum) {
  SetGvValue(Interval, IntervalValues[expNum]);
  SetGvValue(TimeClock, TimeClockValues[expNum]);
  SetGvValue(freezingThreshold, freezingThresholdValues[expNum]);
  SetGvValue(initialInternalTemperature, initialInternalTemperatureValues[expNum]);
  SetGvValue(numSwitch, numSwitchValues[expNum]);
  SetGvValue(phigh, phighValues[expNum]);
  SetGvValue(plow, plowValues[expNum]);
  SetGvValue(pmedium, pmediumValues[expNum]);
  SetGvValue(queueSize, queueSizeValues[expNum]);
  SetGvValue(warningThreshold, warningThresholdValues[expNum]);
  SetGvValue(workingTemperature, workingTemperatureValues[expNum]);
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new failureTestRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* failureTestRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new failureRewardPVModel(expandTimeArrays);
  return ThePVModel;
}


