
#include "Study/carlislePriorityHeaterPerTimeBadThresholds/carlislePriorityHeaterPerTimeBadThresholdsRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
Float HeatersAtInterval;
Short TimeClock;
Float freezingThreshold;
Short gapThreshold;
Short numSwitch;
Short phigh;
Short plow;
Short pmedium;
Short priorities;
Short queueSize;
Float warningThreshold;

//********************************************************
//carlislePriorityHeaterPerTimeBadThresholdsRangeStudy Constructor
//********************************************************
carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::carlislePriorityHeaterPerTimeBadThresholdsRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 11;
  NumExps = 100;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("HeatersAtInterval");
  GVTypes[0]=strdup("float");
  GVNames[1]=strdup("TimeClock");
  GVTypes[1]=strdup("short");
  GVNames[2]=strdup("freezingThreshold");
  GVTypes[2]=strdup("float");
  GVNames[3]=strdup("gapThreshold");
  GVTypes[3]=strdup("short");
  GVNames[4]=strdup("numSwitch");
  GVTypes[4]=strdup("short");
  GVNames[5]=strdup("phigh");
  GVTypes[5]=strdup("short");
  GVNames[6]=strdup("plow");
  GVTypes[6]=strdup("short");
  GVNames[7]=strdup("pmedium");
  GVTypes[7]=strdup("short");
  GVNames[8]=strdup("priorities");
  GVTypes[8]=strdup("short");
  GVNames[9]=strdup("queueSize");
  GVTypes[9]=strdup("short");
  GVNames[10]=strdup("warningThreshold");
  GVTypes[10]=strdup("float");

  // create the arrays to store the values of each gv
  HeatersAtIntervalValues = new float[NumExps];
  TimeClockValues = new short[NumExps];
  freezingThresholdValues = new float[NumExps];
  gapThresholdValues = new short[NumExps];
  numSwitchValues = new short[NumExps];
  phighValues = new short[NumExps];
  plowValues = new short[NumExps];
  pmediumValues = new short[NumExps];
  prioritiesValues = new short[NumExps];
  queueSizeValues = new short[NumExps];
  warningThresholdValues = new float[NumExps];

  // call methods to assign values to each gv
  SetValues_HeatersAtInterval();
  SetValues_TimeClock();
  SetValues_freezingThreshold();
  SetValues_gapThreshold();
  SetValues_numSwitch();
  SetValues_phigh();
  SetValues_plow();
  SetValues_pmedium();
  SetValues_priorities();
  SetValues_queueSize();
  SetValues_warningThreshold();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//carlislePriorityHeaterPerTimeBadThresholdsRangeStudy Destructor
//******************************************************
carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::~carlislePriorityHeaterPerTimeBadThresholdsRangeStudy() {
  delete [] HeatersAtIntervalValues;
  delete [] TimeClockValues;
  delete [] freezingThresholdValues;
  delete [] gapThresholdValues;
  delete [] numSwitchValues;
  delete [] phighValues;
  delete [] plowValues;
  delete [] pmediumValues;
  delete [] prioritiesValues;
  delete [] queueSizeValues;
  delete [] warningThresholdValues;
  delete ThePVModel;
}


//******************************************************
// set values for HeatersAtInterval
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetValues_HeatersAtInterval() {
  HeatersAtIntervalValues[0] = 1.5;
  HeatersAtIntervalValues[1] = 2.5;
  HeatersAtIntervalValues[2] = 3.5;
  HeatersAtIntervalValues[3] = 4.5;
  HeatersAtIntervalValues[4] = 5.5;
  HeatersAtIntervalValues[5] = 6.5;
  HeatersAtIntervalValues[6] = 7.5;
  HeatersAtIntervalValues[7] = 8.5;
  HeatersAtIntervalValues[8] = 9.5;
  HeatersAtIntervalValues[9] = 10.5;
  HeatersAtIntervalValues[10] = 11.5;
  HeatersAtIntervalValues[11] = 12.5;
  HeatersAtIntervalValues[12] = 13.5;
  HeatersAtIntervalValues[13] = 14.5;
  HeatersAtIntervalValues[14] = 15.5;
  HeatersAtIntervalValues[15] = 16.5;
  HeatersAtIntervalValues[16] = 17.5;
  HeatersAtIntervalValues[17] = 18.5;
  HeatersAtIntervalValues[18] = 19.5;
  HeatersAtIntervalValues[19] = 20.5;
  HeatersAtIntervalValues[20] = 21.5;
  HeatersAtIntervalValues[21] = 22.5;
  HeatersAtIntervalValues[22] = 23.5;
  HeatersAtIntervalValues[23] = 24.5;
  HeatersAtIntervalValues[24] = 25.5;
  HeatersAtIntervalValues[25] = 1.5;
  HeatersAtIntervalValues[26] = 2.5;
  HeatersAtIntervalValues[27] = 3.5;
  HeatersAtIntervalValues[28] = 4.5;
  HeatersAtIntervalValues[29] = 5.5;
  HeatersAtIntervalValues[30] = 6.5;
  HeatersAtIntervalValues[31] = 7.5;
  HeatersAtIntervalValues[32] = 8.5;
  HeatersAtIntervalValues[33] = 9.5;
  HeatersAtIntervalValues[34] = 10.5;
  HeatersAtIntervalValues[35] = 11.5;
  HeatersAtIntervalValues[36] = 12.5;
  HeatersAtIntervalValues[37] = 13.5;
  HeatersAtIntervalValues[38] = 14.5;
  HeatersAtIntervalValues[39] = 15.5;
  HeatersAtIntervalValues[40] = 16.5;
  HeatersAtIntervalValues[41] = 17.5;
  HeatersAtIntervalValues[42] = 18.5;
  HeatersAtIntervalValues[43] = 19.5;
  HeatersAtIntervalValues[44] = 20.5;
  HeatersAtIntervalValues[45] = 21.5;
  HeatersAtIntervalValues[46] = 22.5;
  HeatersAtIntervalValues[47] = 23.5;
  HeatersAtIntervalValues[48] = 24.5;
  HeatersAtIntervalValues[49] = 25.5;
  HeatersAtIntervalValues[50] = 1.5;
  HeatersAtIntervalValues[51] = 2.5;
  HeatersAtIntervalValues[52] = 3.5;
  HeatersAtIntervalValues[53] = 4.5;
  HeatersAtIntervalValues[54] = 5.5;
  HeatersAtIntervalValues[55] = 6.5;
  HeatersAtIntervalValues[56] = 7.5;
  HeatersAtIntervalValues[57] = 8.5;
  HeatersAtIntervalValues[58] = 9.5;
  HeatersAtIntervalValues[59] = 10.5;
  HeatersAtIntervalValues[60] = 11.5;
  HeatersAtIntervalValues[61] = 12.5;
  HeatersAtIntervalValues[62] = 13.5;
  HeatersAtIntervalValues[63] = 14.5;
  HeatersAtIntervalValues[64] = 15.5;
  HeatersAtIntervalValues[65] = 16.5;
  HeatersAtIntervalValues[66] = 17.5;
  HeatersAtIntervalValues[67] = 18.5;
  HeatersAtIntervalValues[68] = 19.5;
  HeatersAtIntervalValues[69] = 20.5;
  HeatersAtIntervalValues[70] = 21.5;
  HeatersAtIntervalValues[71] = 22.5;
  HeatersAtIntervalValues[72] = 23.5;
  HeatersAtIntervalValues[73] = 24.5;
  HeatersAtIntervalValues[74] = 25.5;
  HeatersAtIntervalValues[75] = 1.5;
  HeatersAtIntervalValues[76] = 2.5;
  HeatersAtIntervalValues[77] = 3.5;
  HeatersAtIntervalValues[78] = 4.5;
  HeatersAtIntervalValues[79] = 5.5;
  HeatersAtIntervalValues[80] = 6.5;
  HeatersAtIntervalValues[81] = 7.5;
  HeatersAtIntervalValues[82] = 8.5;
  HeatersAtIntervalValues[83] = 9.5;
  HeatersAtIntervalValues[84] = 10.5;
  HeatersAtIntervalValues[85] = 11.5;
  HeatersAtIntervalValues[86] = 12.5;
  HeatersAtIntervalValues[87] = 13.5;
  HeatersAtIntervalValues[88] = 14.5;
  HeatersAtIntervalValues[89] = 15.5;
  HeatersAtIntervalValues[90] = 16.5;
  HeatersAtIntervalValues[91] = 17.5;
  HeatersAtIntervalValues[92] = 18.5;
  HeatersAtIntervalValues[93] = 19.5;
  HeatersAtIntervalValues[94] = 20.5;
  HeatersAtIntervalValues[95] = 21.5;
  HeatersAtIntervalValues[96] = 22.5;
  HeatersAtIntervalValues[97] = 23.5;
  HeatersAtIntervalValues[98] = 24.5;
  HeatersAtIntervalValues[99] = 25.5;
}


//******************************************************
// set values for TimeClock
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetValues_TimeClock() {
  for (int n=0; n<NumExps; n++)
    TimeClockValues[n] = 1;
}


//******************************************************
// set values for freezingThreshold
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetValues_freezingThreshold() {
  for (int n=0; n<NumExps; n++)
    freezingThresholdValues[n] = 0.0;
}


//******************************************************
// set values for gapThreshold
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetValues_gapThreshold() {
  for (int n=0; n<NumExps; n++)
    gapThresholdValues[n] = 8;
}


//******************************************************
// set values for numSwitch
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetValues_numSwitch() {
  for (int n=0; n<NumExps; n++)
    numSwitchValues[n] = 41;
}


//******************************************************
// set values for phigh
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetValues_phigh() {
  for (int n=0; n<NumExps; n++)
    phighValues[n] = 23;
}


//******************************************************
// set values for plow
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetValues_plow() {
  for (int n=0; n<NumExps; n++)
    plowValues[n] = 12;
}


//******************************************************
// set values for pmedium
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetValues_pmedium() {
  for (int n=0; n<NumExps; n++)
    pmediumValues[n] = 6;
}


//******************************************************
// set values for priorities
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetValues_priorities() {
  prioritiesValues[0] = 1;
  prioritiesValues[1] = 1;
  prioritiesValues[2] = 1;
  prioritiesValues[3] = 1;
  prioritiesValues[4] = 1;
  prioritiesValues[5] = 1;
  prioritiesValues[6] = 1;
  prioritiesValues[7] = 1;
  prioritiesValues[8] = 1;
  prioritiesValues[9] = 1;
  prioritiesValues[10] = 1;
  prioritiesValues[11] = 1;
  prioritiesValues[12] = 1;
  prioritiesValues[13] = 1;
  prioritiesValues[14] = 1;
  prioritiesValues[15] = 1;
  prioritiesValues[16] = 1;
  prioritiesValues[17] = 1;
  prioritiesValues[18] = 1;
  prioritiesValues[19] = 1;
  prioritiesValues[20] = 1;
  prioritiesValues[21] = 1;
  prioritiesValues[22] = 1;
  prioritiesValues[23] = 1;
  prioritiesValues[24] = 1;
  prioritiesValues[25] = 2;
  prioritiesValues[26] = 2;
  prioritiesValues[27] = 2;
  prioritiesValues[28] = 2;
  prioritiesValues[29] = 2;
  prioritiesValues[30] = 2;
  prioritiesValues[31] = 2;
  prioritiesValues[32] = 2;
  prioritiesValues[33] = 2;
  prioritiesValues[34] = 2;
  prioritiesValues[35] = 2;
  prioritiesValues[36] = 2;
  prioritiesValues[37] = 2;
  prioritiesValues[38] = 2;
  prioritiesValues[39] = 2;
  prioritiesValues[40] = 2;
  prioritiesValues[41] = 2;
  prioritiesValues[42] = 2;
  prioritiesValues[43] = 2;
  prioritiesValues[44] = 2;
  prioritiesValues[45] = 2;
  prioritiesValues[46] = 2;
  prioritiesValues[47] = 2;
  prioritiesValues[48] = 2;
  prioritiesValues[49] = 2;
  prioritiesValues[50] = 3;
  prioritiesValues[51] = 3;
  prioritiesValues[52] = 3;
  prioritiesValues[53] = 3;
  prioritiesValues[54] = 3;
  prioritiesValues[55] = 3;
  prioritiesValues[56] = 3;
  prioritiesValues[57] = 3;
  prioritiesValues[58] = 3;
  prioritiesValues[59] = 3;
  prioritiesValues[60] = 3;
  prioritiesValues[61] = 3;
  prioritiesValues[62] = 3;
  prioritiesValues[63] = 3;
  prioritiesValues[64] = 3;
  prioritiesValues[65] = 3;
  prioritiesValues[66] = 3;
  prioritiesValues[67] = 3;
  prioritiesValues[68] = 3;
  prioritiesValues[69] = 3;
  prioritiesValues[70] = 3;
  prioritiesValues[71] = 3;
  prioritiesValues[72] = 3;
  prioritiesValues[73] = 3;
  prioritiesValues[74] = 3;
  prioritiesValues[75] = 4;
  prioritiesValues[76] = 4;
  prioritiesValues[77] = 4;
  prioritiesValues[78] = 4;
  prioritiesValues[79] = 4;
  prioritiesValues[80] = 4;
  prioritiesValues[81] = 4;
  prioritiesValues[82] = 4;
  prioritiesValues[83] = 4;
  prioritiesValues[84] = 4;
  prioritiesValues[85] = 4;
  prioritiesValues[86] = 4;
  prioritiesValues[87] = 4;
  prioritiesValues[88] = 4;
  prioritiesValues[89] = 4;
  prioritiesValues[90] = 4;
  prioritiesValues[91] = 4;
  prioritiesValues[92] = 4;
  prioritiesValues[93] = 4;
  prioritiesValues[94] = 4;
  prioritiesValues[95] = 4;
  prioritiesValues[96] = 4;
  prioritiesValues[97] = 4;
  prioritiesValues[98] = 4;
  prioritiesValues[99] = 4;
}


//******************************************************
// set values for queueSize
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetValues_queueSize() {
  for (int n=0; n<NumExps; n++)
    queueSizeValues[n] = 21;
}


//******************************************************
// set values for warningThreshold
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetValues_warningThreshold() {
  for (int n=0; n<NumExps; n++)
    warningThresholdValues[n] = 17.0;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "HeatersAtInterval\tfloat\t" << HeatersAtInterval << endl;
  cout << "TimeClock\tshort\t" << TimeClock << endl;
  cout << "freezingThreshold\tfloat\t" << freezingThreshold << endl;
  cout << "gapThreshold\tshort\t" << gapThreshold << endl;
  cout << "numSwitch\tshort\t" << numSwitch << endl;
  cout << "phigh\tshort\t" << phigh << endl;
  cout << "plow\tshort\t" << plow << endl;
  cout << "pmedium\tshort\t" << pmedium << endl;
  cout << "priorities\tshort\t" << priorities << endl;
  cout << "queueSize\tshort\t" << queueSize << endl;
  cout << "warningThreshold\tfloat\t" << warningThreshold << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("HeatersAtInterval", TheGVName) == 0)
    return &HeatersAtInterval;
  else if (strcmp("TimeClock", TheGVName) == 0)
    return &TimeClock;
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    return &freezingThreshold;
  else if (strcmp("gapThreshold", TheGVName) == 0)
    return &gapThreshold;
  else if (strcmp("numSwitch", TheGVName) == 0)
    return &numSwitch;
  else if (strcmp("phigh", TheGVName) == 0)
    return &phigh;
  else if (strcmp("plow", TheGVName) == 0)
    return &plow;
  else if (strcmp("pmedium", TheGVName) == 0)
    return &pmedium;
  else if (strcmp("priorities", TheGVName) == 0)
    return &priorities;
  else if (strcmp("queueSize", TheGVName) == 0)
    return &queueSize;
  else if (strcmp("warningThreshold", TheGVName) == 0)
    return &warningThreshold;
  else 
    cerr<<"!! carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("HeatersAtInterval", TheGVName) == 0)
    SetGvValue(HeatersAtInterval, *(float *)TheGVValue);
  else if (strcmp("TimeClock", TheGVName) == 0)
    SetGvValue(TimeClock, *(short *)TheGVValue);
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    SetGvValue(freezingThreshold, *(float *)TheGVValue);
  else if (strcmp("gapThreshold", TheGVName) == 0)
    SetGvValue(gapThreshold, *(short *)TheGVValue);
  else if (strcmp("numSwitch", TheGVName) == 0)
    SetGvValue(numSwitch, *(short *)TheGVValue);
  else if (strcmp("phigh", TheGVName) == 0)
    SetGvValue(phigh, *(short *)TheGVValue);
  else if (strcmp("plow", TheGVName) == 0)
    SetGvValue(plow, *(short *)TheGVValue);
  else if (strcmp("pmedium", TheGVName) == 0)
    SetGvValue(pmedium, *(short *)TheGVValue);
  else if (strcmp("priorities", TheGVName) == 0)
    SetGvValue(priorities, *(short *)TheGVValue);
  else if (strcmp("queueSize", TheGVName) == 0)
    SetGvValue(queueSize, *(short *)TheGVValue);
  else if (strcmp("warningThreshold", TheGVName) == 0)
    SetGvValue(warningThreshold, *(float *)TheGVValue);
  else 
    cerr<<"!! carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::SetGVs(int expNum) {
  SetGvValue(HeatersAtInterval, HeatersAtIntervalValues[expNum]);
  SetGvValue(TimeClock, TimeClockValues[expNum]);
  SetGvValue(freezingThreshold, freezingThresholdValues[expNum]);
  SetGvValue(gapThreshold, gapThresholdValues[expNum]);
  SetGvValue(numSwitch, numSwitchValues[expNum]);
  SetGvValue(phigh, phighValues[expNum]);
  SetGvValue(plow, plowValues[expNum]);
  SetGvValue(pmedium, pmediumValues[expNum]);
  SetGvValue(priorities, prioritiesValues[expNum]);
  SetGvValue(queueSize, queueSizeValues[expNum]);
  SetGvValue(warningThreshold, warningThresholdValues[expNum]);
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new carlislePriorityHeaterPerTimeBadThresholdsRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* carlislePriorityHeaterPerTimeBadThresholdsRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new ActivatedHeatersPerTimePVModel(expandTimeArrays);
  return ThePVModel;
}


