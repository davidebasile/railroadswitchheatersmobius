
#ifndef carlislePriorityRangeSTUDY_H_
#define carlislePriorityRangeSTUDY_H_

#include "Reward/rewardSwitchNet/rewardSwitchNetPVNodes.h"
#include "Reward/rewardSwitchNet/rewardSwitchNetPVModel.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/Study/BaseStudyClass.hpp"

extern Float HeatersAtInterval;
extern Short TimeClock;
extern Float freezingThreshold;
extern Short gapThreshold;
extern Short numSwitch;
extern Short phigh;
extern Short plow;
extern Short pmedium;
extern Short priorities;
extern Short queueSize;
extern Float warningThreshold;

class carlislePriorityRangeStudy : public BaseStudyClass {
public:

carlislePriorityRangeStudy();
~carlislePriorityRangeStudy();

private:

float *HeatersAtIntervalValues;
short *TimeClockValues;
float *freezingThresholdValues;
short *gapThresholdValues;
short *numSwitchValues;
short *phighValues;
short *plowValues;
short *pmediumValues;
short *prioritiesValues;
short *queueSizeValues;
float *warningThresholdValues;

void SetValues_HeatersAtInterval();
void SetValues_TimeClock();
void SetValues_freezingThreshold();
void SetValues_gapThreshold();
void SetValues_numSwitch();
void SetValues_phigh();
void SetValues_plow();
void SetValues_pmedium();
void SetValues_priorities();
void SetValues_queueSize();
void SetValues_warningThreshold();

void PrintGlobalValues(int);
void *GetGVValue(char *TheGVName);
void OverrideGVValue(char *TheGVName, void *TheGVValue);
void SetGVs(int expnum);
PVModel *GetPVModel(bool expandTimeArrays);
};

#endif

