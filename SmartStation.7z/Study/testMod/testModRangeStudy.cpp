
#include "Study/testMod/testModRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
Short ID;
Float Interval;
Short TimeClock;
Float freezingThreshold;
Short gapThreshold;
Short numSwitch;
Short phigh;
Short plow;
Short pmedium;
Short queueSize;
Float warningThreshold;

//********************************************************
//testModRangeStudy Constructor
//********************************************************
testModRangeStudy::testModRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 11;
  NumExps = 144;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("ID");
  GVTypes[0]=strdup("short");
  GVNames[1]=strdup("Interval");
  GVTypes[1]=strdup("float");
  GVNames[2]=strdup("TimeClock");
  GVTypes[2]=strdup("short");
  GVNames[3]=strdup("freezingThreshold");
  GVTypes[3]=strdup("float");
  GVNames[4]=strdup("gapThreshold");
  GVTypes[4]=strdup("short");
  GVNames[5]=strdup("numSwitch");
  GVTypes[5]=strdup("short");
  GVNames[6]=strdup("phigh");
  GVTypes[6]=strdup("short");
  GVNames[7]=strdup("plow");
  GVTypes[7]=strdup("short");
  GVNames[8]=strdup("pmedium");
  GVTypes[8]=strdup("short");
  GVNames[9]=strdup("queueSize");
  GVTypes[9]=strdup("short");
  GVNames[10]=strdup("warningThreshold");
  GVTypes[10]=strdup("float");

  // create the arrays to store the values of each gv
  IDValues = new short[NumExps];
  IntervalValues = new float[NumExps];
  TimeClockValues = new short[NumExps];
  freezingThresholdValues = new float[NumExps];
  gapThresholdValues = new short[NumExps];
  numSwitchValues = new short[NumExps];
  phighValues = new short[NumExps];
  plowValues = new short[NumExps];
  pmediumValues = new short[NumExps];
  queueSizeValues = new short[NumExps];
  warningThresholdValues = new float[NumExps];

  // call methods to assign values to each gv
  SetValues_ID();
  SetValues_Interval();
  SetValues_TimeClock();
  SetValues_freezingThreshold();
  SetValues_gapThreshold();
  SetValues_numSwitch();
  SetValues_phigh();
  SetValues_plow();
  SetValues_pmedium();
  SetValues_queueSize();
  SetValues_warningThreshold();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//testModRangeStudy Destructor
//******************************************************
testModRangeStudy::~testModRangeStudy() {
  delete [] IDValues;
  delete [] IntervalValues;
  delete [] TimeClockValues;
  delete [] freezingThresholdValues;
  delete [] gapThresholdValues;
  delete [] numSwitchValues;
  delete [] phighValues;
  delete [] plowValues;
  delete [] pmediumValues;
  delete [] queueSizeValues;
  delete [] warningThresholdValues;
  delete ThePVModel;
}


//******************************************************
// set values for ID
//******************************************************
void testModRangeStudy::SetValues_ID() {
  IDValues[0] = 1;
  IDValues[1] = 2;
  IDValues[2] = 3;
  IDValues[3] = 4;
  IDValues[4] = 5;
  IDValues[5] = 6;
  IDValues[6] = 1;
  IDValues[7] = 2;
  IDValues[8] = 3;
  IDValues[9] = 4;
  IDValues[10] = 5;
  IDValues[11] = 6;
  IDValues[12] = 1;
  IDValues[13] = 2;
  IDValues[14] = 3;
  IDValues[15] = 4;
  IDValues[16] = 5;
  IDValues[17] = 6;
  IDValues[18] = 1;
  IDValues[19] = 2;
  IDValues[20] = 3;
  IDValues[21] = 4;
  IDValues[22] = 5;
  IDValues[23] = 6;
  IDValues[24] = 1;
  IDValues[25] = 2;
  IDValues[26] = 3;
  IDValues[27] = 4;
  IDValues[28] = 5;
  IDValues[29] = 6;
  IDValues[30] = 1;
  IDValues[31] = 2;
  IDValues[32] = 3;
  IDValues[33] = 4;
  IDValues[34] = 5;
  IDValues[35] = 6;
  IDValues[36] = 1;
  IDValues[37] = 2;
  IDValues[38] = 3;
  IDValues[39] = 4;
  IDValues[40] = 5;
  IDValues[41] = 6;
  IDValues[42] = 1;
  IDValues[43] = 2;
  IDValues[44] = 3;
  IDValues[45] = 4;
  IDValues[46] = 5;
  IDValues[47] = 6;
  IDValues[48] = 1;
  IDValues[49] = 2;
  IDValues[50] = 3;
  IDValues[51] = 4;
  IDValues[52] = 5;
  IDValues[53] = 6;
  IDValues[54] = 1;
  IDValues[55] = 2;
  IDValues[56] = 3;
  IDValues[57] = 4;
  IDValues[58] = 5;
  IDValues[59] = 6;
  IDValues[60] = 1;
  IDValues[61] = 2;
  IDValues[62] = 3;
  IDValues[63] = 4;
  IDValues[64] = 5;
  IDValues[65] = 6;
  IDValues[66] = 1;
  IDValues[67] = 2;
  IDValues[68] = 3;
  IDValues[69] = 4;
  IDValues[70] = 5;
  IDValues[71] = 6;
  IDValues[72] = 1;
  IDValues[73] = 2;
  IDValues[74] = 3;
  IDValues[75] = 4;
  IDValues[76] = 5;
  IDValues[77] = 6;
  IDValues[78] = 1;
  IDValues[79] = 2;
  IDValues[80] = 3;
  IDValues[81] = 4;
  IDValues[82] = 5;
  IDValues[83] = 6;
  IDValues[84] = 1;
  IDValues[85] = 2;
  IDValues[86] = 3;
  IDValues[87] = 4;
  IDValues[88] = 5;
  IDValues[89] = 6;
  IDValues[90] = 1;
  IDValues[91] = 2;
  IDValues[92] = 3;
  IDValues[93] = 4;
  IDValues[94] = 5;
  IDValues[95] = 6;
  IDValues[96] = 1;
  IDValues[97] = 2;
  IDValues[98] = 3;
  IDValues[99] = 4;
  IDValues[100] = 5;
  IDValues[101] = 6;
  IDValues[102] = 1;
  IDValues[103] = 2;
  IDValues[104] = 3;
  IDValues[105] = 4;
  IDValues[106] = 5;
  IDValues[107] = 6;
  IDValues[108] = 1;
  IDValues[109] = 2;
  IDValues[110] = 3;
  IDValues[111] = 4;
  IDValues[112] = 5;
  IDValues[113] = 6;
  IDValues[114] = 1;
  IDValues[115] = 2;
  IDValues[116] = 3;
  IDValues[117] = 4;
  IDValues[118] = 5;
  IDValues[119] = 6;
  IDValues[120] = 1;
  IDValues[121] = 2;
  IDValues[122] = 3;
  IDValues[123] = 4;
  IDValues[124] = 5;
  IDValues[125] = 6;
  IDValues[126] = 1;
  IDValues[127] = 2;
  IDValues[128] = 3;
  IDValues[129] = 4;
  IDValues[130] = 5;
  IDValues[131] = 6;
  IDValues[132] = 1;
  IDValues[133] = 2;
  IDValues[134] = 3;
  IDValues[135] = 4;
  IDValues[136] = 5;
  IDValues[137] = 6;
  IDValues[138] = 1;
  IDValues[139] = 2;
  IDValues[140] = 3;
  IDValues[141] = 4;
  IDValues[142] = 5;
  IDValues[143] = 6;
}


//******************************************************
// set values for Interval
//******************************************************
void testModRangeStudy::SetValues_Interval() {
  IntervalValues[0] = 1.5;
  IntervalValues[1] = 1.5;
  IntervalValues[2] = 1.5;
  IntervalValues[3] = 1.5;
  IntervalValues[4] = 1.5;
  IntervalValues[5] = 1.5;
  IntervalValues[6] = 2.5;
  IntervalValues[7] = 2.5;
  IntervalValues[8] = 2.5;
  IntervalValues[9] = 2.5;
  IntervalValues[10] = 2.5;
  IntervalValues[11] = 2.5;
  IntervalValues[12] = 3.5;
  IntervalValues[13] = 3.5;
  IntervalValues[14] = 3.5;
  IntervalValues[15] = 3.5;
  IntervalValues[16] = 3.5;
  IntervalValues[17] = 3.5;
  IntervalValues[18] = 4.5;
  IntervalValues[19] = 4.5;
  IntervalValues[20] = 4.5;
  IntervalValues[21] = 4.5;
  IntervalValues[22] = 4.5;
  IntervalValues[23] = 4.5;
  IntervalValues[24] = 5.5;
  IntervalValues[25] = 5.5;
  IntervalValues[26] = 5.5;
  IntervalValues[27] = 5.5;
  IntervalValues[28] = 5.5;
  IntervalValues[29] = 5.5;
  IntervalValues[30] = 6.5;
  IntervalValues[31] = 6.5;
  IntervalValues[32] = 6.5;
  IntervalValues[33] = 6.5;
  IntervalValues[34] = 6.5;
  IntervalValues[35] = 6.5;
  IntervalValues[36] = 7.5;
  IntervalValues[37] = 7.5;
  IntervalValues[38] = 7.5;
  IntervalValues[39] = 7.5;
  IntervalValues[40] = 7.5;
  IntervalValues[41] = 7.5;
  IntervalValues[42] = 8.5;
  IntervalValues[43] = 8.5;
  IntervalValues[44] = 8.5;
  IntervalValues[45] = 8.5;
  IntervalValues[46] = 8.5;
  IntervalValues[47] = 8.5;
  IntervalValues[48] = 9.5;
  IntervalValues[49] = 9.5;
  IntervalValues[50] = 9.5;
  IntervalValues[51] = 9.5;
  IntervalValues[52] = 9.5;
  IntervalValues[53] = 9.5;
  IntervalValues[54] = 10.5;
  IntervalValues[55] = 10.5;
  IntervalValues[56] = 10.5;
  IntervalValues[57] = 10.5;
  IntervalValues[58] = 10.5;
  IntervalValues[59] = 10.5;
  IntervalValues[60] = 11.5;
  IntervalValues[61] = 11.5;
  IntervalValues[62] = 11.5;
  IntervalValues[63] = 11.5;
  IntervalValues[64] = 11.5;
  IntervalValues[65] = 11.5;
  IntervalValues[66] = 12.5;
  IntervalValues[67] = 12.5;
  IntervalValues[68] = 12.5;
  IntervalValues[69] = 12.5;
  IntervalValues[70] = 12.5;
  IntervalValues[71] = 12.5;
  IntervalValues[72] = 13.5;
  IntervalValues[73] = 13.5;
  IntervalValues[74] = 13.5;
  IntervalValues[75] = 13.5;
  IntervalValues[76] = 13.5;
  IntervalValues[77] = 13.5;
  IntervalValues[78] = 14.5;
  IntervalValues[79] = 14.5;
  IntervalValues[80] = 14.5;
  IntervalValues[81] = 14.5;
  IntervalValues[82] = 14.5;
  IntervalValues[83] = 14.5;
  IntervalValues[84] = 15.5;
  IntervalValues[85] = 15.5;
  IntervalValues[86] = 15.5;
  IntervalValues[87] = 15.5;
  IntervalValues[88] = 15.5;
  IntervalValues[89] = 15.5;
  IntervalValues[90] = 16.5;
  IntervalValues[91] = 16.5;
  IntervalValues[92] = 16.5;
  IntervalValues[93] = 16.5;
  IntervalValues[94] = 16.5;
  IntervalValues[95] = 16.5;
  IntervalValues[96] = 17.5;
  IntervalValues[97] = 17.5;
  IntervalValues[98] = 17.5;
  IntervalValues[99] = 17.5;
  IntervalValues[100] = 17.5;
  IntervalValues[101] = 17.5;
  IntervalValues[102] = 18.5;
  IntervalValues[103] = 18.5;
  IntervalValues[104] = 18.5;
  IntervalValues[105] = 18.5;
  IntervalValues[106] = 18.5;
  IntervalValues[107] = 18.5;
  IntervalValues[108] = 19.5;
  IntervalValues[109] = 19.5;
  IntervalValues[110] = 19.5;
  IntervalValues[111] = 19.5;
  IntervalValues[112] = 19.5;
  IntervalValues[113] = 19.5;
  IntervalValues[114] = 20.5;
  IntervalValues[115] = 20.5;
  IntervalValues[116] = 20.5;
  IntervalValues[117] = 20.5;
  IntervalValues[118] = 20.5;
  IntervalValues[119] = 20.5;
  IntervalValues[120] = 21.5;
  IntervalValues[121] = 21.5;
  IntervalValues[122] = 21.5;
  IntervalValues[123] = 21.5;
  IntervalValues[124] = 21.5;
  IntervalValues[125] = 21.5;
  IntervalValues[126] = 22.5;
  IntervalValues[127] = 22.5;
  IntervalValues[128] = 22.5;
  IntervalValues[129] = 22.5;
  IntervalValues[130] = 22.5;
  IntervalValues[131] = 22.5;
  IntervalValues[132] = 23.5;
  IntervalValues[133] = 23.5;
  IntervalValues[134] = 23.5;
  IntervalValues[135] = 23.5;
  IntervalValues[136] = 23.5;
  IntervalValues[137] = 23.5;
  IntervalValues[138] = 24.5;
  IntervalValues[139] = 24.5;
  IntervalValues[140] = 24.5;
  IntervalValues[141] = 24.5;
  IntervalValues[142] = 24.5;
  IntervalValues[143] = 24.5;
}


//******************************************************
// set values for TimeClock
//******************************************************
void testModRangeStudy::SetValues_TimeClock() {
  for (int n=0; n<NumExps; n++)
    TimeClockValues[n] = 1;
}


//******************************************************
// set values for freezingThreshold
//******************************************************
void testModRangeStudy::SetValues_freezingThreshold() {
  for (int n=0; n<NumExps; n++)
    freezingThresholdValues[n] = 0.0;
}


//******************************************************
// set values for gapThreshold
//******************************************************
void testModRangeStudy::SetValues_gapThreshold() {
  for (int n=0; n<NumExps; n++)
    gapThresholdValues[n] = 1;
}


//******************************************************
// set values for numSwitch
//******************************************************
void testModRangeStudy::SetValues_numSwitch() {
  for (int n=0; n<NumExps; n++)
    numSwitchValues[n] = 6;
}


//******************************************************
// set values for phigh
//******************************************************
void testModRangeStudy::SetValues_phigh() {
  for (int n=0; n<NumExps; n++)
    phighValues[n] = 1;
}


//******************************************************
// set values for plow
//******************************************************
void testModRangeStudy::SetValues_plow() {
  for (int n=0; n<NumExps; n++)
    plowValues[n] = 1;
}


//******************************************************
// set values for pmedium
//******************************************************
void testModRangeStudy::SetValues_pmedium() {
  for (int n=0; n<NumExps; n++)
    pmediumValues[n] = 4;
}


//******************************************************
// set values for queueSize
//******************************************************
void testModRangeStudy::SetValues_queueSize() {
  for (int n=0; n<NumExps; n++)
    queueSizeValues[n] = 3;
}


//******************************************************
// set values for warningThreshold
//******************************************************
void testModRangeStudy::SetValues_warningThreshold() {
  for (int n=0; n<NumExps; n++)
    warningThresholdValues[n] = 15.0;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void testModRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "ID\tshort\t" << ID << endl;
  cout << "Interval\tfloat\t" << Interval << endl;
  cout << "TimeClock\tshort\t" << TimeClock << endl;
  cout << "freezingThreshold\tfloat\t" << freezingThreshold << endl;
  cout << "gapThreshold\tshort\t" << gapThreshold << endl;
  cout << "numSwitch\tshort\t" << numSwitch << endl;
  cout << "phigh\tshort\t" << phigh << endl;
  cout << "plow\tshort\t" << plow << endl;
  cout << "pmedium\tshort\t" << pmedium << endl;
  cout << "queueSize\tshort\t" << queueSize << endl;
  cout << "warningThreshold\tfloat\t" << warningThreshold << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *testModRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("ID", TheGVName) == 0)
    return &ID;
  else if (strcmp("Interval", TheGVName) == 0)
    return &Interval;
  else if (strcmp("TimeClock", TheGVName) == 0)
    return &TimeClock;
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    return &freezingThreshold;
  else if (strcmp("gapThreshold", TheGVName) == 0)
    return &gapThreshold;
  else if (strcmp("numSwitch", TheGVName) == 0)
    return &numSwitch;
  else if (strcmp("phigh", TheGVName) == 0)
    return &phigh;
  else if (strcmp("plow", TheGVName) == 0)
    return &plow;
  else if (strcmp("pmedium", TheGVName) == 0)
    return &pmedium;
  else if (strcmp("queueSize", TheGVName) == 0)
    return &queueSize;
  else if (strcmp("warningThreshold", TheGVName) == 0)
    return &warningThreshold;
  else 
    cerr<<"!! testModRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void testModRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("ID", TheGVName) == 0)
    SetGvValue(ID, *(short *)TheGVValue);
  else if (strcmp("Interval", TheGVName) == 0)
    SetGvValue(Interval, *(float *)TheGVValue);
  else if (strcmp("TimeClock", TheGVName) == 0)
    SetGvValue(TimeClock, *(short *)TheGVValue);
  else if (strcmp("freezingThreshold", TheGVName) == 0)
    SetGvValue(freezingThreshold, *(float *)TheGVValue);
  else if (strcmp("gapThreshold", TheGVName) == 0)
    SetGvValue(gapThreshold, *(short *)TheGVValue);
  else if (strcmp("numSwitch", TheGVName) == 0)
    SetGvValue(numSwitch, *(short *)TheGVValue);
  else if (strcmp("phigh", TheGVName) == 0)
    SetGvValue(phigh, *(short *)TheGVValue);
  else if (strcmp("plow", TheGVName) == 0)
    SetGvValue(plow, *(short *)TheGVValue);
  else if (strcmp("pmedium", TheGVName) == 0)
    SetGvValue(pmedium, *(short *)TheGVValue);
  else if (strcmp("queueSize", TheGVName) == 0)
    SetGvValue(queueSize, *(short *)TheGVValue);
  else if (strcmp("warningThreshold", TheGVName) == 0)
    SetGvValue(warningThreshold, *(float *)TheGVValue);
  else 
    cerr<<"!! testModRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void testModRangeStudy::SetGVs(int expNum) {
  SetGvValue(ID, IDValues[expNum]);
  SetGvValue(Interval, IntervalValues[expNum]);
  SetGvValue(TimeClock, TimeClockValues[expNum]);
  SetGvValue(freezingThreshold, freezingThresholdValues[expNum]);
  SetGvValue(gapThreshold, gapThresholdValues[expNum]);
  SetGvValue(numSwitch, numSwitchValues[expNum]);
  SetGvValue(phigh, phighValues[expNum]);
  SetGvValue(plow, plowValues[expNum]);
  SetGvValue(pmedium, pmediumValues[expNum]);
  SetGvValue(queueSize, queueSizeValues[expNum]);
  SetGvValue(warningThreshold, warningThresholdValues[expNum]);
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new testModRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* testModRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new testModPVModel(expandTimeArrays);
  return ThePVModel;
}


