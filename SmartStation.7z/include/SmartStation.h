#ifndef MAX
#define MAX 50
#define DEBUGG
#define DEBUG
#include <iostream>
using namespace std;


class Weather
{
  	private:
		int numProfiles;
		int interval;
		double internalTemperature;
		int** profile1;
		int profileID;
		short currentTime;
		double locality;
		int TimeOn;
		int TimeReady;
		int priority;
		double heatExchange(int interval, double eT, double iT, double power);
		
	public:
		Weather();
		Weather(int n, int m);
		~Weather();
		double* getProfile(int i);
		void setProfileID(int value);		
		int getProfileID();
		void setCurrentTime(short value);
		short getCurrentTime();
		void setInternalTemperature(double value);
		void setInternalTemperature();
		double getInternalTemperature();
		double getExternalTemperature();
		void decreaseInternalTemperature();
		void increaseInternalTemperature();
		void setLocality(short token);
		double getLocality();
		void increaseTimeOn();
		void increaseTimeReady();
		void resetTimeOn();
		void resetTimeReady();
		int getTimeOn();
		int getTimeReady();
		void setPriority(int p);
		int getPriority();
};

class Queue
{
	private:
		int numSwitches;
		int minPriority;
	public:
		Queue();
		~Queue();
		Queue(int numSwitch,int minPr);
		int remove(int p);
		int insert();
};

extern Queue q;
extern Weather w[MAX];
extern double profile[MAX][MAX];


#endif
