#include "SmartStation.h"
#include <iostream>
#include <cmath>
using namespace std;

Weather::Weather()
{
	interval=2;
	currentTime=-10;			//to be initialized 
	TimeOn=0;
	TimeReady=0;
	internalTemperature=-10; //to be initialized 
	profileID= -10;  		 //to be initialized 
	locality= -10;  		 //to be initialized 
}

Weather::Weather(int n, int m){
	Weather();
	profile1 = new int*[n];
	for(int i=0; i < m; i++)
		profile1[i] = new int[m];
}

Weather::~Weather()
{
	
}

double* Weather::getProfile(int i)
{
	switch(i)
	{
		case 1 : return profile[0];
		case 2 : return profile[1];
		case 3 : return profile[2];
		case 4 : return profile[3];
		case 5 : return profile[4];
		default : return NULL;
	}
}

void Weather::setProfileID(int value)
{
	profileID = value;
	#ifndef DEBUG
		cout << "profileID set to "<< profileID << " \n";
	#endif
}

int Weather::getProfileID()
{
	return profileID;
}

double Weather::getLocality()
{
	return locality;
}

void Weather::setCurrentTime(short value)
{
	currentTime=value;
}

short Weather::getCurrentTime()
{
	return currentTime;
}

void Weather::setInternalTemperature(double value)
{
	internalTemperature=value;
}

void Weather::setInternalTemperature()
{
	//internalTemperature=profile[profileID-1][(int)(currentTime/interval)]+locality+0.5;
	internalTemperature= 5;
}

double Weather::getExternalTemperature()
{
	return  profile[profileID-1][(int)(currentTime/interval)]+locality;
}

double Weather::getInternalTemperature()
{
	return internalTemperature;
}


void Weather::setLocality(short token)
{
	switch (token)
	{
		case 1: locality = -0.8;
				break;
		case 2: locality = -0.3;
				break;
		case 3: locality = 0;
				break;
	}
	#ifndef DEBUG
		cout << "Locality set to : " << locality << " the value of the place locality is " << token << "\n";
	#endif
}

double Weather::heatExchange(int interval, double eT, double iT,double power)
{
	/*
	  alpha 	coefficiente dello strato limite (aria)		10 - 100
	  
	  c     calore specifico acciaio 					502
														0.466		http://en.wikipedia.org/wiki/Heat_capacity  J/(g*K)
	  s 	superficie della lastra che collega i due binari da spostare, rappresenta la componente di maggiore
			rilevanza in uno switch, quindi considero solo quella http://www.unitracrail.com/pdfs2013/Turnout_Components_Section.pdf
			(6'9'' * 2,5'')*2 + (6'9''* 0,75'')*2
			 peso = 118,941 kg http://www.calculatoredge.com/matweight/material%20wt.htm
			 peso in newton = 1166.4127 N
	        massa (Kg) = peso (N) /  9,8 m/s2 = 119,021 Kg
			 6'9''     = 2,0574 m   6 piedi = 182,88 cm  9 pollici = 22,86 cm
			 2,5'' 	   =  0,7366 m   2 piedi = 60,96 cm   5 pollici = 12,7 cm
			 0,75''	   = 0,01 m 
			 
			http://formulas.tutorvista.com/physics/heat-transfer-formula.html
			 
	q  =  quantità di calore trasferito 		 
			 
			 q = alpha*s*t* (Taria-Tacciaio)
			 
			 q = m c (Temperatura finale - Temperatura iniziale) <-- acciaio
			 			  
			  Tfin = (k*A*t)/(m*c)*(eT - iT) + sT  <-- in K
			  
			  k * s * ( x - Te) =  m * c * (x - Te)
			  
			  melting point steel = 1510 degrees
			  brittle point steel =  -20 c 		http://www.carrl.ca/rail_breaks
	
	double k = 36; //thermal conductivity steel W/m*K   http://en.wikipedia.org/wiki/List_of_thermal_conductivities
	double alpha = 10; // W/m^2*K
	double c = 502;
	//double s = 3.07;
	double s = 1.5154; // metri quadri
	double m = 119.021;
	int t = 3600;
	int den=8000; //density of steel kg/m^3
	int thickness = 1; // cm
	double aria =eT + 273.15; //Kelvin
	double Tiniziale = iT + 273.15; //Kelvin
	double Tfinale;
	if (aria>Tiniziale)
		Tfinale = ( (alpha*s*t*(aria - Tiniziale))/(m*c) ) + Tiniziale;
	else
		Tfinale = ( (alpha*s*t*( Tiniziale - aria))/(m*c) ) + Tiniziale;
	double TfinaleCelsius = Tfinale - 273.15;
	return TfinaleCelsius;
	*/
	double Ta= eT;
    double To= iT;
	double beta=0.0037;	//coefficiente dilatazione termica aria
	double den=1.30;		// densità aria
	double L = (0.28*6)/6.28;	//Area su Volume  --- Perimetro ?
	double vis=0.000017157;		//viscosità dinamica
	double Pr=0.7;			//numero di Prandtl
	double K=0.023845;			//conduttività termica ferro 
	double m=529.13;			//massa
	double c=450;			//capacità calore ferro
	double lung = 20; //10 //8000;//		//cavo lungo 8 km -- 10 metri
	double s = 3600;			//tempo 1 ora, 3600 secondi
	double u= (pow(((9.81*beta*(To-Ta)*den*den*L*L*L*Pr)/(vis*vis)), 0.25))*((0.54+0.27)/2)*(K/L);	//coefficiente scambio termico
	
	double T;
	if (u == u)
	{
		#ifndef DEBUGG
			cout<< " u " << u << "\n";
		#endif
		// T=Ta+(To-Ta)*exp((-u)*0.28*6*2/m/c*s)+(power/(u*0.28*6*2*lung));		VECCHIO
		T = Ta + ((To-Ta) * exp( ((-u)*0.28*6*2*s) / (m*c) )) + ( power*6 / (u*0.28*6*2*lung)); //power 
	}
	else
		T=Ta+(To-Ta);
	return T;
}


void Weather::decreaseInternalTemperature()
{
	double externalTemperature = profile[profileID-1][(int)(currentTime/interval)]+locality;
	internalTemperature =  heatExchange(interval,externalTemperature,internalTemperature,0);
	#ifndef DEBUGG
		int frac = (int)(currentTime/interval);
		cout<< "heater off ";
		//cout<<"current time on interval "<<frac<< " ; ";
		//cout<<"locality "<<locality<<" ; ";
		cout<< "External temperature = " << externalTemperature << " ; ";
		//cout<< "profileID = " << profileID << " ; ";
		//cout<< "currentTime = "<< currentTime << " ; ";
		cout<< "new internal temperature " << internalTemperature << " \n ";
	#endif
}


void Weather::increaseInternalTemperature()
{
	double externalTemperature =  profile[profileID-1][(int)(currentTime/interval)]+locality;
	#ifndef DEBUGG
		int frac = (int)(currentTime/interval);
		cout<< "++++ HEATER ON  ++++";
		//cout<<"int current time on interval "<<frac<< " ; ";
		//cout<<"locality "<<locality<<" ; ";
		cout<< "External temperature = " << externalTemperature << " ; ";
		//cout<< "profileID = " << profileID << " ; ";
		//cout<< "currentTime = "<< currentTime << " ; ";
		cout<< "old internal temperature= "<< internalTemperature<< " ;\n";
	#endif
	internalTemperature =  heatExchange(interval,externalTemperature,internalTemperature,330);//35000);// 300 Watt per metro
	#ifndef DEBUGG			
		cout<< "new internal temperature " << internalTemperature << " \n ";
	#endif
}

void Weather::increaseTimeOn()
{
	TimeOn++;
}

void Weather::increaseTimeReady()
{
	TimeReady++;
}


void Weather::resetTimeOn()
{
	TimeOn=0;
}

void Weather::resetTimeReady()
{
	TimeReady=0;
}

int Weather::getTimeOn()
{
	return TimeOn;
}


int Weather::getTimeReady()
{
	return TimeReady;
}

int Weather::getPriority()
{
	return priority;
}

void Weather::setPriority(int p)
{
	priority=p;
}

Queue::Queue(int numSwitch,int minPr)
{
	numSwitches=numSwitch;
	minPriority=minPr;
}

Queue::Queue()
{
	
}
Queue::~Queue()
{
	
}
/*
int Queue::remove(int p)
{
	int id=0;
	int time=-1;
	for (int i=1;i<=numSwitches;i++)
	{
		if ((w[i].getPriority()==p)&&(w[i].getTimeOn()>time))
		{
			time=w[i].getTimeOn();
			id=i;
		}
	}
	return id;
}*/

/**
*
  the method is invoked in case the queue is full, then if the switcher S needs
  to be activated and has a priority greater than the minimum, it can remove other
  switches activated with a priority lower then S. In particular, it will remove 
  the one with lower priority  lp, and in case of more switches with priority lp,
  it will be removed the one that is activated for longer time.
*@param p  the priority
*@return if p is the minimum priority or if the priority is not in the range
*		 then returns 0 otherwise it returns the id of the switch with priority
*		 p that is activated for longer time
*/
int Queue::remove(int p) 
{
	if (p==minPriority)
		return 0;
	int id=0;
	int time=0;
	for(int j=minPriority;j>p;j--) //starting from lower priorities
	{
		for (int i=1;i<=numSwitches;i++)
		{
			if ((w[i].getPriority()==j)&&(w[i].getTimeOn()>time))
			{
				#ifndef DEBUG
					cout<<"REMOVE QUEUE SwitchID :"<<i<<" priority "<<w[i].getPriority()<<" time on "<<w[i].getTimeOn()<<" \n";
				#endif
				time=w[i].getTimeOn();  //remove the one with longer activation
				id=i;
			}
		}
		if (id>0)
		{
			#ifndef DEBUGG
				cout<<"SELECTED HEATER: "<<id<<" \n";
			#endif
			return id;
		}
	}
	return id;
}

/**
	Selects the id of the switch to insert in the queue. It must be ready, and have
	the higher priority and maximum waiting time between those that are waiting.
	@ return if the queue is empty 0, otherwise the id of the switch
*/
int Queue::insert()
{
	int time=0;
	int id=0;
	for(int j=1;j<=minPriority;j++)
	{
		for (int i=1;i<=numSwitches;i++)
		{	
			if ((w[i].getPriority()==j)&&(w[i].getTimeReady()>time))
			{
				#ifndef DEBUG
					cout<<"INSERT QUEUE SwitchID :"<<i<<" priority "<<w[i].getPriority()<<" time ready "<<w[i].getTimeReady()<<" \n";
				#endif
				time=w[i].getTimeReady();
				id=i;
			}
		}
		if (id>0)
		{
			#ifndef DEBUGG
			cout<<"SELECTED HEATER: "<<id<<" \n";
			#endif
			return id; //dalla priorità più alta alla più bassa, appena trovo mi fermo
		}
	}
	return id;
}

Weather w[MAX];
Queue q;

/*
	TABELLA PROFILI METEO
*/
double profile[MAX][MAX]={ 
							//{ 2, 0, -2, -2.5, -3, -3.3, -3.8, -3.3, -3 , -2.5, -2, 0 }, 
							//{ 0, -1, -2, -3, -4, -4.5, -5, -4.5, -4, -3,-2 ,-1 },
							//{ 3, 1, 0, -1, -2, -3, -3.5, -3, -2, -1,0 ,1 },
							//{ 0, -2, -3.5, -4.8, -6.2, -6.8, -6.9, -6.2, -4.8, -3.5, -2, 0 },
							//{ 1, -1, -3, -3.5, -4, -4.5, -5.5, -4.5 ,-4 , -3 , -2 , -1},
							{-14, -15,     -18,   -19,   -20,   -21,   -23,   -22,   -20,   -17,   -17,   -15},
							{-13.5, -14.5, -17.5, -18.5, -19.5, -20.5, -22.5, -21.5, -19.5, -16.5, -16.5, -14.5},
							{-13,   -14,   -16,   -17,   -19,   -20,   -22,    -21,   -19,   -16,  -15,   -14},
							{-12.5, -13.5, -15.5, -16.5, -18.5, -19.5, -21.5, -20.5, -18.5, -15.5, -14.5, -13.5},
							{-12, -13, -14, -15, -16, -18, -19, -20, -20, -18, -15, -13},
							//{-14, -15, -16, -18, -20, -22, -23, -22, -20, -18, -16, -15},
							//{-11, -12, -13, -14, -17, -19, -20, -19, -17, -15, -13, -12},
							//{-10, -11, -12, -13, -16, -18, -19, -18, -16, -14, -12, -11},
							//{-9,  -10, -11, -12, -15, -17, -18, -17, -15, -13, -11, -10},
							
						};
