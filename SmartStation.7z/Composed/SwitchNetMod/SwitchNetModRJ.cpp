#include "Composed/SwitchNetMod/SwitchNetModRJ.h"
char * SwitchNetModRJ__SharedNames[] = {"idRec", "idSend", "msg", "synch"};

SwitchNetModRJ::SwitchNetModRJ():Join("SwitchHeatingSysM", 2, 4,SwitchNetModRJ__SharedNames) {
  HeatersNetM = new SwitchNetModRJ__HeatersNetM();
  ModelArray[0] = (BaseModelClass*) HeatersNetM;
  ModelArray[0]->DefineName("HeatersNetM");
  Controller = new SwitchNetModRJ__Controller();
  ModelArray[1] = (BaseModelClass*) Controller;
  ModelArray[1]->DefineName("Controller");

  SetupActions();
  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************  State sharing info  **************
    //Shared variable 0
    idRec = new Place("idRec");
    addSharedPtr(idRec, "idRec" );
    if (HeatersNetM->NumStateVariables > 0) {
      idRec->ShareWith(getSharableSVPointer(HeatersNetM->idRec));
      addSharingInfo(getSharableSVPointer(HeatersNetM->idRec), idRec, HeatersNetM);
    }
    if (Controller->NumStateVariables > 0) {
      idRec->ShareWith(getSharableSVPointer(Controller->idRec));
      addSharingInfo(getSharableSVPointer(Controller->idRec), idRec, Controller);
    }

    //Shared variable 1
    idSend = new Place("idSend");
    addSharedPtr(idSend, "idSend" );
    if (HeatersNetM->NumStateVariables > 0) {
      idSend->ShareWith(getSharableSVPointer(HeatersNetM->idSend));
      addSharingInfo(getSharableSVPointer(HeatersNetM->idSend), idSend, HeatersNetM);
    }
    if (Controller->NumStateVariables > 0) {
      idSend->ShareWith(getSharableSVPointer(Controller->idSend));
      addSharingInfo(getSharableSVPointer(Controller->idSend), idSend, Controller);
    }

    //Shared variable 2
    msg = new Place("msg");
    addSharedPtr(msg, "msg" );
    if (HeatersNetM->NumStateVariables > 0) {
      msg->ShareWith(getSharableSVPointer(HeatersNetM->msg));
      addSharingInfo(getSharableSVPointer(HeatersNetM->msg), msg, HeatersNetM);
    }
    if (Controller->NumStateVariables > 0) {
      msg->ShareWith(getSharableSVPointer(Controller->msg));
      addSharingInfo(getSharableSVPointer(Controller->msg), msg, Controller);
    }

    //Shared variable 3
    synch = new Place("synch");
    addSharedPtr(synch, "synch" );
    if (HeatersNetM->NumStateVariables > 0) {
      synch->ShareWith(getSharableSVPointer(HeatersNetM->synch));
      addSharingInfo(getSharableSVPointer(HeatersNetM->synch), synch, HeatersNetM);
    }
    if (Controller->NumStateVariables > 0) {
      synch->ShareWith(getSharableSVPointer(Controller->synch));
      addSharingInfo(getSharableSVPointer(Controller->synch), synch, Controller);
    }

  }

  Setup();
}

SwitchNetModRJ::~SwitchNetModRJ() {
  if (!AllChildrenEmpty()) {
    delete idRec;
    delete idSend;
    delete msg;
    delete synch;
  }
  delete HeatersNetM;
  delete Controller;
}
