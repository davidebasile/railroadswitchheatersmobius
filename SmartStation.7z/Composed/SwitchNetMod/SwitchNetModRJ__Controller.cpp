#include "Composed/SwitchNetMod/SwitchNetModRJ__Controller.h"
char * SwitchNetModRJ__Controller__SharedNames[] = {"idRec", "idSend", "msg", "state", "synch", "temp"};

SwitchNetModRJ__Controller::SwitchNetModRJ__Controller():Join("Controller", 2, 6,SwitchNetModRJ__Controller__SharedNames) {
  ControllerEvaluationMod = new ControllerEvaluationModSAN();
  ModelArray[0] = (BaseModelClass*) ControllerEvaluationMod;
  ModelArray[0]->DefineName("ControllerEvaluationMod");
  ControllerCommunicationMod = new ControllerCommunicationModSAN();
  ModelArray[1] = (BaseModelClass*) ControllerCommunicationMod;
  ModelArray[1]->DefineName("ControllerCommunicationMod");

  SetupActions();
  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************  State sharing info  **************
    //Shared variable 0
    idRec = new Place("idRec");
    addSharedPtr(idRec, "idRec" );
    if (ControllerCommunicationMod->NumStateVariables > 0) {
      idRec->ShareWith(getSharableSVPointer(ControllerCommunicationMod->idRec));
      addSharingInfo(getSharableSVPointer(ControllerCommunicationMod->idRec), idRec, ControllerCommunicationMod);
    }

    //Shared variable 1
    idSend = new Place("idSend");
    addSharedPtr(idSend, "idSend" );
    if (ControllerCommunicationMod->NumStateVariables > 0) {
      idSend->ShareWith(getSharableSVPointer(ControllerCommunicationMod->idSend));
      addSharingInfo(getSharableSVPointer(ControllerCommunicationMod->idSend), idSend, ControllerCommunicationMod);
    }

    //Shared variable 2
    msg = new Place("msg");
    addSharedPtr(msg, "msg" );
    if (ControllerCommunicationMod->NumStateVariables > 0) {
      msg->ShareWith(getSharableSVPointer(ControllerCommunicationMod->msg));
      addSharingInfo(getSharableSVPointer(ControllerCommunicationMod->msg), msg, ControllerCommunicationMod);
    }

    //Shared variable 3
    state = new Place("state");
    addSharedPtr(state, "state" );
    if (ControllerEvaluationMod->NumStateVariables > 0) {
      state->ShareWith(getSharableSVPointer(ControllerEvaluationMod->state));
      addSharingInfo(getSharableSVPointer(ControllerEvaluationMod->state), state, ControllerEvaluationMod);
    }
    if (ControllerCommunicationMod->NumStateVariables > 0) {
      state->ShareWith(getSharableSVPointer(ControllerCommunicationMod->state));
      addSharingInfo(getSharableSVPointer(ControllerCommunicationMod->state), state, ControllerCommunicationMod);
    }

    //Shared variable 4
    synch = new Place("synch");
    addSharedPtr(synch, "synch" );
    if (ControllerEvaluationMod->NumStateVariables > 0) {
      synch->ShareWith(getSharableSVPointer(ControllerEvaluationMod->synch));
      addSharingInfo(getSharableSVPointer(ControllerEvaluationMod->synch), synch, ControllerEvaluationMod);
    }
    if (ControllerCommunicationMod->NumStateVariables > 0) {
      synch->ShareWith(getSharableSVPointer(ControllerCommunicationMod->synch));
      addSharingInfo(getSharableSVPointer(ControllerCommunicationMod->synch), synch, ControllerCommunicationMod);
    }

    //Shared variable 5
    temp = new Place("temp");
    addSharedPtr(temp, "temp" );
    if (ControllerEvaluationMod->NumStateVariables > 0) {
      temp->ShareWith(getSharableSVPointer(ControllerEvaluationMod->temp));
      addSharingInfo(getSharableSVPointer(ControllerEvaluationMod->temp), temp, ControllerEvaluationMod);
    }
    if (ControllerCommunicationMod->NumStateVariables > 0) {
      temp->ShareWith(getSharableSVPointer(ControllerCommunicationMod->temp));
      addSharingInfo(getSharableSVPointer(ControllerCommunicationMod->temp), temp, ControllerCommunicationMod);
    }

  }

  Setup();
}

SwitchNetModRJ__Controller::~SwitchNetModRJ__Controller() {
  if (!AllChildrenEmpty()) {
    delete idRec;
    delete idSend;
    delete msg;
    delete state;
    delete synch;
    delete temp;
  }
  delete ControllerEvaluationMod;
  delete ControllerCommunicationMod;
}
