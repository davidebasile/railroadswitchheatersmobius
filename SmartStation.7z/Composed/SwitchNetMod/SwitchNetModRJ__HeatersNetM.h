#ifndef SwitchNetModRJ__HeatersNetM_H_
#define SwitchNetModRJ__HeatersNetM_H_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Composer/Rep.h"
#include "Cpp/Composer/AllStateVariableTypes.h"

//Submodel header files
#include "Composed/SwitchNetMod/SwitchNetModRJ__HeaterModuleM.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
extern Short numSwitch;

class SwitchNetModRJ__HeatersNetM: public Rep {
 public:
  SwitchNetModRJ__HeaterModuleM ** InstanceArray;

  SwitchNetModRJ__HeatersNetM();
  ~SwitchNetModRJ__HeatersNetM();

  // Declare new variables
  Place * idRec;
  Place * idSend;
  Place * msg;
  Place * p1;
  Place * synch;
};

#endif
