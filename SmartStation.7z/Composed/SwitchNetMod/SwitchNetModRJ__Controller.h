#ifndef SwitchNetModRJ__Controller_H_
#define SwitchNetModRJ__Controller_H_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Composer/Join.h"
#include "Cpp/Composer/AllStateVariableTypes.h"
#include "Atomic/ControllerEvaluationMod/ControllerEvaluationModSAN.h"
#include "Atomic/ControllerCommunicationMod/ControllerCommunicationModSAN.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
extern Short numSwitch;

class SwitchNetModRJ__Controller: public Join {
 public:
  ControllerEvaluationModSAN * ControllerEvaluationMod;
  ControllerCommunicationModSAN * ControllerCommunicationMod;
  Place * idRec;
  Place * idSend;
  Place * msg;
  Place * state;
  Place * synch;
  Place * temp;

  SwitchNetModRJ__Controller();
  ~SwitchNetModRJ__Controller();
};

#endif
