#ifndef SwitchNetModRJ__RailRoadSwitchHeater_H_
#define SwitchNetModRJ__RailRoadSwitchHeater_H_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Composer/Join.h"
#include "Cpp/Composer/AllStateVariableTypes.h"
#include "Atomic/RailRoadSwitchHeaterCommunicationModel/RailRoadSwitchHeaterCommunicationModelSAN.h"
#include "Atomic/RailRoadSwitchHeaterEvaluationModule/RailRoadSwitchHeaterEvaluationModuleSAN.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
extern Short numSwitch;

class SwitchNetModRJ__RailRoadSwitchHeater: public Join {
 public:
  RailRoadSwitchHeaterCommunicationModelSAN * RailRoadSwitchHeaterCommunicationModel;
  RailRoadSwitchHeaterEvaluationModuleSAN * RailRoadSwitchHeaterEvaluationModule;
  Place * SwitchID;
  Place * idRec;
  Place * idSend;
  Place * locality;
  Place * msg;
  Place * profileID;
  Place * state;
  Place * synch;

  SwitchNetModRJ__RailRoadSwitchHeater();
  ~SwitchNetModRJ__RailRoadSwitchHeater();
};

#endif
