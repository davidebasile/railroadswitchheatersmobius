#include "Composed/SwitchNetMod/SwitchNetModRJ__RailRoadSwitchHeater.h"
char * SwitchNetModRJ__RailRoadSwitchHeater__SharedNames[] = {"SwitchID", "idRec", "idSend", "locality", "msg", "profileID", "state", "synch"};

SwitchNetModRJ__RailRoadSwitchHeater::SwitchNetModRJ__RailRoadSwitchHeater():Join("RailRoadSwitchHeater", 2, 8,SwitchNetModRJ__RailRoadSwitchHeater__SharedNames) {
  RailRoadSwitchHeaterCommunicationModel = new RailRoadSwitchHeaterCommunicationModelSAN();
  ModelArray[0] = (BaseModelClass*) RailRoadSwitchHeaterCommunicationModel;
  ModelArray[0]->DefineName("RailRoadSwitchHeaterCommunicationModel");
  RailRoadSwitchHeaterEvaluationModule = new RailRoadSwitchHeaterEvaluationModuleSAN();
  ModelArray[1] = (BaseModelClass*) RailRoadSwitchHeaterEvaluationModule;
  ModelArray[1]->DefineName("RailRoadSwitchHeaterEvaluationModule");

  SetupActions();
  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************  State sharing info  **************
    //Shared variable 0
    SwitchID = new Place("SwitchID");
    addSharedPtr(SwitchID, "SwitchID" );
    if (RailRoadSwitchHeaterCommunicationModel->NumStateVariables > 0) {
      SwitchID->ShareWith(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->SwitchID));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->SwitchID), SwitchID, RailRoadSwitchHeaterCommunicationModel);
    }
    if (RailRoadSwitchHeaterEvaluationModule->NumStateVariables > 0) {
      SwitchID->ShareWith(getSharableSVPointer(RailRoadSwitchHeaterEvaluationModule->SwitchID));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeaterEvaluationModule->SwitchID), SwitchID, RailRoadSwitchHeaterEvaluationModule);
    }

    //Shared variable 1
    idRec = new Place("idRec");
    addSharedPtr(idRec, "idRec" );
    if (RailRoadSwitchHeaterCommunicationModel->NumStateVariables > 0) {
      idRec->ShareWith(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->idRec));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->idRec), idRec, RailRoadSwitchHeaterCommunicationModel);
    }

    //Shared variable 2
    idSend = new Place("idSend");
    addSharedPtr(idSend, "idSend" );
    if (RailRoadSwitchHeaterCommunicationModel->NumStateVariables > 0) {
      idSend->ShareWith(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->idSend));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->idSend), idSend, RailRoadSwitchHeaterCommunicationModel);
    }

    //Shared variable 3
    locality = new Place("locality");
    addSharedPtr(locality, "locality" );
    if (RailRoadSwitchHeaterEvaluationModule->NumStateVariables > 0) {
      locality->ShareWith(getSharableSVPointer(RailRoadSwitchHeaterEvaluationModule->locality));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeaterEvaluationModule->locality), locality, RailRoadSwitchHeaterEvaluationModule);
    }

    //Shared variable 4
    msg = new Place("msg");
    addSharedPtr(msg, "msg" );
    if (RailRoadSwitchHeaterCommunicationModel->NumStateVariables > 0) {
      msg->ShareWith(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->msg));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->msg), msg, RailRoadSwitchHeaterCommunicationModel);
    }

    //Shared variable 5
    profileID = new Place("profileID");
    addSharedPtr(profileID, "profileID" );
    if (RailRoadSwitchHeaterEvaluationModule->NumStateVariables > 0) {
      profileID->ShareWith(getSharableSVPointer(RailRoadSwitchHeaterEvaluationModule->profileID));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeaterEvaluationModule->profileID), profileID, RailRoadSwitchHeaterEvaluationModule);
    }

    //Shared variable 6
    state = new Place("state");
    addSharedPtr(state, "state" );
    if (RailRoadSwitchHeaterCommunicationModel->NumStateVariables > 0) {
      state->ShareWith(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->state));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->state), state, RailRoadSwitchHeaterCommunicationModel);
    }
    if (RailRoadSwitchHeaterEvaluationModule->NumStateVariables > 0) {
      state->ShareWith(getSharableSVPointer(RailRoadSwitchHeaterEvaluationModule->state));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeaterEvaluationModule->state), state, RailRoadSwitchHeaterEvaluationModule);
    }

    //Shared variable 7
    synch = new Place("synch");
    addSharedPtr(synch, "synch" );
    if (RailRoadSwitchHeaterCommunicationModel->NumStateVariables > 0) {
      synch->ShareWith(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->synch));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeaterCommunicationModel->synch), synch, RailRoadSwitchHeaterCommunicationModel);
    }
    if (RailRoadSwitchHeaterEvaluationModule->NumStateVariables > 0) {
      synch->ShareWith(getSharableSVPointer(RailRoadSwitchHeaterEvaluationModule->synch));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeaterEvaluationModule->synch), synch, RailRoadSwitchHeaterEvaluationModule);
    }

  }

  Setup();
}

SwitchNetModRJ__RailRoadSwitchHeater::~SwitchNetModRJ__RailRoadSwitchHeater() {
  if (!AllChildrenEmpty()) {
    delete SwitchID;
    delete idRec;
    delete idSend;
    delete locality;
    delete msg;
    delete profileID;
    delete state;
    delete synch;
  }
  delete RailRoadSwitchHeaterCommunicationModel;
  delete RailRoadSwitchHeaterEvaluationModule;
}
