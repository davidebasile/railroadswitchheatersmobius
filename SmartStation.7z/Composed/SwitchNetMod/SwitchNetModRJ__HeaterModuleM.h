#ifndef SwitchNetModRJ__HeaterModuleM_H_
#define SwitchNetModRJ__HeaterModuleM_H_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Composer/Join.h"
#include "Cpp/Composer/AllStateVariableTypes.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__RailRoadSwitchHeater.h"
#include "Atomic/LocalitySelector/LocalitySelectorSAN.h"
#include "Atomic/ProfileSelector/ProfileSelectorSAN.h"
#include "Atomic/SwitchIDSelector/SwitchIDSelectorSAN.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
extern Short numSwitch;

class SwitchNetModRJ__HeaterModuleM: public Join {
 public:
  SwitchNetModRJ__RailRoadSwitchHeater * RailRoadSwitchHeater;
  LocalitySelectorSAN * LocalitySelector;
  ProfileSelectorSAN * ProfileSelector;
  SwitchIDSelectorSAN * SwitchIDSelector;
  Place * SwitchID;
  Place * idRec;
  Place * idSend;
  Place * locality;
  Place * msg;
  Place * p1;
  Place * profileID;
  Place * synch;

  SwitchNetModRJ__HeaterModuleM();
  ~SwitchNetModRJ__HeaterModuleM();
};

#endif
