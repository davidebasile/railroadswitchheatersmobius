#ifndef SwitchNetModRJ_H_
#define SwitchNetModRJ_H_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Composer/Join.h"
#include "Cpp/Composer/AllStateVariableTypes.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__HeatersNetM.h"
#include "Composed/SwitchNetMod/SwitchNetModRJ__Controller.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
extern Short numSwitch;

class SwitchNetModRJ: public Join {
 public:
  SwitchNetModRJ__HeatersNetM * HeatersNetM;
  SwitchNetModRJ__Controller * Controller;
  Place * idRec;
  Place * idSend;
  Place * msg;
  Place * synch;

  SwitchNetModRJ();
  ~SwitchNetModRJ();
};

#endif
