#include "Composed/SwitchNetMod/SwitchNetModRJ__HeaterModuleM.h"
char * SwitchNetModRJ__HeaterModuleM__SharedNames[] = {"SwitchID", "idRec", "idSend", "locality", "msg", "p1", "profileID", "synch"};

SwitchNetModRJ__HeaterModuleM::SwitchNetModRJ__HeaterModuleM():Join("HeaterModuleM", 4, 8,SwitchNetModRJ__HeaterModuleM__SharedNames) {
  RailRoadSwitchHeater = new SwitchNetModRJ__RailRoadSwitchHeater();
  ModelArray[0] = (BaseModelClass*) RailRoadSwitchHeater;
  ModelArray[0]->DefineName("RailRoadSwitchHeater");
  LocalitySelector = new LocalitySelectorSAN();
  ModelArray[1] = (BaseModelClass*) LocalitySelector;
  ModelArray[1]->DefineName("LocalitySelector");
  ProfileSelector = new ProfileSelectorSAN();
  ModelArray[2] = (BaseModelClass*) ProfileSelector;
  ModelArray[2]->DefineName("ProfileSelector");
  SwitchIDSelector = new SwitchIDSelectorSAN();
  ModelArray[3] = (BaseModelClass*) SwitchIDSelector;
  ModelArray[3]->DefineName("SwitchIDSelector");

  SetupActions();
  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************  State sharing info  **************
    //Shared variable 0
    SwitchID = new Place("SwitchID");
    addSharedPtr(SwitchID, "SwitchID" );
    if (SwitchIDSelector->NumStateVariables > 0) {
      SwitchID->ShareWith(getSharableSVPointer(SwitchIDSelector->SwitchID));
      addSharingInfo(getSharableSVPointer(SwitchIDSelector->SwitchID), SwitchID, SwitchIDSelector);
    }
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      SwitchID->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->SwitchID));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->SwitchID), SwitchID, RailRoadSwitchHeater);
    }

    //Shared variable 1
    idRec = new Place("idRec");
    addSharedPtr(idRec, "idRec" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      idRec->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->idRec));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->idRec), idRec, RailRoadSwitchHeater);
    }

    //Shared variable 2
    idSend = new Place("idSend");
    addSharedPtr(idSend, "idSend" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      idSend->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->idSend));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->idSend), idSend, RailRoadSwitchHeater);
    }

    //Shared variable 3
    locality = new Place("locality");
    addSharedPtr(locality, "locality" );
    if (LocalitySelector->NumStateVariables > 0) {
      locality->ShareWith(getSharableSVPointer(LocalitySelector->locality));
      addSharingInfo(getSharableSVPointer(LocalitySelector->locality), locality, LocalitySelector);
    }
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      locality->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->locality));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->locality), locality, RailRoadSwitchHeater);
    }

    //Shared variable 4
    msg = new Place("msg");
    addSharedPtr(msg, "msg" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      msg->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->msg));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->msg), msg, RailRoadSwitchHeater);
    }

    //Shared variable 5
    p1 = new Place("p1");
    addSharedPtr(p1, "p1" );
    if (SwitchIDSelector->NumStateVariables > 0) {
      p1->ShareWith(getSharableSVPointer(SwitchIDSelector->p1));
      addSharingInfo(getSharableSVPointer(SwitchIDSelector->p1), p1, SwitchIDSelector);
    }

    //Shared variable 6
    profileID = new Place("profileID");
    addSharedPtr(profileID, "profileID" );
    if (ProfileSelector->NumStateVariables > 0) {
      profileID->ShareWith(getSharableSVPointer(ProfileSelector->profileID));
      addSharingInfo(getSharableSVPointer(ProfileSelector->profileID), profileID, ProfileSelector);
    }
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      profileID->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->profileID));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->profileID), profileID, RailRoadSwitchHeater);
    }

    //Shared variable 7
    synch = new Place("synch");
    addSharedPtr(synch, "synch" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      synch->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->synch));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->synch), synch, RailRoadSwitchHeater);
    }

  }

  Setup();
}

SwitchNetModRJ__HeaterModuleM::~SwitchNetModRJ__HeaterModuleM() {
  if (!AllChildrenEmpty()) {
    delete SwitchID;
    delete idRec;
    delete idSend;
    delete locality;
    delete msg;
    delete p1;
    delete profileID;
    delete synch;
  }
  delete RailRoadSwitchHeater;
  delete LocalitySelector;
  delete ProfileSelector;
  delete SwitchIDSelector;
}
