#include "Composed/SwitchNetMod/SwitchNetModRJ__HeatersNetM.h"
char * SwitchNetModRJ__HeatersNetM__SharedNames[] = {"idRec", "idSend", "msg", "p1", "synch"};

SwitchNetModRJ__HeatersNetM::SwitchNetModRJ__HeatersNetM():Rep("HeatersNetM", numSwitch, 5, SwitchNetModRJ__HeatersNetM__SharedNames)
{
  InstanceArray = new SwitchNetModRJ__HeaterModuleM * [NumModels];
  delete[] ModelArray;
  ModelArray = (BaseModelClass **) InstanceArray;
  for (counter = 0; counter < NumModels; counter++)
    InstanceArray[counter] = new SwitchNetModRJ__HeaterModuleM();

  SetupActions();
  if (NumModels == 0) return;

  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************** Initialize local variables ****************
    idRec = new Place("idRec");
    addSharedPtr(idRec, "idRec");
    idRec->ShareWith(InstanceArray[0]->idRec);

    idSend = new Place("idSend");
    addSharedPtr(idSend, "idSend");
    idSend->ShareWith(InstanceArray[0]->idSend);

    msg = new Place("msg");
    addSharedPtr(msg, "msg");
    msg->ShareWith(InstanceArray[0]->msg);

    p1 = new Place("p1");
    addSharedPtr(p1, "p1");
    p1->ShareWith(InstanceArray[0]->p1);

    synch = new Place("synch");
    addSharedPtr(synch, "synch");
    synch->ShareWith(InstanceArray[0]->synch);


    //Share state in submodels
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->idRec, idRec);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->idSend, idSend);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->msg, msg);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->p1, p1);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->synch, synch);
    }
    for (counter = 1; counter < NumModels; counter++) {
      InstanceArray[0]->idRec->ShareWith(InstanceArray[counter]->idRec);
      InstanceArray[0]->idSend->ShareWith(InstanceArray[counter]->idSend);
      InstanceArray[0]->msg->ShareWith(InstanceArray[counter]->msg);
      InstanceArray[0]->p1->ShareWith(InstanceArray[counter]->p1);
      InstanceArray[0]->synch->ShareWith(InstanceArray[counter]->synch);
    }
  }
  Setup("HeaterModuleM");
}

SwitchNetModRJ__HeatersNetM::~SwitchNetModRJ__HeatersNetM() {
  if (NumModels == 0) return;
  delete idRec;
  delete idSend;
  delete msg;
  delete p1;
  delete synch;
  for (int i = 0; i < NumModels; i++)
    delete InstanceArray[i];
}

