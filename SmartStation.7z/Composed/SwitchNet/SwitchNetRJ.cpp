#include "Composed/SwitchNet/SwitchNetRJ.h"
char * SwitchNetRJ__SharedNames[] = {"action", "id", "notifyIn", "notifyOut", "synch"};

SwitchNetRJ::SwitchNetRJ():Join("SwitchHeatingSysM", 2, 5,SwitchNetRJ__SharedNames) {
  HeatersNetM = new SwitchNetRJ__HeatersNetM();
  ModelArray[0] = (BaseModelClass*) HeatersNetM;
  ModelArray[0]->DefineName("HeatersNetM");
  Coordinator = new QueueSAN();
  ModelArray[1] = (BaseModelClass*) Coordinator;
  ModelArray[1]->DefineName("Coordinator");

  SetupActions();
  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************  State sharing info  **************
    //Shared variable 0
    action = new Place("action");
    addSharedPtr(action, "action" );
    if (HeatersNetM->NumStateVariables > 0) {
      action->ShareWith(getSharableSVPointer(HeatersNetM->action));
      addSharingInfo(getSharableSVPointer(HeatersNetM->action), action, HeatersNetM);
    }
    if (Coordinator->NumStateVariables > 0) {
      action->ShareWith(getSharableSVPointer(Coordinator->action));
      addSharingInfo(getSharableSVPointer(Coordinator->action), action, Coordinator);
    }

    //Shared variable 1
    id = new Place("id");
    addSharedPtr(id, "id" );
    if (HeatersNetM->NumStateVariables > 0) {
      id->ShareWith(getSharableSVPointer(HeatersNetM->id));
      addSharingInfo(getSharableSVPointer(HeatersNetM->id), id, HeatersNetM);
    }
    if (Coordinator->NumStateVariables > 0) {
      id->ShareWith(getSharableSVPointer(Coordinator->id));
      addSharingInfo(getSharableSVPointer(Coordinator->id), id, Coordinator);
    }

    //Shared variable 2
    notifyIn = new Place("notifyIn");
    addSharedPtr(notifyIn, "notifyIn" );
    if (HeatersNetM->NumStateVariables > 0) {
      notifyIn->ShareWith(getSharableSVPointer(HeatersNetM->notifyIn));
      addSharingInfo(getSharableSVPointer(HeatersNetM->notifyIn), notifyIn, HeatersNetM);
    }
    if (Coordinator->NumStateVariables > 0) {
      notifyIn->ShareWith(getSharableSVPointer(Coordinator->notifyIn));
      addSharingInfo(getSharableSVPointer(Coordinator->notifyIn), notifyIn, Coordinator);
    }

    //Shared variable 3
    notifyOut = new Place("notifyOut");
    addSharedPtr(notifyOut, "notifyOut" );
    if (HeatersNetM->NumStateVariables > 0) {
      notifyOut->ShareWith(getSharableSVPointer(HeatersNetM->notifyOut));
      addSharingInfo(getSharableSVPointer(HeatersNetM->notifyOut), notifyOut, HeatersNetM);
    }
    if (Coordinator->NumStateVariables > 0) {
      notifyOut->ShareWith(getSharableSVPointer(Coordinator->notifyOut));
      addSharingInfo(getSharableSVPointer(Coordinator->notifyOut), notifyOut, Coordinator);
    }

    //Shared variable 4
    synch = new Place("synch");
    addSharedPtr(synch, "synch" );
    if (HeatersNetM->NumStateVariables > 0) {
      synch->ShareWith(getSharableSVPointer(HeatersNetM->synch));
      addSharingInfo(getSharableSVPointer(HeatersNetM->synch), synch, HeatersNetM);
    }
    if (Coordinator->NumStateVariables > 0) {
      synch->ShareWith(getSharableSVPointer(Coordinator->synch));
      addSharingInfo(getSharableSVPointer(Coordinator->synch), synch, Coordinator);
    }

  }

  Setup();
}

SwitchNetRJ::~SwitchNetRJ() {
  if (!AllChildrenEmpty()) {
    delete action;
    delete id;
    delete notifyIn;
    delete notifyOut;
    delete synch;
  }
  delete HeatersNetM;
  delete Coordinator;
}
