#ifndef SwitchNetRJ__Rep1_H_
#define SwitchNetRJ__Rep1_H_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Composer/Rep.h"
#include "Cpp/Composer/AllStateVariableTypes.h"

//Submodel header files
#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
extern Short numSwitch;

class SwitchNetRJ__Rep1: public Rep {
 public:
  SwitchNetRJ__Join1 ** InstanceArray;

  SwitchNetRJ__Rep1();
  ~SwitchNetRJ__Rep1();

  // Declare new variables
  Place * action;
  Place * id;
  Place * notifyIn;
  Place * notifyOut;
  Place * p1;
  Place * synch;
};

#endif
