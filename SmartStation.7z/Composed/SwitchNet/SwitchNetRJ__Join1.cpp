#include "Composed/SwitchNet/SwitchNetRJ__Join1.h"
char * SwitchNetRJ__Join1__SharedNames[] = {"SwitchID", "action", "id", "locality", "notifyIn", "notifyOut", "p1", "profileID", "synch"};

SwitchNetRJ__Join1::SwitchNetRJ__Join1():Join("Join1", 4, 9,SwitchNetRJ__Join1__SharedNames) {
  RailSwitchHeater2 = new RailSwitchHeater2SAN();
  ModelArray[0] = (BaseModelClass*) RailSwitchHeater2;
  ModelArray[0]->DefineName("RailSwitchHeater2");
  LocalitySelector = new LocalitySelectorSAN();
  ModelArray[1] = (BaseModelClass*) LocalitySelector;
  ModelArray[1]->DefineName("LocalitySelector");
  ProfileSelector = new ProfileSelectorSAN();
  ModelArray[2] = (BaseModelClass*) ProfileSelector;
  ModelArray[2]->DefineName("ProfileSelector");
  SwitchIDSelector = new SwitchIDSelectorSAN();
  ModelArray[3] = (BaseModelClass*) SwitchIDSelector;
  ModelArray[3]->DefineName("SwitchIDSelector");

  SetupActions();
  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************  State sharing info  **************
    //Shared variable 0
    SwitchID = new Place("SwitchID");
    addSharedPtr(SwitchID, "SwitchID" );
    if (RailSwitchHeater2->NumStateVariables > 0) {
      SwitchID->ShareWith(getSharableSVPointer(RailSwitchHeater2->SwitchID));
      addSharingInfo(getSharableSVPointer(RailSwitchHeater2->SwitchID), SwitchID, RailSwitchHeater2);
    }
    if (SwitchIDSelector->NumStateVariables > 0) {
      SwitchID->ShareWith(getSharableSVPointer(SwitchIDSelector->SwitchID));
      addSharingInfo(getSharableSVPointer(SwitchIDSelector->SwitchID), SwitchID, SwitchIDSelector);
    }

    //Shared variable 1
    action = new Place("action");
    addSharedPtr(action, "action" );
    if (RailSwitchHeater2->NumStateVariables > 0) {
      action->ShareWith(getSharableSVPointer(RailSwitchHeater2->action));
      addSharingInfo(getSharableSVPointer(RailSwitchHeater2->action), action, RailSwitchHeater2);
    }

    //Shared variable 2
    id = new Place("id");
    addSharedPtr(id, "id" );
    if (RailSwitchHeater2->NumStateVariables > 0) {
      id->ShareWith(getSharableSVPointer(RailSwitchHeater2->id));
      addSharingInfo(getSharableSVPointer(RailSwitchHeater2->id), id, RailSwitchHeater2);
    }

    //Shared variable 3
    locality = new Place("locality");
    addSharedPtr(locality, "locality" );
    if (RailSwitchHeater2->NumStateVariables > 0) {
      locality->ShareWith(getSharableSVPointer(RailSwitchHeater2->locality));
      addSharingInfo(getSharableSVPointer(RailSwitchHeater2->locality), locality, RailSwitchHeater2);
    }
    if (LocalitySelector->NumStateVariables > 0) {
      locality->ShareWith(getSharableSVPointer(LocalitySelector->locality));
      addSharingInfo(getSharableSVPointer(LocalitySelector->locality), locality, LocalitySelector);
    }

    //Shared variable 4
    notifyIn = new Place("notifyIn");
    addSharedPtr(notifyIn, "notifyIn" );
    if (RailSwitchHeater2->NumStateVariables > 0) {
      notifyIn->ShareWith(getSharableSVPointer(RailSwitchHeater2->notifyIn));
      addSharingInfo(getSharableSVPointer(RailSwitchHeater2->notifyIn), notifyIn, RailSwitchHeater2);
    }

    //Shared variable 5
    notifyOut = new Place("notifyOut");
    addSharedPtr(notifyOut, "notifyOut" );
    if (RailSwitchHeater2->NumStateVariables > 0) {
      notifyOut->ShareWith(getSharableSVPointer(RailSwitchHeater2->notifyOut));
      addSharingInfo(getSharableSVPointer(RailSwitchHeater2->notifyOut), notifyOut, RailSwitchHeater2);
    }

    //Shared variable 6
    p1 = new Place("p1");
    addSharedPtr(p1, "p1" );
    if (SwitchIDSelector->NumStateVariables > 0) {
      p1->ShareWith(getSharableSVPointer(SwitchIDSelector->p1));
      addSharingInfo(getSharableSVPointer(SwitchIDSelector->p1), p1, SwitchIDSelector);
    }

    //Shared variable 7
    profileID = new Place("profileID");
    addSharedPtr(profileID, "profileID" );
    if (RailSwitchHeater2->NumStateVariables > 0) {
      profileID->ShareWith(getSharableSVPointer(RailSwitchHeater2->profileID));
      addSharingInfo(getSharableSVPointer(RailSwitchHeater2->profileID), profileID, RailSwitchHeater2);
    }
    if (ProfileSelector->NumStateVariables > 0) {
      profileID->ShareWith(getSharableSVPointer(ProfileSelector->profileID));
      addSharingInfo(getSharableSVPointer(ProfileSelector->profileID), profileID, ProfileSelector);
    }

    //Shared variable 8
    synch = new Place("synch");
    addSharedPtr(synch, "synch" );
    if (RailSwitchHeater2->NumStateVariables > 0) {
      synch->ShareWith(getSharableSVPointer(RailSwitchHeater2->synch));
      addSharingInfo(getSharableSVPointer(RailSwitchHeater2->synch), synch, RailSwitchHeater2);
    }

  }

  Setup();
}

SwitchNetRJ__Join1::~SwitchNetRJ__Join1() {
  if (!AllChildrenEmpty()) {
    delete SwitchID;
    delete action;
    delete id;
    delete locality;
    delete notifyIn;
    delete notifyOut;
    delete p1;
    delete profileID;
    delete synch;
  }
  delete RailSwitchHeater2;
  delete LocalitySelector;
  delete ProfileSelector;
  delete SwitchIDSelector;
}
