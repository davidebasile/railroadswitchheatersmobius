#ifndef SwitchNetRJ__Join1_H_
#define SwitchNetRJ__Join1_H_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Composer/Join.h"
#include "Cpp/Composer/AllStateVariableTypes.h"
#include "Atomic/RailSwitchHeater2/RailSwitchHeater2SAN.h"
#include "Atomic/LocalitySelector/LocalitySelectorSAN.h"
#include "Atomic/ProfileSelector/ProfileSelectorSAN.h"
#include "Atomic/SwitchIDSelector/SwitchIDSelectorSAN.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
extern Short numSwitch;

class SwitchNetRJ__Join1: public Join {
 public:
  RailSwitchHeater2SAN * RailSwitchHeater2;
  LocalitySelectorSAN * LocalitySelector;
  ProfileSelectorSAN * ProfileSelector;
  SwitchIDSelectorSAN * SwitchIDSelector;
  Place * SwitchID;
  Place * action;
  Place * id;
  Place * locality;
  Place * notifyIn;
  Place * notifyOut;
  Place * p1;
  Place * profileID;
  Place * synch;

  SwitchNetRJ__Join1();
  ~SwitchNetRJ__Join1();
};

#endif
