#include "Composed/SwitchNet/SwitchNetRJ__HeaterModuleM.h"
char * SwitchNetRJ__HeaterModuleM__SharedNames[] = {"SwitchID", "action", "id", "locality", "notifyIn", "notifyOut", "p1", "profileID", "synch"};

SwitchNetRJ__HeaterModuleM::SwitchNetRJ__HeaterModuleM():Join("HeaterModuleM", 4, 9,SwitchNetRJ__HeaterModuleM__SharedNames) {
  RailRoadSwitchHeater = new RailSwitchHeater2SAN();
  ModelArray[0] = (BaseModelClass*) RailRoadSwitchHeater;
  ModelArray[0]->DefineName("RailRoadSwitchHeater");
  LocalitySelector = new LocalitySelectorSAN();
  ModelArray[1] = (BaseModelClass*) LocalitySelector;
  ModelArray[1]->DefineName("LocalitySelector");
  ProfileSelector = new ProfileSelectorSAN();
  ModelArray[2] = (BaseModelClass*) ProfileSelector;
  ModelArray[2]->DefineName("ProfileSelector");
  SwitchIDSelector = new SwitchIDSelectorSAN();
  ModelArray[3] = (BaseModelClass*) SwitchIDSelector;
  ModelArray[3]->DefineName("SwitchIDSelector");

  SetupActions();
  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************  State sharing info  **************
    //Shared variable 0
    SwitchID = new Place("SwitchID");
    addSharedPtr(SwitchID, "SwitchID" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      SwitchID->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->SwitchID));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->SwitchID), SwitchID, RailRoadSwitchHeater);
    }
    if (SwitchIDSelector->NumStateVariables > 0) {
      SwitchID->ShareWith(getSharableSVPointer(SwitchIDSelector->SwitchID));
      addSharingInfo(getSharableSVPointer(SwitchIDSelector->SwitchID), SwitchID, SwitchIDSelector);
    }

    //Shared variable 1
    action = new Place("action");
    addSharedPtr(action, "action" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      action->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->action));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->action), action, RailRoadSwitchHeater);
    }

    //Shared variable 2
    id = new Place("id");
    addSharedPtr(id, "id" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      id->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->id));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->id), id, RailRoadSwitchHeater);
    }

    //Shared variable 3
    locality = new Place("locality");
    addSharedPtr(locality, "locality" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      locality->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->locality));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->locality), locality, RailRoadSwitchHeater);
    }
    if (LocalitySelector->NumStateVariables > 0) {
      locality->ShareWith(getSharableSVPointer(LocalitySelector->locality));
      addSharingInfo(getSharableSVPointer(LocalitySelector->locality), locality, LocalitySelector);
    }

    //Shared variable 4
    notifyIn = new Place("notifyIn");
    addSharedPtr(notifyIn, "notifyIn" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      notifyIn->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->notifyIn));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->notifyIn), notifyIn, RailRoadSwitchHeater);
    }

    //Shared variable 5
    notifyOut = new Place("notifyOut");
    addSharedPtr(notifyOut, "notifyOut" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      notifyOut->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->notifyOut));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->notifyOut), notifyOut, RailRoadSwitchHeater);
    }

    //Shared variable 6
    p1 = new Place("p1");
    addSharedPtr(p1, "p1" );
    if (SwitchIDSelector->NumStateVariables > 0) {
      p1->ShareWith(getSharableSVPointer(SwitchIDSelector->p1));
      addSharingInfo(getSharableSVPointer(SwitchIDSelector->p1), p1, SwitchIDSelector);
    }

    //Shared variable 7
    profileID = new Place("profileID");
    addSharedPtr(profileID, "profileID" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      profileID->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->profileID));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->profileID), profileID, RailRoadSwitchHeater);
    }
    if (ProfileSelector->NumStateVariables > 0) {
      profileID->ShareWith(getSharableSVPointer(ProfileSelector->profileID));
      addSharingInfo(getSharableSVPointer(ProfileSelector->profileID), profileID, ProfileSelector);
    }

    //Shared variable 8
    synch = new Place("synch");
    addSharedPtr(synch, "synch" );
    if (RailRoadSwitchHeater->NumStateVariables > 0) {
      synch->ShareWith(getSharableSVPointer(RailRoadSwitchHeater->synch));
      addSharingInfo(getSharableSVPointer(RailRoadSwitchHeater->synch), synch, RailRoadSwitchHeater);
    }

  }

  Setup();
}

SwitchNetRJ__HeaterModuleM::~SwitchNetRJ__HeaterModuleM() {
  if (!AllChildrenEmpty()) {
    delete SwitchID;
    delete action;
    delete id;
    delete locality;
    delete notifyIn;
    delete notifyOut;
    delete p1;
    delete profileID;
    delete synch;
  }
  delete RailRoadSwitchHeater;
  delete LocalitySelector;
  delete ProfileSelector;
  delete SwitchIDSelector;
}
