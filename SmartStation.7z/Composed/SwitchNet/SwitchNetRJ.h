#ifndef SwitchNetRJ_H_
#define SwitchNetRJ_H_
#include "include/SmartStation.h"
#include <math.h>
#include "Cpp/Composer/Join.h"
#include "Cpp/Composer/AllStateVariableTypes.h"
#include "Composed/SwitchNet/SwitchNetRJ__HeatersNetM.h"
#include "Atomic/Queue/QueueSAN.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
extern Short numSwitch;

class SwitchNetRJ: public Join {
 public:
  SwitchNetRJ__HeatersNetM * HeatersNetM;
  QueueSAN * Coordinator;
  Place * action;
  Place * id;
  Place * notifyIn;
  Place * notifyOut;
  Place * synch;

  SwitchNetRJ();
  ~SwitchNetRJ();
};

#endif
