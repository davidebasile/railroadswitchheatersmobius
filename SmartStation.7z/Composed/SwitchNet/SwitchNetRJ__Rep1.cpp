#include "Composed/SwitchNet/SwitchNetRJ__Rep1.h"
char * SwitchNetRJ__Rep1__SharedNames[] = {"action", "id", "notifyIn", "notifyOut", "p1", "synch"};

SwitchNetRJ__Rep1::SwitchNetRJ__Rep1():Rep("Rep1", numSwitch, 6, SwitchNetRJ__Rep1__SharedNames)
{
  InstanceArray = new SwitchNetRJ__Join1 * [NumModels];
  delete[] ModelArray;
  ModelArray = (BaseModelClass **) InstanceArray;
  for (counter = 0; counter < NumModels; counter++)
    InstanceArray[counter] = new SwitchNetRJ__Join1();

  SetupActions();
  if (NumModels == 0) return;

  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************** Initialize local variables ****************
    action = new Place("action");
    addSharedPtr(action, "action");
    action->ShareWith(InstanceArray[0]->action);

    id = new Place("id");
    addSharedPtr(id, "id");
    id->ShareWith(InstanceArray[0]->id);

    notifyIn = new Place("notifyIn");
    addSharedPtr(notifyIn, "notifyIn");
    notifyIn->ShareWith(InstanceArray[0]->notifyIn);

    notifyOut = new Place("notifyOut");
    addSharedPtr(notifyOut, "notifyOut");
    notifyOut->ShareWith(InstanceArray[0]->notifyOut);

    p1 = new Place("p1");
    addSharedPtr(p1, "p1");
    p1->ShareWith(InstanceArray[0]->p1);

    synch = new Place("synch");
    addSharedPtr(synch, "synch");
    synch->ShareWith(InstanceArray[0]->synch);


    //Share state in submodels
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->action, action);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->id, id);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->notifyIn, notifyIn);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->notifyOut, notifyOut);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->p1, p1);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->synch, synch);
    }
    for (counter = 1; counter < NumModels; counter++) {
      InstanceArray[0]->action->ShareWith(InstanceArray[counter]->action);
      InstanceArray[0]->id->ShareWith(InstanceArray[counter]->id);
      InstanceArray[0]->notifyIn->ShareWith(InstanceArray[counter]->notifyIn);
      InstanceArray[0]->notifyOut->ShareWith(InstanceArray[counter]->notifyOut);
      InstanceArray[0]->p1->ShareWith(InstanceArray[counter]->p1);
      InstanceArray[0]->synch->ShareWith(InstanceArray[counter]->synch);
    }
  }
  Setup("Join1");
}

SwitchNetRJ__Rep1::~SwitchNetRJ__Rep1() {
  if (NumModels == 0) return;
  delete action;
  delete id;
  delete notifyIn;
  delete notifyOut;
  delete p1;
  delete synch;
  for (int i = 0; i < NumModels; i++)
    delete InstanceArray[i];
}

