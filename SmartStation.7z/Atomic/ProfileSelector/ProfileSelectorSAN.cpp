

// This C++ file was created by SanEditor

#include "Atomic/ProfileSelector/ProfileSelectorSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         ProfileSelectorSAN Constructor             
******************************************************************/


ProfileSelectorSAN::ProfileSelectorSAN(){


  selectProfileGroup.initialize(5, "selectProfileGroup");
  selectProfileGroup.appendGroup((BaseGroupClass*) &selectProfile_case1);
  selectProfileGroup.appendGroup((BaseGroupClass*) &selectProfile_case2);
  selectProfileGroup.appendGroup((BaseGroupClass*) &selectProfile_case3);
  selectProfileGroup.appendGroup((BaseGroupClass*) &selectProfile_case4);
  selectProfileGroup.appendGroup((BaseGroupClass*) &selectProfile_case5);

  Activity* InitialActionList[5]={
    &selectProfile_case1, //0
    &selectProfile_case2, //1
    &selectProfile_case3, //2
    &selectProfile_case4, //3
    &selectProfile_case5  // 4
  };

  BaseGroupClass* InitialGroupList[1]={
    (BaseGroupClass*) &(selectProfileGroup)
  };

  s = new Place("s" ,1);
  profileID = new Place("profileID" ,0);
  BaseStateVariableClass* InitialPlaces[2]={
    s,  // 0
    profileID   // 1
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("ProfileSelector", 2, InitialPlaces, 
                        0, InitialROPlaces, 
                        5, InitialActionList, 1, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[10][2]={ 
    {0,0}, {1,0}, {0,1}, {1,1}, {0,2}, {1,2}, {0,3}, {1,3}, {0,4}, 
    {1,4}
  };
  for(int n=0;n<10;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[5][2]={ 
    {0,0}, {0,1}, {0,2}, {0,3}, {0,4}
  };
  for(int n=0;n<5;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<5;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void ProfileSelectorSAN::CustomInitialization() {

}
ProfileSelectorSAN::~ProfileSelectorSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void ProfileSelectorSAN::assignPlacesToActivitiesInst(){
  selectProfile_case1.s = (Place*) LocalStateVariables[0];
  selectProfile_case1.profileID = (Place*) LocalStateVariables[1];
  selectProfile_case2.s = (Place*) LocalStateVariables[0];
  selectProfile_case2.profileID = (Place*) LocalStateVariables[1];
  selectProfile_case3.s = (Place*) LocalStateVariables[0];
  selectProfile_case3.profileID = (Place*) LocalStateVariables[1];
  selectProfile_case4.s = (Place*) LocalStateVariables[0];
  selectProfile_case4.profileID = (Place*) LocalStateVariables[1];
  selectProfile_case5.s = (Place*) LocalStateVariables[0];
  selectProfile_case5.profileID = (Place*) LocalStateVariables[1];
}
void ProfileSelectorSAN::assignPlacesToActivitiesTimed(){
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================selectProfileActivity_case1========================*/


ProfileSelectorSAN::selectProfileActivity_case1::selectProfileActivity_case1(){
  ActivityInitialize("selectProfile_case1",0,Instantaneous , RaceEnabled, 2,1, false);
}

void ProfileSelectorSAN::selectProfileActivity_case1::LinkVariables(){
  s->Register(&s_Mobius_Mark);
  profileID->Register(&profileID_Mobius_Mark);
}

bool ProfileSelectorSAN::selectProfileActivity_case1::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((s->Mark() > 0));
  return NewEnabled;
}

double ProfileSelectorSAN::selectProfileActivity_case1::Weight(){ 
  return 0.25;
}

bool ProfileSelectorSAN::selectProfileActivity_case1::ReactivationPredicate(){ 
  return false;
}

bool ProfileSelectorSAN::selectProfileActivity_case1::ReactivationFunction(){ 
  return false;
}

double ProfileSelectorSAN::selectProfileActivity_case1::SampleDistribution(){
  return 0;
}

double* ProfileSelectorSAN::selectProfileActivity_case1::ReturnDistributionParameters(){
    return NULL;
}

int ProfileSelectorSAN::selectProfileActivity_case1::Rank(){
  return 1;
}

BaseActionClass* ProfileSelectorSAN::selectProfileActivity_case1::Fire(){
  s->Mark()=0;
  profileID->Mark()=1;
  return this;
}

/*======================selectProfileActivity_case2========================*/


ProfileSelectorSAN::selectProfileActivity_case2::selectProfileActivity_case2(){
  ActivityInitialize("selectProfile_case2",0,Instantaneous , RaceEnabled, 2,1, false);
}

void ProfileSelectorSAN::selectProfileActivity_case2::LinkVariables(){
  s->Register(&s_Mobius_Mark);
  profileID->Register(&profileID_Mobius_Mark);
}

bool ProfileSelectorSAN::selectProfileActivity_case2::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((s->Mark() > 0));
  return NewEnabled;
}

double ProfileSelectorSAN::selectProfileActivity_case2::Weight(){ 
  return 0.2;
}

bool ProfileSelectorSAN::selectProfileActivity_case2::ReactivationPredicate(){ 
  return false;
}

bool ProfileSelectorSAN::selectProfileActivity_case2::ReactivationFunction(){ 
  return false;
}

double ProfileSelectorSAN::selectProfileActivity_case2::SampleDistribution(){
  return 0;
}

double* ProfileSelectorSAN::selectProfileActivity_case2::ReturnDistributionParameters(){
    return NULL;
}

int ProfileSelectorSAN::selectProfileActivity_case2::Rank(){
  return 1;
}

BaseActionClass* ProfileSelectorSAN::selectProfileActivity_case2::Fire(){
  s->Mark()=0;
  profileID->Mark()=2;
  return this;
}

/*======================selectProfileActivity_case3========================*/


ProfileSelectorSAN::selectProfileActivity_case3::selectProfileActivity_case3(){
  ActivityInitialize("selectProfile_case3",0,Instantaneous , RaceEnabled, 2,1, false);
}

void ProfileSelectorSAN::selectProfileActivity_case3::LinkVariables(){
  s->Register(&s_Mobius_Mark);
  profileID->Register(&profileID_Mobius_Mark);
}

bool ProfileSelectorSAN::selectProfileActivity_case3::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((s->Mark() > 0));
  return NewEnabled;
}

double ProfileSelectorSAN::selectProfileActivity_case3::Weight(){ 
  return 0.2;
}

bool ProfileSelectorSAN::selectProfileActivity_case3::ReactivationPredicate(){ 
  return false;
}

bool ProfileSelectorSAN::selectProfileActivity_case3::ReactivationFunction(){ 
  return false;
}

double ProfileSelectorSAN::selectProfileActivity_case3::SampleDistribution(){
  return 0;
}

double* ProfileSelectorSAN::selectProfileActivity_case3::ReturnDistributionParameters(){
    return NULL;
}

int ProfileSelectorSAN::selectProfileActivity_case3::Rank(){
  return 1;
}

BaseActionClass* ProfileSelectorSAN::selectProfileActivity_case3::Fire(){
  s->Mark()=0;
  profileID->Mark()=3;
  return this;
}

/*======================selectProfileActivity_case4========================*/


ProfileSelectorSAN::selectProfileActivity_case4::selectProfileActivity_case4(){
  ActivityInitialize("selectProfile_case4",0,Instantaneous , RaceEnabled, 2,1, false);
}

void ProfileSelectorSAN::selectProfileActivity_case4::LinkVariables(){
  s->Register(&s_Mobius_Mark);
  profileID->Register(&profileID_Mobius_Mark);
}

bool ProfileSelectorSAN::selectProfileActivity_case4::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((s->Mark() > 0));
  return NewEnabled;
}

double ProfileSelectorSAN::selectProfileActivity_case4::Weight(){ 
  return 0.15;
}

bool ProfileSelectorSAN::selectProfileActivity_case4::ReactivationPredicate(){ 
  return false;
}

bool ProfileSelectorSAN::selectProfileActivity_case4::ReactivationFunction(){ 
  return false;
}

double ProfileSelectorSAN::selectProfileActivity_case4::SampleDistribution(){
  return 0;
}

double* ProfileSelectorSAN::selectProfileActivity_case4::ReturnDistributionParameters(){
    return NULL;
}

int ProfileSelectorSAN::selectProfileActivity_case4::Rank(){
  return 1;
}

BaseActionClass* ProfileSelectorSAN::selectProfileActivity_case4::Fire(){
  s->Mark()=0;
  profileID->Mark()=4;
  return this;
}

/*======================selectProfileActivity_case5========================*/


ProfileSelectorSAN::selectProfileActivity_case5::selectProfileActivity_case5(){
  ActivityInitialize("selectProfile_case5",0,Instantaneous , RaceEnabled, 2,1, false);
}

void ProfileSelectorSAN::selectProfileActivity_case5::LinkVariables(){
  s->Register(&s_Mobius_Mark);
  profileID->Register(&profileID_Mobius_Mark);
}

bool ProfileSelectorSAN::selectProfileActivity_case5::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((s->Mark() > 0));
  return NewEnabled;
}

double ProfileSelectorSAN::selectProfileActivity_case5::Weight(){ 
  return 0.2;
}

bool ProfileSelectorSAN::selectProfileActivity_case5::ReactivationPredicate(){ 
  return false;
}

bool ProfileSelectorSAN::selectProfileActivity_case5::ReactivationFunction(){ 
  return false;
}

double ProfileSelectorSAN::selectProfileActivity_case5::SampleDistribution(){
  return 0;
}

double* ProfileSelectorSAN::selectProfileActivity_case5::ReturnDistributionParameters(){
    return NULL;
}

int ProfileSelectorSAN::selectProfileActivity_case5::Rank(){
  return 1;
}

BaseActionClass* ProfileSelectorSAN::selectProfileActivity_case5::Fire(){
  s->Mark()=0;
  profileID->Mark()=5;
  return this;
}

