#ifndef ProfileSelectorSAN_H_
#define ProfileSelectorSAN_H_

#include "include/SmartStation.h"
#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               ProfileSelectorSAN Submodel Definition                   
*********************************************************************/

class ProfileSelectorSAN:public SANModel{
public:

class selectProfileActivity_case1:public Activity {
public:

  Place* s;
  short* s_Mobius_Mark;
  Place* profileID;
  short* profileID_Mobius_Mark;

  double* TheDistributionParameters;
  selectProfileActivity_case1();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // selectProfileActivity_case1Activity

class selectProfileActivity_case2:public Activity {
public:

  Place* s;
  short* s_Mobius_Mark;
  Place* profileID;
  short* profileID_Mobius_Mark;

  double* TheDistributionParameters;
  selectProfileActivity_case2();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // selectProfileActivity_case2Activity

class selectProfileActivity_case3:public Activity {
public:

  Place* s;
  short* s_Mobius_Mark;
  Place* profileID;
  short* profileID_Mobius_Mark;

  double* TheDistributionParameters;
  selectProfileActivity_case3();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // selectProfileActivity_case3Activity

class selectProfileActivity_case4:public Activity {
public:

  Place* s;
  short* s_Mobius_Mark;
  Place* profileID;
  short* profileID_Mobius_Mark;

  double* TheDistributionParameters;
  selectProfileActivity_case4();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // selectProfileActivity_case4Activity

class selectProfileActivity_case5:public Activity {
public:

  Place* s;
  short* s_Mobius_Mark;
  Place* profileID;
  short* profileID_Mobius_Mark;

  double* TheDistributionParameters;
  selectProfileActivity_case5();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // selectProfileActivity_case5Activity

  //List of user-specified place names
  Place* s;
  Place* profileID;

  // Create instances of all actvities
  selectProfileActivity_case1 selectProfile_case1;
  selectProfileActivity_case2 selectProfile_case2;
  selectProfileActivity_case3 selectProfile_case3;
  selectProfileActivity_case4 selectProfile_case4;
  selectProfileActivity_case5 selectProfile_case5;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup selectProfileGroup;

  ProfileSelectorSAN();
  ~ProfileSelectorSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end ProfileSelectorSAN

#endif // ProfileSelectorSAN_H_
