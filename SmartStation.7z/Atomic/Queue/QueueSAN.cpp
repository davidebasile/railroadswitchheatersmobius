

// This C++ file was created by SanEditor

#include "Atomic/Queue/QueueSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         QueueSAN Constructor             
******************************************************************/


QueueSAN::QueueSAN(){


  Activity* InitialActionList[2]={
    &IA_queue, //0
    &IA_init  // 1
  };

  BaseGroupClass* InitialGroupList[2]={
    (BaseGroupClass*) &(IA_queue), 
    (BaseGroupClass*) &(IA_init)
  };

  queue = new Place("queue" ,0);
  action = new Place("action" ,0);
  notifyIn = new Place("notifyIn" ,0);
  notifyOut = new Place("notifyOut" ,0);
  id = new Place("id" ,0);
  p = new Place("p" ,1);
  init = new Place("init" ,1);
  synch = new Place("synch" ,0);
  BaseStateVariableClass* InitialPlaces[8]={
    queue,  // 0
    action,  // 1
    notifyIn,  // 2
    notifyOut,  // 3
    id,  // 4
    p,  // 5
    init,  // 6
    synch   // 7
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("Queue", 8, InitialPlaces, 
                        0, InitialROPlaces, 
                        2, InitialActionList, 2, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[7][2]={ 
    {5,0}, {0,0}, {1,0}, {4,0}, {2,0}, {3,0}, {6,1}
  };
  for(int n=0;n<7;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[6][2]={ 
    {1,0}, {5,0}, {2,0}, {3,0}, {7,0}, {6,1}
  };
  for(int n=0;n<6;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<2;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void QueueSAN::CustomInitialization() {

}
QueueSAN::~QueueSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void QueueSAN::assignPlacesToActivitiesInst(){
  IA_queue.action = (Place*) LocalStateVariables[1];
  IA_queue.p = (Place*) LocalStateVariables[5];
  IA_queue.notifyIn = (Place*) LocalStateVariables[2];
  IA_queue.notifyOut = (Place*) LocalStateVariables[3];
  IA_queue.synch = (Place*) LocalStateVariables[7];
  IA_queue.queue = (Place*) LocalStateVariables[0];
  IA_queue.id = (Place*) LocalStateVariables[4];
  IA_init.init = (Place*) LocalStateVariables[6];
}
void QueueSAN::assignPlacesToActivitiesTimed(){
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================IA_queueActivity========================*/


QueueSAN::IA_queueActivity::IA_queueActivity(){
  ActivityInitialize("IA_queue",0,Instantaneous , RaceEnabled, 6,5, false);
}

void QueueSAN::IA_queueActivity::LinkVariables(){
  action->Register(&action_Mobius_Mark);
  p->Register(&p_Mobius_Mark);
  notifyIn->Register(&notifyIn_Mobius_Mark);
  notifyOut->Register(&notifyOut_Mobius_Mark);
  synch->Register(&synch_Mobius_Mark);
  queue->Register(&queue_Mobius_Mark);
  id->Register(&id_Mobius_Mark);
}

bool QueueSAN::IA_queueActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((action->Mark()>0)
&&
(p->Mark()==1)
&&
(notifyIn->Mark()==0)
&&
(notifyOut->Mark()==0)
&&
(synch->Mark()==numSwitch)));
  return NewEnabled;
}

double QueueSAN::IA_queueActivity::Weight(){ 
  return 1;
}

bool QueueSAN::IA_queueActivity::ReactivationPredicate(){ 
  return false;
}

bool QueueSAN::IA_queueActivity::ReactivationFunction(){ 
  return false;
}

double QueueSAN::IA_queueActivity::SampleDistribution(){
  return 0;
}

double* QueueSAN::IA_queueActivity::ReturnDistributionParameters(){
    return NULL;
}

int QueueSAN::IA_queueActivity::Rank(){
  return 1;
}

BaseActionClass* QueueSAN::IA_queueActivity::Fire(){
  p->Mark()=0;
  int tot=queue->Mark();
if (action->Mark()==1)  //insert
{
	if (tot<queueSize)
	{
		queue->Mark()++;
		#ifndef DEBUG
			cout<<"Insert Switch "<<id->Mark()<<" \n";
		#endif
		notifyIn->Mark()=id->Mark();
	}
	else if (tot==queueSize)
	{		
		int rr = q.remove(w[id->Mark()].getPriority());
		if (rr!=0)
		{
			#ifndef DEBUG
				cout<<"Notify out Switch "<<rr<<" \n";
				cout<<"Notify in Switch "<<id->Mark()<<" \n";
			#endif
			notifyOut->Mark()=rr;
			notifyIn->Mark()=id->Mark();
		}
	}
}
else if ((action->Mark()==2)&&(tot>0))  //remove
{
	#ifndef DEBUG
	cout<<"Removed Switch "<<id->Mark()<<" \n";
	#endif
	int swid=q.insert();
	if (swid!=0)
	{
		#ifndef DEBUG
			cout<<"Notify in Switch "<<swid<<" \n";
		#endif
		notifyIn->Mark()=swid;
	}
	else
		queue->Mark()--; //it can be that all switches are on or off
}

p->Mark()=1;
action->Mark()=0;
  return this;
}

/*======================IA_initActivity========================*/


QueueSAN::IA_initActivity::IA_initActivity(){
  ActivityInitialize("IA_init",1,Instantaneous , RaceEnabled, 1,1, false);
}

void QueueSAN::IA_initActivity::LinkVariables(){
  init->Register(&init_Mobius_Mark);
}

bool QueueSAN::IA_initActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((init->Mark()==1));
  return NewEnabled;
}

double QueueSAN::IA_initActivity::Weight(){ 
  return 1;
}

bool QueueSAN::IA_initActivity::ReactivationPredicate(){ 
  return false;
}

bool QueueSAN::IA_initActivity::ReactivationFunction(){ 
  return false;
}

double QueueSAN::IA_initActivity::SampleDistribution(){
  return 0;
}

double* QueueSAN::IA_initActivity::ReturnDistributionParameters(){
    return NULL;
}

int QueueSAN::IA_initActivity::Rank(){
  return 1;
}

BaseActionClass* QueueSAN::IA_initActivity::Fire(){
  init->Mark()=0;
q = Queue(numSwitch,3);
  return this;
}

