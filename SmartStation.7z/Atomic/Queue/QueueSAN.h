#ifndef QueueSAN_H_
#define QueueSAN_H_

#include "include/SmartStation.h"
#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short queueSize;
extern Short numSwitch;
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               QueueSAN Submodel Definition                   
*********************************************************************/

class QueueSAN:public SANModel{
public:

class IA_queueActivity:public Activity {
public:

  Place* action;
  short* action_Mobius_Mark;
  Place* p;
  short* p_Mobius_Mark;
  Place* notifyIn;
  short* notifyIn_Mobius_Mark;
  Place* notifyOut;
  short* notifyOut_Mobius_Mark;
  Place* synch;
  short* synch_Mobius_Mark;
  Place* queue;
  short* queue_Mobius_Mark;
  Place* id;
  short* id_Mobius_Mark;

  double* TheDistributionParameters;
  IA_queueActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // IA_queueActivityActivity

class IA_initActivity:public Activity {
public:

  Place* init;
  short* init_Mobius_Mark;

  double* TheDistributionParameters;
  IA_initActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // IA_initActivityActivity

  //List of user-specified place names
  Place* queue;
  Place* action;
  Place* notifyIn;
  Place* notifyOut;
  Place* id;
  Place* p;
  Place* init;
  Place* synch;

  // Create instances of all actvities
  IA_queueActivity IA_queue;
  IA_initActivity IA_init;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup IA_queueGroup;
  PostselectGroup IA_initGroup;

  QueueSAN();
  ~QueueSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end QueueSAN

#endif // QueueSAN_H_
