#ifndef RailRoadSwitchHeaterEvaluationModuleSAN_H_
#define RailRoadSwitchHeaterEvaluationModuleSAN_H_

#include "include/SmartStation.h"
#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short TimeClock;
extern Float warningThreshold;
extern Float freezingThreshold;
extern Short numSwitch;
extern Short queueSize;
extern Short phigh;
extern Short pmedium;
extern Short plow;
extern Short gapThreshold;
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               RailRoadSwitchHeaterEvaluationModuleSAN Submodel Definition                   
*********************************************************************/

class RailRoadSwitchHeaterEvaluationModuleSAN:public SANModel{
public:

class IAstateActivity:public Activity {
public:

  Place* synch;
  short* synch_Mobius_Mark;
  Place* state;
  short* state_Mobius_Mark;
  ExtendedPlace<double>* Temperature;
  Place* TimeOn;
  short* TimeOn_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  Place* TimeReady;
  short* TimeReady_Mobius_Mark;

  double* TheDistributionParameters;
  IAstateActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // IAstateActivityActivity

class ClockActivity:public Activity {
public:

  Place* time;
  short* time_Mobius_Mark;
  Place* state;
  short* state_Mobius_Mark;
  Place* synch;
  short* synch_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  ExtendedPlace<double>* Temperature;
  Place* TimeReady;
  short* TimeReady_Mobius_Mark;
  Place* TimeOn;
  short* TimeOn_Mobius_Mark;
  Place* profileID;
  short* profileID_Mobius_Mark;

  double* TheDistributionParameters;
  ClockActivity();
  ~ClockActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // ClockActivityActivity

class TA_initActivity:public Activity {
public:

  Place* locality;
  short* locality_Mobius_Mark;
  Place* profileID;
  short* profileID_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  Place* s;
  short* s_Mobius_Mark;
  Place* state;
  short* state_Mobius_Mark;
  Place* time;
  short* time_Mobius_Mark;
  ExtendedPlace<double>* Temperature;

  double* TheDistributionParameters;
  TA_initActivity();
  ~TA_initActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // TA_initActivityActivity

class TA_failureActivity:public Activity {
public:

  ExtendedPlace<double>* Temperature;
  Place* state;
  short* state_Mobius_Mark;
  Place* TimeReady;
  short* TimeReady_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  Place* TimeOn;
  short* TimeOn_Mobius_Mark;

  double* TheDistributionParameters;
  TA_failureActivity();
  ~TA_failureActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // TA_failureActivityActivity

  //List of user-specified place names
  Place* time;
  Place* locality;
  Place* profileID;
  Place* SwitchID;
  Place* s;
  Place* TimeReady;
  Place* TimeOn;
  Place* synch;
  Place* state;
  ExtendedPlace<double>* Temperature;

  // Create instances of all actvities
  IAstateActivity IAstate;
  ClockActivity Clock;
  TA_initActivity TA_init;
  TA_failureActivity TA_failure;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup IAstateGroup;

  RailRoadSwitchHeaterEvaluationModuleSAN();
  ~RailRoadSwitchHeaterEvaluationModuleSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end RailRoadSwitchHeaterEvaluationModuleSAN

#endif // RailRoadSwitchHeaterEvaluationModuleSAN_H_
