

// This C++ file was created by SanEditor

#include "Atomic/RailRoadSwitchHeaterEvaluationModule/RailRoadSwitchHeaterEvaluationModuleSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         RailRoadSwitchHeaterEvaluationModuleSAN Constructor             
******************************************************************/


RailRoadSwitchHeaterEvaluationModuleSAN::RailRoadSwitchHeaterEvaluationModuleSAN(){


  Activity* InitialActionList[4]={
    &IAstate, //0
    &Clock, //1
    &TA_init, //2
    &TA_failure  // 3
  };

  BaseGroupClass* InitialGroupList[4]={
    (BaseGroupClass*) &(Clock), 
    (BaseGroupClass*) &(TA_init), 
    (BaseGroupClass*) &(TA_failure), 
    (BaseGroupClass*) &(IAstate)
  };

  time = new Place("time" ,0);
  locality = new Place("locality" ,0);
  profileID = new Place("profileID" ,0);
  SwitchID = new Place("SwitchID" ,0);
  s = new Place("s" ,1);
  TimeReady = new Place("TimeReady" ,0);
  TimeOn = new Place("TimeOn" ,0);
  synch = new Place("synch" ,0);
  state = new Place("state" ,0);
  double temp_Temperaturedouble = 0;
  Temperature = new ExtendedPlace<double>("Temperature",temp_Temperaturedouble);
  BaseStateVariableClass* InitialPlaces[10]={
    time,  // 0
    locality,  // 1
    profileID,  // 2
    SwitchID,  // 3
    s,  // 4
    TimeReady,  // 5
    TimeOn,  // 6
    synch,  // 7
    state,  // 8
    Temperature   // 9
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("RailRoadSwitchHeaterEvaluationModule", 10, InitialPlaces, 
                        0, InitialROPlaces, 
                        4, InitialActionList, 4, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[25][2]={ 
    {8,0}, {6,0}, {3,0}, {5,0}, {9,0}, {7,1}, {0,1}, {3,1}, {9,1}, 
    {8,1}, {5,1}, {6,1}, {2,1}, {4,2}, {3,2}, {2,2}, {1,2}, {8,2}, 
    {0,2}, {9,2}, {5,3}, {3,3}, {6,3}, {8,3}, {9,3}
  };
  for(int n=0;n<25;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[11][2]={ 
    {7,0}, {8,0}, {9,0}, {0,1}, {8,1}, {1,2}, {2,2}, {3,2}, {4,2}, 
    {9,3}, {8,3}
  };
  for(int n=0;n<11;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<4;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void RailRoadSwitchHeaterEvaluationModuleSAN::CustomInitialization() {

}
RailRoadSwitchHeaterEvaluationModuleSAN::~RailRoadSwitchHeaterEvaluationModuleSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void RailRoadSwitchHeaterEvaluationModuleSAN::assignPlacesToActivitiesInst(){
  IAstate.synch = (Place*) LocalStateVariables[7];
  IAstate.state = (Place*) LocalStateVariables[8];
  IAstate.Temperature = (ExtendedPlace<double>*) LocalStateVariables[9];
  IAstate.TimeOn = (Place*) LocalStateVariables[6];
  IAstate.SwitchID = (Place*) LocalStateVariables[3];
  IAstate.TimeReady = (Place*) LocalStateVariables[5];
}
void RailRoadSwitchHeaterEvaluationModuleSAN::assignPlacesToActivitiesTimed(){
  Clock.time = (Place*) LocalStateVariables[0];
  Clock.state = (Place*) LocalStateVariables[8];
  Clock.synch = (Place*) LocalStateVariables[7];
  Clock.SwitchID = (Place*) LocalStateVariables[3];
  Clock.Temperature = (ExtendedPlace<double>*) LocalStateVariables[9];
  Clock.TimeReady = (Place*) LocalStateVariables[5];
  Clock.TimeOn = (Place*) LocalStateVariables[6];
  Clock.profileID = (Place*) LocalStateVariables[2];
  TA_init.locality = (Place*) LocalStateVariables[1];
  TA_init.profileID = (Place*) LocalStateVariables[2];
  TA_init.SwitchID = (Place*) LocalStateVariables[3];
  TA_init.s = (Place*) LocalStateVariables[4];
  TA_init.state = (Place*) LocalStateVariables[8];
  TA_init.time = (Place*) LocalStateVariables[0];
  TA_init.Temperature = (ExtendedPlace<double>*) LocalStateVariables[9];
  TA_failure.Temperature = (ExtendedPlace<double>*) LocalStateVariables[9];
  TA_failure.state = (Place*) LocalStateVariables[8];
  TA_failure.TimeReady = (Place*) LocalStateVariables[5];
  TA_failure.SwitchID = (Place*) LocalStateVariables[3];
  TA_failure.TimeOn = (Place*) LocalStateVariables[6];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================IAstateActivity========================*/


RailRoadSwitchHeaterEvaluationModuleSAN::IAstateActivity::IAstateActivity(){
  ActivityInitialize("IAstate",3,Instantaneous , RaceEnabled, 5,3, false);
}

void RailRoadSwitchHeaterEvaluationModuleSAN::IAstateActivity::LinkVariables(){
  synch->Register(&synch_Mobius_Mark);
  state->Register(&state_Mobius_Mark);

  TimeOn->Register(&TimeOn_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);
  TimeReady->Register(&TimeReady_Mobius_Mark);
}

bool RailRoadSwitchHeaterEvaluationModuleSAN::IAstateActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((synch->Mark()==numSwitch
&&
(
(state->Mark()==11)
||
(state->Mark()==12 // off and above Twa 
&& 
Temperature->Mark()<warningThreshold 
)
||
(
state->Mark()==21 
)
||
(state->Mark()==31)
||
(
state->Mark()==32// on and below Two
&&
(Temperature->Mark() > (warningThreshold+gapThreshold))
) 
)
));
  return NewEnabled;
}

double RailRoadSwitchHeaterEvaluationModuleSAN::IAstateActivity::Weight(){ 
  return 1;
}

bool RailRoadSwitchHeaterEvaluationModuleSAN::IAstateActivity::ReactivationPredicate(){ 
  return false;
}

bool RailRoadSwitchHeaterEvaluationModuleSAN::IAstateActivity::ReactivationFunction(){ 
  return false;
}

double RailRoadSwitchHeaterEvaluationModuleSAN::IAstateActivity::SampleDistribution(){
  return 0;
}

double* RailRoadSwitchHeaterEvaluationModuleSAN::IAstateActivity::ReturnDistributionParameters(){
    return NULL;
}

int RailRoadSwitchHeaterEvaluationModuleSAN::IAstateActivity::Rank(){
  return 1;
}

BaseActionClass* RailRoadSwitchHeaterEvaluationModuleSAN::IAstateActivity::Fire(){
  ;
  if (state->Mark()==11)
{
	state->Mark()=12;
	TimeOn->Mark()=0;
	w[SwitchID->Mark()].resetTimeOn();
}
else if (state->Mark()==12) //off and above Twa
{
	state->Mark()=13;//off and below Twa
}
else if (state->Mark()==21) //ready
{
	w[SwitchID->Mark()].increaseTimeReady();
	TimeReady->Mark()++;
	state->Mark()=22;
}
else if ((state->Mark()==31)) //on and below Two
{
	TimeReady->Mark()=0;
	w[SwitchID->Mark()].resetTimeReady();
	w[SwitchID->Mark()].increaseTimeOn();
	TimeOn->Mark()++;
	state->Mark()=32;
}
else if ((state->Mark()==32)&&(Temperature->Mark() > (warningThreshold+gapThreshold))) //on and below Two
{
	state->Mark()=33;//on and above Two
}

  return this;
}

/*======================ClockActivity========================*/

RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::ClockActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("Clock",0,Deterministic, RaceEnabled, 8,2, false);
}

RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::~ClockActivity(){
  delete[] TheDistributionParameters;
}

void RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::LinkVariables(){
  time->Register(&time_Mobius_Mark);
  state->Register(&state_Mobius_Mark);
  synch->Register(&synch_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);

  TimeReady->Register(&TimeReady_Mobius_Mark);
  TimeOn->Register(&TimeOn_Mobius_Mark);
  profileID->Register(&profileID_Mobius_Mark);
}

bool RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((time->Mark()>=0
&& 
(
state->Mark()>0
)));
  return NewEnabled;
}

double RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::DeterministicParamValue(){
  return TimeClock;
  return 1.0;  // default rate if none is specified
}

double RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::Weight(){ 
  return 1;
}

bool RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::ReactivationPredicate(){ 
  return false;
}

bool RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::ReactivationFunction(){ 
  return false;
}

double RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::SampleDistribution(){
  return TimeClock;
}

double* RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::Rank(){
  return 1;
}

BaseActionClass* RailRoadSwitchHeaterEvaluationModuleSAN::ClockActivity::Fire(){
  ;
  if (synch->Mark() == numSwitch)
	synch->Mark()=0;




//UPDATE TIME
int t = abs(time->Mark() - 24);
//cout<< " time mark " << time->Mark() << " \n";
//cout<< " abs(time->Mark() - 13)=" << t << "\n";
if (t==24)
{
	time->Mark()  = 24;
	t=0;
#ifndef DEBUGG
	cout<< " time mark " << time->Mark() << " and t " << t << " \n";
#endif
}
else
	time->Mark()--;
#ifndef DEBUG
	cout<< "SwitchID " <<SwitchID->Mark()<<" current time " << t<< " Temperature "<< Temperature->Mark() <<" \n";
#endif
w[SwitchID->Mark()].setCurrentTime((short) t);



//UPDATE TIME ON TIME READY
if(state->Mark()==3)
{
	w[SwitchID->Mark()].increaseTimeReady();	
	TimeReady->Mark()++;
	#ifndef DEBUG
	cout<<"SwitchID "<<SwitchID->Mark()<<" time ready "<<TimeReady->Mark()<<" "<<w[SwitchID->Mark()].getTimeReady()<<" \n";
	#endif
}
else if((state->Mark()==4)||(state->Mark()==5))
{
	w[SwitchID->Mark()].increaseTimeOn();	
	TimeOn->Mark()++;
	#ifndef DEBUG
	cout<<"SwitchID "<<SwitchID->Mark()<<" time on "<<TimeOn->Mark()<<" \n";
	#endif
}
#ifndef DEBUGG
		cout << " ( profileID : " <<  w[SwitchID->Mark()].getProfileID() << " , ";
		//cout << " time : " << w[SwitchID->Mark()].getCurrentTime()<< " , ";
		//cout << " off : " << off->Mark() << " , ";
		//cout << " ready : " << ready ->Mark() << " , ";
		//cout << " on : " << on->Mark() << " , ";
		cout << " failure : " << state->Mark() << " , ";
		//cout << " locality : "  << w[SwitchID->Mark()].getLocality()  << " , ";
		//cout << " warningThreshold : " << warningThreshold << " , ";
		//cout << " workingTemperature : " << workingTemperature << " , ";
		//cout << "Freezing threshold " << freezingThreshold << " , ";
		cout << "SwitchID " << SwitchID->Mark() << ")\n";
#endif




//UPDATE TEMPERATURE
if ((state->Mark()!=4)||(state->Mark()!=5))
	w[SwitchID->Mark()].decreaseInternalTemperature();
else if ((state->Mark()>=1)&&(state->Mark()<=3))
	w[SwitchID->Mark()].increaseInternalTemperature();

Temperature->Mark() =  w[SwitchID->Mark()].getInternalTemperature();
synch->Mark()++;
  return this;
}

/*======================TA_initActivity========================*/

RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::TA_initActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("TA_init",1,Deterministic, RaceEnabled, 7,4, false);
}

RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::~TA_initActivity(){
  delete[] TheDistributionParameters;
}

void RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::LinkVariables(){
  locality->Register(&locality_Mobius_Mark);
  profileID->Register(&profileID_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);
  s->Register(&s_Mobius_Mark);
  state->Register(&state_Mobius_Mark);
  time->Register(&time_Mobius_Mark);

}

bool RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((locality->Mark()>0) & (profileID->Mark()>0) & (SwitchID->Mark() > 0) & (s->Mark() == 1)));
  return NewEnabled;
}

double RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::DeterministicParamValue(){
  return 1;
  return 1.0;  // default rate if none is specified
}

double RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::Weight(){ 
  return 1;
}

bool RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::ReactivationPredicate(){ 
  return false;
}

bool RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::ReactivationFunction(){ 
  return false;
}

double RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::SampleDistribution(){
  return 1;
}

double* RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::Rank(){
  return 1;
}

BaseActionClass* RailRoadSwitchHeaterEvaluationModuleSAN::TA_initActivity::Fire(){
  s->Mark()=0;
  w[SwitchID->Mark() ]= Weather();
//profileID->Mark()=5;
//locality->Mark()=3;
w[SwitchID->Mark()].setProfileID(profileID->Mark());
w[SwitchID->Mark()].setLocality(locality->Mark());

if ((SwitchID->Mark()>0)&&(SwitchID->Mark()<=phigh))
	w[SwitchID->Mark()].setPriority(1);
else if ((SwitchID->Mark()>phigh)&&(SwitchID->Mark()<= (phigh+pmedium)))
	w[SwitchID->Mark()].setPriority(2);
else if ((SwitchID->Mark()>(phigh+pmedium))&&(SwitchID->Mark()<= (phigh+pmedium+plow)))
	w[SwitchID->Mark()].setPriority(3);

state->Mark()= 12;

time->Mark()=24;
w[SwitchID->Mark()].setCurrentTime(0);
w[SwitchID->Mark()].setInternalTemperature(gapThreshold+warningThreshold);
Temperature->Mark() =  w[SwitchID->Mark()].getInternalTemperature();
w[SwitchID->Mark()].resetTimeReady();
w[SwitchID->Mark()].resetTimeOn();
  return this;
}

/*======================TA_failureActivity========================*/

RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::TA_failureActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("TA_failure",2,Exponential, RaceEnabled, 5,2, false);
}

RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::~TA_failureActivity(){
  delete[] TheDistributionParameters;
}

void RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::LinkVariables(){

  state->Register(&state_Mobius_Mark);
  TimeReady->Register(&TimeReady_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);
  TimeOn->Register(&TimeOn_Mobius_Mark);
}

bool RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((
Temperature->Mark() <= freezingThreshold
)
&&
(state->Mark()>0)));
  return NewEnabled;
}

double RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::Rate(){
  return -Temperature->Mark();
  return 1.0;  // default rate if none is specified
}

double RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::Weight(){ 
  return 1;
}

bool RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::ReactivationPredicate(){ 
  return false;
}

bool RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::ReactivationFunction(){ 
  return false;
}

double RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::SampleDistribution(){
  return TheDistribution->Exponential(-Temperature->Mark());
}

double* RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::Rank(){
  return 1;
}

BaseActionClass* RailRoadSwitchHeaterEvaluationModuleSAN::TA_failureActivity::Fire(){
  ;
  TimeReady->Mark()=0;
w[SwitchID->Mark()].resetTimeReady();
TimeOn->Mark()=0;
w[SwitchID->Mark()].resetTimeOn();
if ((state->Mark()>=31)&&(state->Mark()<=33))
{
	state->Mark()=61;
}
else if((state->Mark()>=21)&&(state->Mark()<=22))
{
	state->Mark()=62;
}
else state->Mark()=63;
#ifndef DEBUG
cout<<"Failure Switch "<<SwitchID->Mark()<<" temperature "<<Temperature->Mark()<<" \n";
#endif
  return this;
}

