

// This C++ file was created by SanEditor

#include "Atomic/LocalitySelector/LocalitySelectorSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         LocalitySelectorSAN Constructor             
******************************************************************/


LocalitySelectorSAN::LocalitySelectorSAN(){


  selectLocalityGroup.initialize(3, "selectLocalityGroup");
  selectLocalityGroup.appendGroup((BaseGroupClass*) &selectLocality_case1);
  selectLocalityGroup.appendGroup((BaseGroupClass*) &selectLocality_case2);
  selectLocalityGroup.appendGroup((BaseGroupClass*) &selectLocality_case3);

  Activity* InitialActionList[3]={
    &selectLocality_case1, //0
    &selectLocality_case2, //1
    &selectLocality_case3  // 2
  };

  BaseGroupClass* InitialGroupList[1]={
    (BaseGroupClass*) &(selectLocalityGroup)
  };

  s2 = new Place("s2" ,1);
  locality = new Place("locality" ,0);
  BaseStateVariableClass* InitialPlaces[2]={
    s2,  // 0
    locality   // 1
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("LocalitySelector", 2, InitialPlaces, 
                        0, InitialROPlaces, 
                        3, InitialActionList, 1, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[6][2]={ 
    {0,0}, {1,0}, {0,1}, {1,1}, {0,2}, {1,2}
  };
  for(int n=0;n<6;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[3][2]={ 
    {0,0}, {0,1}, {0,2}
  };
  for(int n=0;n<3;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<3;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void LocalitySelectorSAN::CustomInitialization() {

}
LocalitySelectorSAN::~LocalitySelectorSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void LocalitySelectorSAN::assignPlacesToActivitiesInst(){
  selectLocality_case1.s2 = (Place*) LocalStateVariables[0];
  selectLocality_case1.locality = (Place*) LocalStateVariables[1];
  selectLocality_case2.s2 = (Place*) LocalStateVariables[0];
  selectLocality_case2.locality = (Place*) LocalStateVariables[1];
  selectLocality_case3.s2 = (Place*) LocalStateVariables[0];
  selectLocality_case3.locality = (Place*) LocalStateVariables[1];
}
void LocalitySelectorSAN::assignPlacesToActivitiesTimed(){
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================selectLocalityActivity_case1========================*/


LocalitySelectorSAN::selectLocalityActivity_case1::selectLocalityActivity_case1(){
  ActivityInitialize("selectLocality_case1",0,Instantaneous , RaceEnabled, 2,1, false);
}

void LocalitySelectorSAN::selectLocalityActivity_case1::LinkVariables(){
  s2->Register(&s2_Mobius_Mark);
  locality->Register(&locality_Mobius_Mark);
}

bool LocalitySelectorSAN::selectLocalityActivity_case1::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((s2->Mark()==1));
  return NewEnabled;
}

double LocalitySelectorSAN::selectLocalityActivity_case1::Weight(){ 
  return 0.3;
}

bool LocalitySelectorSAN::selectLocalityActivity_case1::ReactivationPredicate(){ 
  return false;
}

bool LocalitySelectorSAN::selectLocalityActivity_case1::ReactivationFunction(){ 
  return false;
}

double LocalitySelectorSAN::selectLocalityActivity_case1::SampleDistribution(){
  return 0;
}

double* LocalitySelectorSAN::selectLocalityActivity_case1::ReturnDistributionParameters(){
    return NULL;
}

int LocalitySelectorSAN::selectLocalityActivity_case1::Rank(){
  return 1;
}

BaseActionClass* LocalitySelectorSAN::selectLocalityActivity_case1::Fire(){
  s2->Mark()=0;
  locality->Mark()=1;
  return this;
}

/*======================selectLocalityActivity_case2========================*/


LocalitySelectorSAN::selectLocalityActivity_case2::selectLocalityActivity_case2(){
  ActivityInitialize("selectLocality_case2",0,Instantaneous , RaceEnabled, 2,1, false);
}

void LocalitySelectorSAN::selectLocalityActivity_case2::LinkVariables(){
  s2->Register(&s2_Mobius_Mark);
  locality->Register(&locality_Mobius_Mark);
}

bool LocalitySelectorSAN::selectLocalityActivity_case2::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((s2->Mark()==1));
  return NewEnabled;
}

double LocalitySelectorSAN::selectLocalityActivity_case2::Weight(){ 
  return 0.3;
}

bool LocalitySelectorSAN::selectLocalityActivity_case2::ReactivationPredicate(){ 
  return false;
}

bool LocalitySelectorSAN::selectLocalityActivity_case2::ReactivationFunction(){ 
  return false;
}

double LocalitySelectorSAN::selectLocalityActivity_case2::SampleDistribution(){
  return 0;
}

double* LocalitySelectorSAN::selectLocalityActivity_case2::ReturnDistributionParameters(){
    return NULL;
}

int LocalitySelectorSAN::selectLocalityActivity_case2::Rank(){
  return 1;
}

BaseActionClass* LocalitySelectorSAN::selectLocalityActivity_case2::Fire(){
  s2->Mark()=0;
  locality->Mark()=2;
  return this;
}

/*======================selectLocalityActivity_case3========================*/


LocalitySelectorSAN::selectLocalityActivity_case3::selectLocalityActivity_case3(){
  ActivityInitialize("selectLocality_case3",0,Instantaneous , RaceEnabled, 2,1, false);
}

void LocalitySelectorSAN::selectLocalityActivity_case3::LinkVariables(){
  s2->Register(&s2_Mobius_Mark);
  locality->Register(&locality_Mobius_Mark);
}

bool LocalitySelectorSAN::selectLocalityActivity_case3::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((s2->Mark()==1));
  return NewEnabled;
}

double LocalitySelectorSAN::selectLocalityActivity_case3::Weight(){ 
  return 0.4;
}

bool LocalitySelectorSAN::selectLocalityActivity_case3::ReactivationPredicate(){ 
  return false;
}

bool LocalitySelectorSAN::selectLocalityActivity_case3::ReactivationFunction(){ 
  return false;
}

double LocalitySelectorSAN::selectLocalityActivity_case3::SampleDistribution(){
  return 0;
}

double* LocalitySelectorSAN::selectLocalityActivity_case3::ReturnDistributionParameters(){
    return NULL;
}

int LocalitySelectorSAN::selectLocalityActivity_case3::Rank(){
  return 1;
}

BaseActionClass* LocalitySelectorSAN::selectLocalityActivity_case3::Fire(){
  s2->Mark()=0;
  locality->Mark()=3;
  return this;
}

