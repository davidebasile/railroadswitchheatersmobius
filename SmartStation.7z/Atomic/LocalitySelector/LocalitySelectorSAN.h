#ifndef LocalitySelectorSAN_H_
#define LocalitySelectorSAN_H_

#include "include/SmartStation.h"
#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               LocalitySelectorSAN Submodel Definition                   
*********************************************************************/

class LocalitySelectorSAN:public SANModel{
public:

class selectLocalityActivity_case1:public Activity {
public:

  Place* s2;
  short* s2_Mobius_Mark;
  Place* locality;
  short* locality_Mobius_Mark;

  double* TheDistributionParameters;
  selectLocalityActivity_case1();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // selectLocalityActivity_case1Activity

class selectLocalityActivity_case2:public Activity {
public:

  Place* s2;
  short* s2_Mobius_Mark;
  Place* locality;
  short* locality_Mobius_Mark;

  double* TheDistributionParameters;
  selectLocalityActivity_case2();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // selectLocalityActivity_case2Activity

class selectLocalityActivity_case3:public Activity {
public:

  Place* s2;
  short* s2_Mobius_Mark;
  Place* locality;
  short* locality_Mobius_Mark;

  double* TheDistributionParameters;
  selectLocalityActivity_case3();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // selectLocalityActivity_case3Activity

  //List of user-specified place names
  Place* s2;
  Place* locality;

  // Create instances of all actvities
  selectLocalityActivity_case1 selectLocality_case1;
  selectLocalityActivity_case2 selectLocality_case2;
  selectLocalityActivity_case3 selectLocality_case3;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup selectLocalityGroup;

  LocalitySelectorSAN();
  ~LocalitySelectorSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end LocalitySelectorSAN

#endif // LocalitySelectorSAN_H_
