

// This C++ file was created by SanEditor

#include "Atomic/ControllerCommunicationMod/ControllerCommunicationModSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         ControllerCommunicationModSAN Constructor             
******************************************************************/


ControllerCommunicationModSAN::ControllerCommunicationModSAN(){


  Activity* InitialActionList[2]={
    &sendIA, //0
    &receiveIA  // 1
  };

  BaseGroupClass* InitialGroupList[2]={
    (BaseGroupClass*) &(sendIA), 
    (BaseGroupClass*) &(receiveIA)
  };

  state = new Place("state" ,0);
  msg = new Place("msg" ,0);
  idRec = new Place("idRec" ,0);
  idSend = new Place("idSend" ,0);
  temp = new Place("temp" ,0);
  synch = new Place("synch" ,0);
  BaseStateVariableClass* InitialPlaces[6]={
    state,  // 0
    msg,  // 1
    idRec,  // 2
    idSend,  // 3
    temp,  // 4
    synch   // 5
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("ControllerCommunicationMod", 6, InitialPlaces, 
                        0, InitialROPlaces, 
                        2, InitialActionList, 2, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[10][2]={ 
    {0,0}, {1,0}, {2,0}, {4,0}, {3,0}, {0,1}, {1,1}, {4,1}, {3,1}, 
    {2,1}
  };
  for(int n=0;n<10;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[7][2]={ 
    {5,0}, {0,0}, {3,0}, {2,0}, {1,0}, {2,1}, {0,1}
  };
  for(int n=0;n<7;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<2;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void ControllerCommunicationModSAN::CustomInitialization() {

}
ControllerCommunicationModSAN::~ControllerCommunicationModSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void ControllerCommunicationModSAN::assignPlacesToActivitiesInst(){
  sendIA.synch = (Place*) LocalStateVariables[5];
  sendIA.state = (Place*) LocalStateVariables[0];
  sendIA.idSend = (Place*) LocalStateVariables[3];
  sendIA.idRec = (Place*) LocalStateVariables[2];
  sendIA.msg = (Place*) LocalStateVariables[1];
  sendIA.temp = (Place*) LocalStateVariables[4];
  receiveIA.idRec = (Place*) LocalStateVariables[2];
  receiveIA.state = (Place*) LocalStateVariables[0];
  receiveIA.msg = (Place*) LocalStateVariables[1];
  receiveIA.temp = (Place*) LocalStateVariables[4];
  receiveIA.idSend = (Place*) LocalStateVariables[3];
}
void ControllerCommunicationModSAN::assignPlacesToActivitiesTimed(){
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================sendIAActivity========================*/


ControllerCommunicationModSAN::sendIAActivity::sendIAActivity(){
  ActivityInitialize("sendIA",0,Instantaneous , RaceEnabled, 5,5, false);
}

void ControllerCommunicationModSAN::sendIAActivity::LinkVariables(){
  synch->Register(&synch_Mobius_Mark);
  state->Register(&state_Mobius_Mark);
  idSend->Register(&idSend_Mobius_Mark);
  idRec->Register(&idRec_Mobius_Mark);
  msg->Register(&msg_Mobius_Mark);
  temp->Register(&temp_Mobius_Mark);
}

bool ControllerCommunicationModSAN::sendIAActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((synch->Mark()==numSwitch
&&
(state->Mark()==2 || state->Mark()==3 || state->Mark()==4|| state->Mark()==5)
&&
( 
idSend->Mark()==0
&&
idRec->Mark()==0
&&
msg->Mark()==0
)
));
  return NewEnabled;
}

double ControllerCommunicationModSAN::sendIAActivity::Weight(){ 
  return 1;
}

bool ControllerCommunicationModSAN::sendIAActivity::ReactivationPredicate(){ 
  return false;
}

bool ControllerCommunicationModSAN::sendIAActivity::ReactivationFunction(){ 
  return false;
}

double ControllerCommunicationModSAN::sendIAActivity::SampleDistribution(){
  return 0;
}

double* ControllerCommunicationModSAN::sendIAActivity::ReturnDistributionParameters(){
    return NULL;
}

int ControllerCommunicationModSAN::sendIAActivity::Rank(){
  return 1;
}

BaseActionClass* ControllerCommunicationModSAN::sendIAActivity::Fire(){
  ;
  if (state->Mark() == 2)// q1
{
	state->Mark()= 3; // q2
	msg->Mark()= 4; // notifyOut
	idRec->Mark()= q.remove(w[temp->Mark()].getPriority()); 
	idSend->Mark()= numSwitch+1; //coordinator
}
else if (state->Mark() == 3)// q2
{
	state->Mark() = 1; // q0
	msg->Mark()= 2; // notifyIn
	idRec->Mark()= temp->Mark();
	idSend->Mark()= numSwitch+1;
}
else if (state->Mark() == 4)  // q3
{	
	state->Mark()=1; //q0
	msg->Mark()= 2; // notifyIn
	idSend->Mark()= numSwitch+1; 
	idRec->Mark()= q.insert();
}
else if (state->Mark() == 5)
{	
	state->Mark()=1; //q0
	msg->Mark()= 2; // notifyIn
	idRec->Mark()= temp->Mark();
	idSend->Mark()= numSwitch+1; 
}
  return this;
}

/*======================receiveIAActivity========================*/


ControllerCommunicationModSAN::receiveIAActivity::receiveIAActivity(){
  ActivityInitialize("receiveIA",1,Instantaneous , RaceEnabled, 5,2, false);
}

void ControllerCommunicationModSAN::receiveIAActivity::LinkVariables(){
  idRec->Register(&idRec_Mobius_Mark);
  state->Register(&state_Mobius_Mark);
  msg->Register(&msg_Mobius_Mark);
  temp->Register(&temp_Mobius_Mark);
  idSend->Register(&idSend_Mobius_Mark);
}

bool ControllerCommunicationModSAN::receiveIAActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((idRec->Mark()==numSwitch+1
&&
state->Mark()==1)));
  return NewEnabled;
}

double ControllerCommunicationModSAN::receiveIAActivity::Weight(){ 
  return 1;
}

bool ControllerCommunicationModSAN::receiveIAActivity::ReactivationPredicate(){ 
  return false;
}

bool ControllerCommunicationModSAN::receiveIAActivity::ReactivationFunction(){ 
  return false;
}

double ControllerCommunicationModSAN::receiveIAActivity::SampleDistribution(){
  return 0;
}

double* ControllerCommunicationModSAN::receiveIAActivity::ReturnDistributionParameters(){
    return NULL;
}

int ControllerCommunicationModSAN::receiveIAActivity::Rank(){
  return 1;
}

BaseActionClass* ControllerCommunicationModSAN::receiveIAActivity::Fire(){
  ;
  if(state->Mark()==1) //q1
{
	if (msg->Mark()==1) //ins
	{
		state->Mark()=6; //ins_nondet
		temp->Mark()=idSend->Mark();
		idSend->Mark()=0;
		msg->Mark()=0;
		idRec->Mark()=0;
	}
	else if (msg->Mark()==3)//rem
	{
		state->Mark()=7; //rec_nondet
		temp->Mark()=idSend->Mark();
		idSend->Mark()=0;
		msg->Mark()=0;
		idRec->Mark()=0;
	}
}
  return this;
}

