#ifndef ControllerEvaluationModSAN_H_
#define ControllerEvaluationModSAN_H_

#include "include/SmartStation.h"
#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short queueSize;
extern Short numSwitch;
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               ControllerEvaluationModSAN Submodel Definition                   
*********************************************************************/

class ControllerEvaluationModSAN:public SANModel{
public:

class IA_initActivity:public Activity {
public:

  Place* init;
  short* init_Mobius_Mark;
  Place* state;
  short* state_Mobius_Mark;

  double* TheDistributionParameters;
  IA_initActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // IA_initActivityActivity

class IAActivity:public Activity {
public:

  Place* state;
  short* state_Mobius_Mark;
  Place* synch;
  short* synch_Mobius_Mark;
  Place* queue;
  short* queue_Mobius_Mark;
  Place* temp;
  short* temp_Mobius_Mark;

  double* TheDistributionParameters;
  IAActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // IAActivityActivity

  //List of user-specified place names
  Place* queue;
  Place* init;
  Place* synch;
  Place* state;
  Place* temp;

  // Create instances of all actvities
  IA_initActivity IA_init;
  IAActivity IA;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup IA_initGroup;
  PostselectGroup IAGroup;

  ControllerEvaluationModSAN();
  ~ControllerEvaluationModSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end ControllerEvaluationModSAN

#endif // ControllerEvaluationModSAN_H_
