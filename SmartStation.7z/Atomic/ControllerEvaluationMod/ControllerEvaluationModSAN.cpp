

// This C++ file was created by SanEditor

#include "Atomic/ControllerEvaluationMod/ControllerEvaluationModSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         ControllerEvaluationModSAN Constructor             
******************************************************************/


ControllerEvaluationModSAN::ControllerEvaluationModSAN(){


  Activity* InitialActionList[2]={
    &IA_init, //0
    &IA  // 1
  };

  BaseGroupClass* InitialGroupList[2]={
    (BaseGroupClass*) &(IA_init), 
    (BaseGroupClass*) &(IA)
  };

  queue = new Place("queue" ,0);
  init = new Place("init" ,1);
  synch = new Place("synch" ,0);
  state = new Place("state" ,0);
  temp = new Place("temp" ,0);
  BaseStateVariableClass* InitialPlaces[5]={
    queue,  // 0
    init,  // 1
    synch,  // 2
    state,  // 3
    temp   // 4
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("ControllerEvaluationMod", 5, InitialPlaces, 
                        0, InitialROPlaces, 
                        2, InitialActionList, 2, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[5][2]={ 
    {1,0}, {3,0}, {0,1}, {3,1}, {4,1}
  };
  for(int n=0;n<5;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[3][2]={ 
    {1,0}, {3,1}, {2,1}
  };
  for(int n=0;n<3;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<2;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void ControllerEvaluationModSAN::CustomInitialization() {

}
ControllerEvaluationModSAN::~ControllerEvaluationModSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void ControllerEvaluationModSAN::assignPlacesToActivitiesInst(){
  IA_init.init = (Place*) LocalStateVariables[1];
  IA_init.state = (Place*) LocalStateVariables[3];
  IA.state = (Place*) LocalStateVariables[3];
  IA.synch = (Place*) LocalStateVariables[2];
  IA.queue = (Place*) LocalStateVariables[0];
  IA.temp = (Place*) LocalStateVariables[4];
}
void ControllerEvaluationModSAN::assignPlacesToActivitiesTimed(){
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================IA_initActivity========================*/


ControllerEvaluationModSAN::IA_initActivity::IA_initActivity(){
  ActivityInitialize("IA_init",0,Instantaneous , RaceEnabled, 2,1, false);
}

void ControllerEvaluationModSAN::IA_initActivity::LinkVariables(){
  init->Register(&init_Mobius_Mark);
  state->Register(&state_Mobius_Mark);
}

bool ControllerEvaluationModSAN::IA_initActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((init->Mark()==1));
  return NewEnabled;
}

double ControllerEvaluationModSAN::IA_initActivity::Weight(){ 
  return 1;
}

bool ControllerEvaluationModSAN::IA_initActivity::ReactivationPredicate(){ 
  return false;
}

bool ControllerEvaluationModSAN::IA_initActivity::ReactivationFunction(){ 
  return false;
}

double ControllerEvaluationModSAN::IA_initActivity::SampleDistribution(){
  return 0;
}

double* ControllerEvaluationModSAN::IA_initActivity::ReturnDistributionParameters(){
    return NULL;
}

int ControllerEvaluationModSAN::IA_initActivity::Rank(){
  return 1;
}

BaseActionClass* ControllerEvaluationModSAN::IA_initActivity::Fire(){
  init->Mark()=0;
state->Mark()=1;
q = Queue(numSwitch,3);
  return this;
}

/*======================IAActivity========================*/


ControllerEvaluationModSAN::IAActivity::IAActivity(){
  ActivityInitialize("IA",1,Instantaneous , RaceEnabled, 3,2, false);
}

void ControllerEvaluationModSAN::IAActivity::LinkVariables(){
  state->Register(&state_Mobius_Mark);
  synch->Register(&synch_Mobius_Mark);
  queue->Register(&queue_Mobius_Mark);
  temp->Register(&temp_Mobius_Mark);
}

bool ControllerEvaluationModSAN::IAActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((state->Mark()==6)||(state->Mark()==7)
&&
(synch->Mark()==numSwitch)));
  return NewEnabled;
}

double ControllerEvaluationModSAN::IAActivity::Weight(){ 
  return 1;
}

bool ControllerEvaluationModSAN::IAActivity::ReactivationPredicate(){ 
  return false;
}

bool ControllerEvaluationModSAN::IAActivity::ReactivationFunction(){ 
  return false;
}

double ControllerEvaluationModSAN::IAActivity::SampleDistribution(){
  return 0;
}

double* ControllerEvaluationModSAN::IAActivity::ReturnDistributionParameters(){
    return NULL;
}

int ControllerEvaluationModSAN::IAActivity::Rank(){
  return 1;
}

BaseActionClass* ControllerEvaluationModSAN::IAActivity::Fire(){
  ;
  int tot=queue->Mark();
if (state->Mark()==6)  //ins nondet
{
	if (tot<queueSize)
	{
		queue->Mark()++;
		#ifndef DEBUG
			cout<<"Insert Switch "<<temp->Mark()<<" \n";
		#endif
		state->Mark()=5;
	}
	else if (tot==queueSize)
	{		
		int rr = q.remove(w[temp->Mark()].getPriority());
		if (rr!=0)
		{
			#ifndef DEBUG
				cout<<"Notify out Switch "<<rr<<" \n";
				cout<<"Notify in Switch "<<temp->Mark()<<" \n";
			#endif
			state->Mark()=2;
		}
		else
			state->Mark()=8; //back to initial state
	}
}
else if ((state->Mark()==7)&&(tot>0))  //remove
{
	#ifndef DEBUG
	cout<<"Removed Switch "<<temp->Mark()<<" \n";
	#endif
	int swid=q.insert();
	if (swid!=0)
	{
		#ifndef DEBUG
			cout<<"Notify in Switch "<<swid<<" \n";
		#endif
		state->Mark()=4;
	}
	else
	{
		queue->Mark()--; //it can be that all switches are on
		state->Mark()=8;
	}
}
else if ((state->Mark()==7)&&(tot=0))//it can be that all switches are off
{
	state->Mark()=1; //back to initial state, reset places
}
  return this;
}

