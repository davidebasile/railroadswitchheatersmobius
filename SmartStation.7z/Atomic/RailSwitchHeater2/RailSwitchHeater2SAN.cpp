

// This C++ file was created by SanEditor

#include "Atomic/RailSwitchHeater2/RailSwitchHeater2SAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         RailSwitchHeater2SAN Constructor             
******************************************************************/


RailSwitchHeater2SAN::RailSwitchHeater2SAN(){


  Activity* InitialActionList[6]={
    &IA_on2off, //0
    &IA_off2ready, //1
    &IA_ready2on, //2
    &Clock, //3
    &TA_init, //4
    &TA_failure  // 5
  };

  BaseGroupClass* InitialGroupList[6]={
    (BaseGroupClass*) &(Clock), 
    (BaseGroupClass*) &(TA_init), 
    (BaseGroupClass*) &(TA_failure), 
    (BaseGroupClass*) &(IA_on2off), 
    (BaseGroupClass*) &(IA_off2ready), 
    (BaseGroupClass*) &(IA_ready2on)
  };

  action = new Place("action" ,0);
  off = new Place("off" ,0);
  failure = new Place("failure" ,0);
  time = new Place("time" ,0);
  on = new Place("on" ,0);
  locality = new Place("locality" ,0);
  profileID = new Place("profileID" ,0);
  SwitchID = new Place("SwitchID" ,0);
  s = new Place("s" ,1);
  ready = new Place("ready" ,0);
  TimeReady = new Place("TimeReady" ,0);
  TimeOn = new Place("TimeOn" ,0);
  notifyIn = new Place("notifyIn" ,0);
  notifyOut = new Place("notifyOut" ,0);
  id = new Place("id" ,0);
  synch = new Place("synch" ,0);
  double temp_Temperaturedouble = 0;
  Temperature = new ExtendedPlace<double>("Temperature",temp_Temperaturedouble);
  BaseStateVariableClass* InitialPlaces[17]={
    action,  // 0
    off,  // 1
    failure,  // 2
    time,  // 3
    on,  // 4
    locality,  // 5
    profileID,  // 6
    SwitchID,  // 7
    s,  // 8
    ready,  // 9
    TimeReady,  // 10
    TimeOn,  // 11
    notifyIn,  // 12
    notifyOut,  // 13
    id,  // 14
    synch,  // 15
    Temperature   // 16
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("RailSwitchHeater2", 17, InitialPlaces, 
                        0, InitialROPlaces, 
                        6, InitialActionList, 6, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[50][2]={ 
    {4,0}, {13,0}, {7,0}, {0,0}, {14,0}, {1,0}, {11,0}, {1,1}, 
    {0,1}, {9,1}, {7,1}, {10,1}, {14,1}, {9,2}, {12,2}, {4,2}, 
    {10,2}, {7,2}, {11,2}, {6,2}, {15,3}, {3,3}, {7,3}, {16,3}, 
    {9,3}, {10,3}, {4,3}, {11,3}, {2,3}, {1,3}, {6,3}, {8,4}, 
    {7,4}, {6,4}, {5,4}, {1,4}, {3,4}, {16,4}, {1,5}, {9,5}, 
    {10,5}, {7,5}, {12,5}, {14,5}, {0,5}, {4,5}, {11,5}, {13,5}, 
    {2,5}, {16,5}
  };
  for(int n=0;n<50;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[27][2]={ 
    {4,0}, {0,0}, {16,0}, {13,0}, {7,0}, {15,0}, {1,1}, {16,1}, 
    {0,1}, {15,1}, {9,2}, {12,2}, {7,2}, {3,3}, {1,3}, {9,3}, 
    {4,3}, {2,3}, {5,4}, {6,4}, {7,4}, {8,4}, {1,5}, {9,5}, {4,5}, 
    {7,5}, {0,5}
  };
  for(int n=0;n<27;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<6;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void RailSwitchHeater2SAN::CustomInitialization() {

}
RailSwitchHeater2SAN::~RailSwitchHeater2SAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void RailSwitchHeater2SAN::assignPlacesToActivitiesInst(){
  IA_on2off.on = (Place*) LocalStateVariables[4];
  IA_on2off.action = (Place*) LocalStateVariables[0];
  IA_on2off.Temperature = (ExtendedPlace<double>*) LocalStateVariables[16];
  IA_on2off.notifyOut = (Place*) LocalStateVariables[13];
  IA_on2off.SwitchID = (Place*) LocalStateVariables[7];
  IA_on2off.synch = (Place*) LocalStateVariables[15];
  IA_on2off.id = (Place*) LocalStateVariables[14];
  IA_on2off.off = (Place*) LocalStateVariables[1];
  IA_on2off.TimeOn = (Place*) LocalStateVariables[11];
  IA_off2ready.off = (Place*) LocalStateVariables[1];
  IA_off2ready.Temperature = (ExtendedPlace<double>*) LocalStateVariables[16];
  IA_off2ready.action = (Place*) LocalStateVariables[0];
  IA_off2ready.synch = (Place*) LocalStateVariables[15];
  IA_off2ready.ready = (Place*) LocalStateVariables[9];
  IA_off2ready.SwitchID = (Place*) LocalStateVariables[7];
  IA_off2ready.TimeReady = (Place*) LocalStateVariables[10];
  IA_off2ready.id = (Place*) LocalStateVariables[14];
  IA_ready2on.ready = (Place*) LocalStateVariables[9];
  IA_ready2on.notifyIn = (Place*) LocalStateVariables[12];
  IA_ready2on.SwitchID = (Place*) LocalStateVariables[7];
  IA_ready2on.on = (Place*) LocalStateVariables[4];
  IA_ready2on.TimeReady = (Place*) LocalStateVariables[10];
  IA_ready2on.TimeOn = (Place*) LocalStateVariables[11];
  IA_ready2on.profileID = (Place*) LocalStateVariables[6];
}
void RailSwitchHeater2SAN::assignPlacesToActivitiesTimed(){
  Clock.time = (Place*) LocalStateVariables[3];
  Clock.off = (Place*) LocalStateVariables[1];
  Clock.ready = (Place*) LocalStateVariables[9];
  Clock.on = (Place*) LocalStateVariables[4];
  Clock.failure = (Place*) LocalStateVariables[2];
  Clock.synch = (Place*) LocalStateVariables[15];
  Clock.SwitchID = (Place*) LocalStateVariables[7];
  Clock.Temperature = (ExtendedPlace<double>*) LocalStateVariables[16];
  Clock.TimeReady = (Place*) LocalStateVariables[10];
  Clock.TimeOn = (Place*) LocalStateVariables[11];
  Clock.profileID = (Place*) LocalStateVariables[6];
  TA_init.locality = (Place*) LocalStateVariables[5];
  TA_init.profileID = (Place*) LocalStateVariables[6];
  TA_init.SwitchID = (Place*) LocalStateVariables[7];
  TA_init.s = (Place*) LocalStateVariables[8];
  TA_init.off = (Place*) LocalStateVariables[1];
  TA_init.time = (Place*) LocalStateVariables[3];
  TA_init.Temperature = (ExtendedPlace<double>*) LocalStateVariables[16];
  TA_failure.off = (Place*) LocalStateVariables[1];
  TA_failure.ready = (Place*) LocalStateVariables[9];
  TA_failure.on = (Place*) LocalStateVariables[4];
  TA_failure.SwitchID = (Place*) LocalStateVariables[7];
  TA_failure.action = (Place*) LocalStateVariables[0];
  TA_failure.TimeReady = (Place*) LocalStateVariables[10];
  TA_failure.notifyIn = (Place*) LocalStateVariables[12];
  TA_failure.id = (Place*) LocalStateVariables[14];
  TA_failure.TimeOn = (Place*) LocalStateVariables[11];
  TA_failure.notifyOut = (Place*) LocalStateVariables[13];
  TA_failure.failure = (Place*) LocalStateVariables[2];
  TA_failure.Temperature = (ExtendedPlace<double>*) LocalStateVariables[16];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================IA_on2offActivity========================*/


RailSwitchHeater2SAN::IA_on2offActivity::IA_on2offActivity(){
  ActivityInitialize("IA_on2off",3,Instantaneous , RaceEnabled, 7,6, false);
}

void RailSwitchHeater2SAN::IA_on2offActivity::LinkVariables(){
  on->Register(&on_Mobius_Mark);
  action->Register(&action_Mobius_Mark);

  notifyOut->Register(&notifyOut_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);
  synch->Register(&synch_Mobius_Mark);
  id->Register(&id_Mobius_Mark);
  off->Register(&off_Mobius_Mark);
  TimeOn->Register(&TimeOn_Mobius_Mark);
}

bool RailSwitchHeater2SAN::IA_on2offActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((on->Mark()==1 &&
(
(action->Mark()==0 && Temperature->Mark() > (warningThreshold+gapThreshold) )
|| 
notifyOut->Mark()==SwitchID->Mark()
)
&&
synch->Mark()==numSwitch));
  return NewEnabled;
}

double RailSwitchHeater2SAN::IA_on2offActivity::Weight(){ 
  return 1;
}

bool RailSwitchHeater2SAN::IA_on2offActivity::ReactivationPredicate(){ 
  return false;
}

bool RailSwitchHeater2SAN::IA_on2offActivity::ReactivationFunction(){ 
  return false;
}

double RailSwitchHeater2SAN::IA_on2offActivity::SampleDistribution(){
  return 0;
}

double* RailSwitchHeater2SAN::IA_on2offActivity::ReturnDistributionParameters(){
    return NULL;
}

int RailSwitchHeater2SAN::IA_on2offActivity::Rank(){
  return 1;
}

BaseActionClass* RailSwitchHeater2SAN::IA_on2offActivity::Fire(){
  on->Mark()=0;
if (notifyOut->Mark()==SwitchID->Mark())
	notifyOut->Mark()=0;
else
{
	action->Mark()=2;//remove
	id->Mark()=SwitchID->Mark();
}
  off->Mark()=1;
TimeOn->Mark()=0;
w[SwitchID->Mark()].resetTimeOn();
#ifndef DEBUGG
	cout<< "ON 2 OFF internal temperature : " << w[SwitchID->Mark()].getInternalTemperature() << " \n";
#endif
#ifndef DEBUG
cout<<"Off Switch "<<SwitchID->Mark()<<" \n";
#endif
  return this;
}

/*======================IA_off2readyActivity========================*/


RailSwitchHeater2SAN::IA_off2readyActivity::IA_off2readyActivity(){
  ActivityInitialize("IA_off2ready",4,Instantaneous , RaceEnabled, 6,4, false);
}

void RailSwitchHeater2SAN::IA_off2readyActivity::LinkVariables(){
  off->Register(&off_Mobius_Mark);

  action->Register(&action_Mobius_Mark);
  synch->Register(&synch_Mobius_Mark);
  ready->Register(&ready_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);
  TimeReady->Register(&TimeReady_Mobius_Mark);
  id->Register(&id_Mobius_Mark);
}

bool RailSwitchHeater2SAN::IA_off2readyActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((off->Mark()>0 
&& 
Temperature->Mark()<warningThreshold 
&&
action->Mark()==0
&&
synch->Mark()==numSwitch));
  return NewEnabled;
}

double RailSwitchHeater2SAN::IA_off2readyActivity::Weight(){ 
  return 1;
}

bool RailSwitchHeater2SAN::IA_off2readyActivity::ReactivationPredicate(){ 
  return false;
}

bool RailSwitchHeater2SAN::IA_off2readyActivity::ReactivationFunction(){ 
  return false;
}

double RailSwitchHeater2SAN::IA_off2readyActivity::SampleDistribution(){
  return 0;
}

double* RailSwitchHeater2SAN::IA_off2readyActivity::ReturnDistributionParameters(){
    return NULL;
}

int RailSwitchHeater2SAN::IA_off2readyActivity::Rank(){
  return 1;
}

BaseActionClass* RailSwitchHeater2SAN::IA_off2readyActivity::Fire(){
  off->Mark()=0;
action->Mark()=1;//insert
  ready->Mark()=1;
w[SwitchID->Mark()].increaseTimeReady();
TimeReady->Mark()++;
id->Mark() = SwitchID->Mark();
#ifndef DEBUG
cout<<"Ready Switch "<<SwitchID->Mark()<<" \n";
#endif
  return this;
}

/*======================IA_ready2onActivity========================*/


RailSwitchHeater2SAN::IA_ready2onActivity::IA_ready2onActivity(){
  ActivityInitialize("IA_ready2on",5,Instantaneous , RaceEnabled, 7,3, false);
}

void RailSwitchHeater2SAN::IA_ready2onActivity::LinkVariables(){
  ready->Register(&ready_Mobius_Mark);
  notifyIn->Register(&notifyIn_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);
  on->Register(&on_Mobius_Mark);
  TimeReady->Register(&TimeReady_Mobius_Mark);
  TimeOn->Register(&TimeOn_Mobius_Mark);
  profileID->Register(&profileID_Mobius_Mark);
}

bool RailSwitchHeater2SAN::IA_ready2onActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((ready->Mark()==1 &
notifyIn->Mark() == SwitchID->Mark()
));
  return NewEnabled;
}

double RailSwitchHeater2SAN::IA_ready2onActivity::Weight(){ 
  return 1;
}

bool RailSwitchHeater2SAN::IA_ready2onActivity::ReactivationPredicate(){ 
  return false;
}

bool RailSwitchHeater2SAN::IA_ready2onActivity::ReactivationFunction(){ 
  return false;
}

double RailSwitchHeater2SAN::IA_ready2onActivity::SampleDistribution(){
  return 0;
}

double* RailSwitchHeater2SAN::IA_ready2onActivity::ReturnDistributionParameters(){
    return NULL;
}

int RailSwitchHeater2SAN::IA_ready2onActivity::Rank(){
  return 1;
}

BaseActionClass* RailSwitchHeater2SAN::IA_ready2onActivity::Fire(){
  ready->Mark()=0;
notifyIn->Mark()=0;
  on->Mark()=1;
TimeReady->Mark()=0;
w[SwitchID->Mark()].resetTimeReady();
w[SwitchID->Mark()].increaseTimeOn();
TimeOn->Mark()++;
#ifndef DEBUGG
	cout << "Turning ON  SwitchID " << SwitchID->Mark()<< " profileID " << profileID->Mark() << " \n";
#endif
#ifndef DEBUG
cout<<"On Switch "<<SwitchID->Mark()<<" \n";
#endif
  return this;
}

/*======================ClockActivity========================*/

RailSwitchHeater2SAN::ClockActivity::ClockActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("Clock",0,Deterministic, RaceEnabled, 11,5, false);
}

RailSwitchHeater2SAN::ClockActivity::~ClockActivity(){
  delete[] TheDistributionParameters;
}

void RailSwitchHeater2SAN::ClockActivity::LinkVariables(){
  time->Register(&time_Mobius_Mark);
  off->Register(&off_Mobius_Mark);
  ready->Register(&ready_Mobius_Mark);
  on->Register(&on_Mobius_Mark);
  failure->Register(&failure_Mobius_Mark);
  synch->Register(&synch_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);

  TimeReady->Register(&TimeReady_Mobius_Mark);
  TimeOn->Register(&TimeOn_Mobius_Mark);
  profileID->Register(&profileID_Mobius_Mark);
}

bool RailSwitchHeater2SAN::ClockActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((time->Mark()>=0
&& 
(
off->Mark()>0
||
ready->Mark()>0
||
on->Mark()>0
||
failure->Mark()>0
)));
  return NewEnabled;
}

double RailSwitchHeater2SAN::ClockActivity::DeterministicParamValue(){
  return TimeClock;
  return 1.0;  // default rate if none is specified
}

double RailSwitchHeater2SAN::ClockActivity::Weight(){ 
  return 1;
}

bool RailSwitchHeater2SAN::ClockActivity::ReactivationPredicate(){ 
  return false;
}

bool RailSwitchHeater2SAN::ClockActivity::ReactivationFunction(){ 
  return false;
}

double RailSwitchHeater2SAN::ClockActivity::SampleDistribution(){
  return TimeClock;
}

double* RailSwitchHeater2SAN::ClockActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int RailSwitchHeater2SAN::ClockActivity::Rank(){
  return 1;
}

BaseActionClass* RailSwitchHeater2SAN::ClockActivity::Fire(){
  ;
  if (synch->Mark() == numSwitch)
	synch->Mark()=0;




//UPDATE TIME
int t = abs(time->Mark() - 24);
//cout<< " time mark " << time->Mark() << " \n";
//cout<< " abs(time->Mark() - 13)=" << t << "\n";
if (t==24)
{
	time->Mark()  = 24;
	t=0;
#ifndef DEBUGG
	cout<< " time mark " << time->Mark() << " and t " << t << " \n";
#endif
}
else
	time->Mark()--;
#ifndef DEBUG
	cout<< "SwitchID " <<SwitchID->Mark()<<" current time " << t<< " Temperature "<< Temperature->Mark() <<" \n";
#endif
w[SwitchID->Mark()].setCurrentTime((short) t);



//UPDATE TIME ON TIME READY
if(ready->Mark()==1)
{
	w[SwitchID->Mark()].increaseTimeReady();	
	TimeReady->Mark()++;
	#ifndef DEBUG
	cout<<"SwitchID "<<SwitchID->Mark()<<" time ready "<<TimeReady->Mark()<<" "<<w[SwitchID->Mark()].getTimeReady()<<" \n";
	#endif
}
else if(on->Mark()==1)
{
	w[SwitchID->Mark()].increaseTimeOn();	
	TimeOn->Mark()++;
	#ifndef DEBUG
	cout<<"SwitchID "<<SwitchID->Mark()<<" time on "<<TimeOn->Mark()<<" \n";
	#endif
}
#ifndef DEBUGG
		cout << " ( profileID : " <<  w[SwitchID->Mark()].getProfileID() << " , ";
		//cout << " time : " << w[SwitchID->Mark()].getCurrentTime()<< " , ";
		//cout << " off : " << off->Mark() << " , ";
		//cout << " ready : " << ready ->Mark() << " , ";
		//cout << " on : " << on->Mark() << " , ";
		cout << " failure : " << failure->Mark() << " , ";
		//cout << " locality : "  << w[SwitchID->Mark()].getLocality()  << " , ";
		//cout << " warningThreshold : " << warningThreshold << " , ";
		//cout << " workingTemperature : " << workingTemperature << " , ";
		//cout << "Freezing threshold " << freezingThreshold << " , ";
		cout << "SwitchID " << SwitchID->Mark() << ")\n";
#endif




//UPDATE TEMPERATURE
if (on->Mark()==0)
	w[SwitchID->Mark()].decreaseInternalTemperature();
else if ((off->Mark()==0)||(ready->Mark()==0))
	w[SwitchID->Mark()].increaseInternalTemperature();
Temperature->Mark() =  w[SwitchID->Mark()].getInternalTemperature();

synch->Mark()++;
  return this;
}

/*======================TA_initActivity========================*/

RailSwitchHeater2SAN::TA_initActivity::TA_initActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("TA_init",1,Deterministic, RaceEnabled, 7,4, false);
}

RailSwitchHeater2SAN::TA_initActivity::~TA_initActivity(){
  delete[] TheDistributionParameters;
}

void RailSwitchHeater2SAN::TA_initActivity::LinkVariables(){
  locality->Register(&locality_Mobius_Mark);
  profileID->Register(&profileID_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);
  s->Register(&s_Mobius_Mark);
  off->Register(&off_Mobius_Mark);
  time->Register(&time_Mobius_Mark);

}

bool RailSwitchHeater2SAN::TA_initActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((locality->Mark()>0) & (profileID->Mark()>0) & (SwitchID->Mark() > 0) & (s->Mark() == 1)));
  return NewEnabled;
}

double RailSwitchHeater2SAN::TA_initActivity::DeterministicParamValue(){
  return 1;
  return 1.0;  // default rate if none is specified
}

double RailSwitchHeater2SAN::TA_initActivity::Weight(){ 
  return 1;
}

bool RailSwitchHeater2SAN::TA_initActivity::ReactivationPredicate(){ 
  return false;
}

bool RailSwitchHeater2SAN::TA_initActivity::ReactivationFunction(){ 
  return false;
}

double RailSwitchHeater2SAN::TA_initActivity::SampleDistribution(){
  return 1;
}

double* RailSwitchHeater2SAN::TA_initActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int RailSwitchHeater2SAN::TA_initActivity::Rank(){
  return 1;
}

BaseActionClass* RailSwitchHeater2SAN::TA_initActivity::Fire(){
  s->Mark()=0;
  w[SwitchID->Mark() ]= Weather();
//profileID->Mark()=5;
//locality->Mark()=3;
w[SwitchID->Mark()].setProfileID(profileID->Mark());
w[SwitchID->Mark()].setLocality(locality->Mark());

if ((SwitchID->Mark()>0)&&(SwitchID->Mark()<=phigh))
	w[SwitchID->Mark()].setPriority(1);
else if ((SwitchID->Mark()>phigh)&&(SwitchID->Mark()<= (phigh+pmedium)))
	w[SwitchID->Mark()].setPriority(2);
else if ((SwitchID->Mark()>(phigh+pmedium))&&(SwitchID->Mark()<= (phigh+pmedium+plow)))
	w[SwitchID->Mark()].setPriority(3);

off->Mark()= 1;

time->Mark()=24;
w[SwitchID->Mark()].setCurrentTime(0);
w[SwitchID->Mark()].setInternalTemperature(gapThreshold+warningThreshold);
Temperature->Mark() =  w[SwitchID->Mark()].getInternalTemperature();
w[SwitchID->Mark()].resetTimeReady();
w[SwitchID->Mark()].resetTimeOn();
  return this;
}

/*======================TA_failureActivity========================*/

RailSwitchHeater2SAN::TA_failureActivity::TA_failureActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("TA_failure",2,Exponential, RaceEnabled, 12,5, false);
}

RailSwitchHeater2SAN::TA_failureActivity::~TA_failureActivity(){
  delete[] TheDistributionParameters;
}

void RailSwitchHeater2SAN::TA_failureActivity::LinkVariables(){
  off->Register(&off_Mobius_Mark);
  ready->Register(&ready_Mobius_Mark);
  on->Register(&on_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);
  action->Register(&action_Mobius_Mark);
  TimeReady->Register(&TimeReady_Mobius_Mark);
  notifyIn->Register(&notifyIn_Mobius_Mark);
  id->Register(&id_Mobius_Mark);
  TimeOn->Register(&TimeOn_Mobius_Mark);
  notifyOut->Register(&notifyOut_Mobius_Mark);
  failure->Register(&failure_Mobius_Mark);

}

bool RailSwitchHeater2SAN::TA_failureActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((off->Mark()>0 || ready->Mark()>0 || on->Mark()>0) &&
(
  w[SwitchID->Mark()].getInternalTemperature()<=freezingThreshold 
 )
&& (action->Mark()==0)));
  return NewEnabled;
}

double RailSwitchHeater2SAN::TA_failureActivity::Rate(){
  return -Temperature->Mark();
  return 1.0;  // default rate if none is specified
}

double RailSwitchHeater2SAN::TA_failureActivity::Weight(){ 
  return 1;
}

bool RailSwitchHeater2SAN::TA_failureActivity::ReactivationPredicate(){ 
  return false;
}

bool RailSwitchHeater2SAN::TA_failureActivity::ReactivationFunction(){ 
  return false;
}

double RailSwitchHeater2SAN::TA_failureActivity::SampleDistribution(){
  return TheDistribution->Exponential(-Temperature->Mark());
}

double* RailSwitchHeater2SAN::TA_failureActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int RailSwitchHeater2SAN::TA_failureActivity::Rank(){
  return 1;
}

BaseActionClass* RailSwitchHeater2SAN::TA_failureActivity::Fire(){
  if (off->Mark()>0)
	off->Mark()=0;
else if(ready->Mark()>0)
{
	ready->Mark()=0;
	TimeReady->Mark()=0;
	w[SwitchID->Mark()].resetTimeReady();
	if (notifyIn->Mark()==SwitchID->Mark())
	{
		notifyIn->Mark()=0; //if was kicked in then remove from the queue
		id->Mark()=SwitchID->Mark();
		action->Mark()=2;
	}
}
else if (on->Mark()>0)
{
	on->Mark()=0;
	TimeOn->Mark()=0;
	w[SwitchID->Mark()].resetTimeOn();
	if (notifyOut->Mark()==SwitchID->Mark())
		notifyOut->Mark()=0;
	else{  //if wasn't kicked out then remove
		id->Mark()=SwitchID->Mark();
		action->Mark()=2;
	}
}
  failure->Mark()++;
#ifndef DEBUG
cout<<"Failure Switch "<<SwitchID->Mark()<<" temperature "<<Temperature->Mark()<<" \n";
#endif
  return this;
}

