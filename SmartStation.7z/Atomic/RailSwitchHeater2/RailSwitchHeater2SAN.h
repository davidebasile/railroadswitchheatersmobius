#ifndef RailSwitchHeater2SAN_H_
#define RailSwitchHeater2SAN_H_

#include "include/SmartStation.h"
#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short TimeClock;
extern Float warningThreshold;
extern Float freezingThreshold;
extern Short numSwitch;
extern Short queueSize;
extern Short phigh;
extern Short pmedium;
extern Short plow;
extern Short gapThreshold;
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               RailSwitchHeater2SAN Submodel Definition                   
*********************************************************************/

class RailSwitchHeater2SAN:public SANModel{
public:

class IA_on2offActivity:public Activity {
public:

  Place* on;
  short* on_Mobius_Mark;
  Place* action;
  short* action_Mobius_Mark;
  ExtendedPlace<double>* Temperature;
  Place* notifyOut;
  short* notifyOut_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  Place* synch;
  short* synch_Mobius_Mark;
  Place* id;
  short* id_Mobius_Mark;
  Place* off;
  short* off_Mobius_Mark;
  Place* TimeOn;
  short* TimeOn_Mobius_Mark;

  double* TheDistributionParameters;
  IA_on2offActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // IA_on2offActivityActivity

class IA_off2readyActivity:public Activity {
public:

  Place* off;
  short* off_Mobius_Mark;
  ExtendedPlace<double>* Temperature;
  Place* action;
  short* action_Mobius_Mark;
  Place* synch;
  short* synch_Mobius_Mark;
  Place* ready;
  short* ready_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  Place* TimeReady;
  short* TimeReady_Mobius_Mark;
  Place* id;
  short* id_Mobius_Mark;

  double* TheDistributionParameters;
  IA_off2readyActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // IA_off2readyActivityActivity

class IA_ready2onActivity:public Activity {
public:

  Place* ready;
  short* ready_Mobius_Mark;
  Place* notifyIn;
  short* notifyIn_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  Place* on;
  short* on_Mobius_Mark;
  Place* TimeReady;
  short* TimeReady_Mobius_Mark;
  Place* TimeOn;
  short* TimeOn_Mobius_Mark;
  Place* profileID;
  short* profileID_Mobius_Mark;

  double* TheDistributionParameters;
  IA_ready2onActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // IA_ready2onActivityActivity

class ClockActivity:public Activity {
public:

  Place* time;
  short* time_Mobius_Mark;
  Place* off;
  short* off_Mobius_Mark;
  Place* ready;
  short* ready_Mobius_Mark;
  Place* on;
  short* on_Mobius_Mark;
  Place* failure;
  short* failure_Mobius_Mark;
  Place* synch;
  short* synch_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  ExtendedPlace<double>* Temperature;
  Place* TimeReady;
  short* TimeReady_Mobius_Mark;
  Place* TimeOn;
  short* TimeOn_Mobius_Mark;
  Place* profileID;
  short* profileID_Mobius_Mark;

  double* TheDistributionParameters;
  ClockActivity();
  ~ClockActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // ClockActivityActivity

class TA_initActivity:public Activity {
public:

  Place* locality;
  short* locality_Mobius_Mark;
  Place* profileID;
  short* profileID_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  Place* s;
  short* s_Mobius_Mark;
  Place* off;
  short* off_Mobius_Mark;
  Place* time;
  short* time_Mobius_Mark;
  ExtendedPlace<double>* Temperature;

  double* TheDistributionParameters;
  TA_initActivity();
  ~TA_initActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // TA_initActivityActivity

class TA_failureActivity:public Activity {
public:

  Place* off;
  short* off_Mobius_Mark;
  Place* ready;
  short* ready_Mobius_Mark;
  Place* on;
  short* on_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  Place* action;
  short* action_Mobius_Mark;
  Place* TimeReady;
  short* TimeReady_Mobius_Mark;
  Place* notifyIn;
  short* notifyIn_Mobius_Mark;
  Place* id;
  short* id_Mobius_Mark;
  Place* TimeOn;
  short* TimeOn_Mobius_Mark;
  Place* notifyOut;
  short* notifyOut_Mobius_Mark;
  Place* failure;
  short* failure_Mobius_Mark;
  ExtendedPlace<double>* Temperature;

  double* TheDistributionParameters;
  TA_failureActivity();
  ~TA_failureActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // TA_failureActivityActivity

  //List of user-specified place names
  Place* action;
  Place* off;
  Place* failure;
  Place* time;
  Place* on;
  Place* locality;
  Place* profileID;
  Place* SwitchID;
  Place* s;
  Place* ready;
  Place* TimeReady;
  Place* TimeOn;
  Place* notifyIn;
  Place* notifyOut;
  Place* id;
  Place* synch;
  ExtendedPlace<double>* Temperature;

  // Create instances of all actvities
  IA_on2offActivity IA_on2off;
  IA_off2readyActivity IA_off2ready;
  IA_ready2onActivity IA_ready2on;
  ClockActivity Clock;
  TA_initActivity TA_init;
  TA_failureActivity TA_failure;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup IA_on2offGroup;
  PostselectGroup IA_off2readyGroup;
  PostselectGroup IA_ready2onGroup;

  RailSwitchHeater2SAN();
  ~RailSwitchHeater2SAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end RailSwitchHeater2SAN

#endif // RailSwitchHeater2SAN_H_
