

// This C++ file was created by SanEditor

#include "Atomic/RailRoadSwitchHeaterCommunicationModel/RailRoadSwitchHeaterCommunicationModelSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         RailRoadSwitchHeaterCommunicationModelSAN Constructor             
******************************************************************/


RailRoadSwitchHeaterCommunicationModelSAN::RailRoadSwitchHeaterCommunicationModelSAN(){


  Activity* InitialActionList[2]={
    &sendIA, //0
    &receiveIA  // 1
  };

  BaseGroupClass* InitialGroupList[2]={
    (BaseGroupClass*) &(sendIA), 
    (BaseGroupClass*) &(receiveIA)
  };

  state = new Place("state" ,0);
  msg = new Place("msg" ,0);
  idSend = new Place("idSend" ,0);
  SwitchID = new Place("SwitchID" ,0);
  idRec = new Place("idRec" ,0);
  synch = new Place("synch" ,0);
  BaseStateVariableClass* InitialPlaces[6]={
    state,  // 0
    msg,  // 1
    idSend,  // 2
    SwitchID,  // 3
    idRec,  // 4
    synch   // 5
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("RailRoadSwitchHeaterCommunicationModel", 6, InitialPlaces, 
                        0, InitialROPlaces, 
                        2, InitialActionList, 2, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[10][2]={ 
    {0,0}, {1,0}, {2,0}, {3,0}, {4,0}, {0,1}, {1,1}, {2,1}, {4,1}, 
    {3,1}
  };
  for(int n=0;n<10;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[7][2]={ 
    {5,0}, {0,0}, {1,0}, {2,0}, {4,0}, {4,1}, {3,1}
  };
  for(int n=0;n<7;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<2;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void RailRoadSwitchHeaterCommunicationModelSAN::CustomInitialization() {

}
RailRoadSwitchHeaterCommunicationModelSAN::~RailRoadSwitchHeaterCommunicationModelSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void RailRoadSwitchHeaterCommunicationModelSAN::assignPlacesToActivitiesInst(){
  sendIA.synch = (Place*) LocalStateVariables[5];
  sendIA.state = (Place*) LocalStateVariables[0];
  sendIA.msg = (Place*) LocalStateVariables[1];
  sendIA.idSend = (Place*) LocalStateVariables[2];
  sendIA.idRec = (Place*) LocalStateVariables[4];
  sendIA.SwitchID = (Place*) LocalStateVariables[3];
  receiveIA.idRec = (Place*) LocalStateVariables[4];
  receiveIA.SwitchID = (Place*) LocalStateVariables[3];
  receiveIA.state = (Place*) LocalStateVariables[0];
  receiveIA.msg = (Place*) LocalStateVariables[1];
  receiveIA.idSend = (Place*) LocalStateVariables[2];
}
void RailRoadSwitchHeaterCommunicationModelSAN::assignPlacesToActivitiesTimed(){
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================sendIAActivity========================*/


RailRoadSwitchHeaterCommunicationModelSAN::sendIAActivity::sendIAActivity(){
  ActivityInitialize("sendIA",0,Instantaneous , RaceEnabled, 5,5, false);
}

void RailRoadSwitchHeaterCommunicationModelSAN::sendIAActivity::LinkVariables(){
  synch->Register(&synch_Mobius_Mark);
  state->Register(&state_Mobius_Mark);
  msg->Register(&msg_Mobius_Mark);
  idSend->Register(&idSend_Mobius_Mark);
  idRec->Register(&idRec_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);
}

bool RailRoadSwitchHeaterCommunicationModelSAN::sendIAActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((synch->Mark()==numSwitch
&&
(state->Mark()==13 || state->Mark()==33 || state->Mark()==61 )
&&
msg->Mark()==0
&&
idSend->Mark()==0
&&
idRec->Mark()==0));
  return NewEnabled;
}

double RailRoadSwitchHeaterCommunicationModelSAN::sendIAActivity::Weight(){ 
  return 1;
}

bool RailRoadSwitchHeaterCommunicationModelSAN::sendIAActivity::ReactivationPredicate(){ 
  return false;
}

bool RailRoadSwitchHeaterCommunicationModelSAN::sendIAActivity::ReactivationFunction(){ 
  return false;
}

double RailRoadSwitchHeaterCommunicationModelSAN::sendIAActivity::SampleDistribution(){
  return 0;
}

double* RailRoadSwitchHeaterCommunicationModelSAN::sendIAActivity::ReturnDistributionParameters(){
    return NULL;
}

int RailRoadSwitchHeaterCommunicationModelSAN::sendIAActivity::Rank(){
  return 1;
}

BaseActionClass* RailRoadSwitchHeaterCommunicationModelSAN::sendIAActivity::Fire(){
  ;
  if (state->Mark() == 13)// off and below Twa
{
	state->Mark()= 21; // ready1
	msg->Mark()= 1; // insert
	idSend->Mark()= SwitchID->Mark();
	idRec->Mark()= numSwitch+1; // coordinator
}
else if (state->Mark() == 33)// above Two
{
	state->Mark() = 11; // off and above Twa
	msg->Mark()= 3; // remove
	idSend->Mark()= SwitchID->Mark();
	idRec->Mark()= numSwitch+1; // coordinator
}
else if (state->Mark() == 61)  // failed while on
{	
	msg->Mark()= 3; // remove
	idSend->Mark()= SwitchID->Mark();
	idRec->Mark()= numSwitch+1; // coordinator
}

  return this;
}

/*======================receiveIAActivity========================*/


RailRoadSwitchHeaterCommunicationModelSAN::receiveIAActivity::receiveIAActivity(){
  ActivityInitialize("receiveIA",1,Instantaneous , RaceEnabled, 5,2, false);
}

void RailRoadSwitchHeaterCommunicationModelSAN::receiveIAActivity::LinkVariables(){
  idRec->Register(&idRec_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);
  state->Register(&state_Mobius_Mark);
  msg->Register(&msg_Mobius_Mark);
  idSend->Register(&idSend_Mobius_Mark);
}

bool RailRoadSwitchHeaterCommunicationModelSAN::receiveIAActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((idRec->Mark()==SwitchID->Mark())
&&
(SwitchID->Mark()!=0)));
  return NewEnabled;
}

double RailRoadSwitchHeaterCommunicationModelSAN::receiveIAActivity::Weight(){ 
  return 1;
}

bool RailRoadSwitchHeaterCommunicationModelSAN::receiveIAActivity::ReactivationPredicate(){ 
  return false;
}

bool RailRoadSwitchHeaterCommunicationModelSAN::receiveIAActivity::ReactivationFunction(){ 
  return false;
}

double RailRoadSwitchHeaterCommunicationModelSAN::receiveIAActivity::SampleDistribution(){
  return 0;
}

double* RailRoadSwitchHeaterCommunicationModelSAN::receiveIAActivity::ReturnDistributionParameters(){
    return NULL;
}

int RailRoadSwitchHeaterCommunicationModelSAN::receiveIAActivity::Rank(){
  return 1;
}

BaseActionClass* RailRoadSwitchHeaterCommunicationModelSAN::receiveIAActivity::Fire(){
  ;
  if ((state->Mark()==22)&&(msg->Mark()==2)) //ready and notifyIn
{
	state->Mark()=31; //on and below Two
	msg->Mark()=0;
	idSend->Mark()=0;
	idRec->Mark()=0;
}
else if ((state->Mark()==32)&&(msg->Mark()==4)) // on and below Two and notifyOut
{
	state->Mark()=11; //off and above Twa ?
	msg->Mark()=0;
	idSend->Mark()=0;
	idRec->Mark()=0;
}
else if ((state->Mark()==33)&&(msg->Mark()==4)) 
{
	//T>Two right after notify out
	msg->Mark()=0;
	idSend->Mark()=0;
	idRec->Mark()=0;
}
else if ((state->Mark()==62)&&(msg->Mark()==2))
{
	// failed rightafter notify in
	msg->Mark()= 3; // remove
	idSend->Mark()= SwitchID->Mark();
	idRec->Mark()= numSwitch+1; // coordinator
	state->Mark()=63;
}
else if ((state->Mark() == 61)&&(msg->Mark()==4))  
{	
	// failed right after notify out
	msg->Mark()=0;
	idSend->Mark()=0;
	idRec->Mark()=0;
	state->Mark()=63;
}
  return this;
}

