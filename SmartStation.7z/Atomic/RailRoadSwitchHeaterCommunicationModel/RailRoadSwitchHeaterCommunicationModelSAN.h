#ifndef RailRoadSwitchHeaterCommunicationModelSAN_H_
#define RailRoadSwitchHeaterCommunicationModelSAN_H_

#include "include/SmartStation.h"
#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short numSwitch;
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               RailRoadSwitchHeaterCommunicationModelSAN Submodel Definition                   
*********************************************************************/

class RailRoadSwitchHeaterCommunicationModelSAN:public SANModel{
public:

class sendIAActivity:public Activity {
public:

  Place* synch;
  short* synch_Mobius_Mark;
  Place* state;
  short* state_Mobius_Mark;
  Place* msg;
  short* msg_Mobius_Mark;
  Place* idSend;
  short* idSend_Mobius_Mark;
  Place* idRec;
  short* idRec_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;

  double* TheDistributionParameters;
  sendIAActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // sendIAActivityActivity

class receiveIAActivity:public Activity {
public:

  Place* idRec;
  short* idRec_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  Place* state;
  short* state_Mobius_Mark;
  Place* msg;
  short* msg_Mobius_Mark;
  Place* idSend;
  short* idSend_Mobius_Mark;

  double* TheDistributionParameters;
  receiveIAActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // receiveIAActivityActivity

  //List of user-specified place names
  Place* state;
  Place* msg;
  Place* idSend;
  Place* SwitchID;
  Place* idRec;
  Place* synch;

  // Create instances of all actvities
  sendIAActivity sendIA;
  receiveIAActivity receiveIA;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup sendIAGroup;
  PostselectGroup receiveIAGroup;

  RailRoadSwitchHeaterCommunicationModelSAN();
  ~RailRoadSwitchHeaterCommunicationModelSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end RailRoadSwitchHeaterCommunicationModelSAN

#endif // RailRoadSwitchHeaterCommunicationModelSAN_H_
