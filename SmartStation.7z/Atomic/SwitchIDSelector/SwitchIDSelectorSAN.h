#ifndef SwitchIDSelectorSAN_H_
#define SwitchIDSelectorSAN_H_

#include "include/SmartStation.h"
#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short numSwitch;
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               SwitchIDSelectorSAN Submodel Definition                   
*********************************************************************/

class SwitchIDSelectorSAN:public SANModel{
public:

class IA1Activity:public Activity {
public:

  Place* p2;
  short* p2_Mobius_Mark;
  Place* SwitchID;
  short* SwitchID_Mobius_Mark;
  Place* p1;
  short* p1_Mobius_Mark;

  double* TheDistributionParameters;
  IA1Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // IA1ActivityActivity

  //List of user-specified place names
  Place* p2;
  Place* SwitchID;
  Place* p1;

  // Create instances of all actvities
  IA1Activity IA1;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup IA1Group;

  SwitchIDSelectorSAN();
  ~SwitchIDSelectorSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end SwitchIDSelectorSAN

#endif // SwitchIDSelectorSAN_H_
