

// This C++ file was created by SanEditor

#include "Atomic/SwitchIDSelector/SwitchIDSelectorSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         SwitchIDSelectorSAN Constructor             
******************************************************************/


SwitchIDSelectorSAN::SwitchIDSelectorSAN(){


  Activity* InitialActionList[1]={
    &IA1  // 0
  };

  BaseGroupClass* InitialGroupList[1]={
    (BaseGroupClass*) &(IA1)
  };

  p2 = new Place("p2" ,1);
  SwitchID = new Place("SwitchID" ,0);
  p1 = new Place("p1" ,numSwitch);
  BaseStateVariableClass* InitialPlaces[3]={
    p2,  // 0
    SwitchID,  // 1
    p1   // 2
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("SwitchIDSelector", 3, InitialPlaces, 
                        0, InitialROPlaces, 
                        1, InitialActionList, 1, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[3][2]={ 
    {0,0}, {1,0}, {2,0}
  };
  for(int n=0;n<3;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[1][2]={ 
    {0,0}
  };
  for(int n=0;n<1;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<1;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void SwitchIDSelectorSAN::CustomInitialization() {

}
SwitchIDSelectorSAN::~SwitchIDSelectorSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void SwitchIDSelectorSAN::assignPlacesToActivitiesInst(){
  IA1.p2 = (Place*) LocalStateVariables[0];
  IA1.SwitchID = (Place*) LocalStateVariables[1];
  IA1.p1 = (Place*) LocalStateVariables[2];
}
void SwitchIDSelectorSAN::assignPlacesToActivitiesTimed(){
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================IA1Activity========================*/


SwitchIDSelectorSAN::IA1Activity::IA1Activity(){
  ActivityInitialize("IA1",0,Instantaneous , RaceEnabled, 3,1, false);
}

void SwitchIDSelectorSAN::IA1Activity::LinkVariables(){
  p2->Register(&p2_Mobius_Mark);
  SwitchID->Register(&SwitchID_Mobius_Mark);
  p1->Register(&p1_Mobius_Mark);
}

bool SwitchIDSelectorSAN::IA1Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((p2->Mark() == 1));
  return NewEnabled;
}

double SwitchIDSelectorSAN::IA1Activity::Weight(){ 
  return 1;
}

bool SwitchIDSelectorSAN::IA1Activity::ReactivationPredicate(){ 
  return false;
}

bool SwitchIDSelectorSAN::IA1Activity::ReactivationFunction(){ 
  return false;
}

double SwitchIDSelectorSAN::IA1Activity::SampleDistribution(){
  return 0;
}

double* SwitchIDSelectorSAN::IA1Activity::ReturnDistributionParameters(){
    return NULL;
}

int SwitchIDSelectorSAN::IA1Activity::Rank(){
  return 1;
}

BaseActionClass* SwitchIDSelectorSAN::IA1Activity::Fire(){
  p2->Mark() = 0;
  SwitchID->Mark() = p1->Mark();
p1->Mark()--;

  return this;
}

